package ewl.chinmayala.Interface;

import android.support.v4.app.Fragment;

/**
 * Created by Akash.Singh on 1/20/2016.
 */
public interface IMenuItemClick {
    void onMenuClick(Fragment fragment);
}
