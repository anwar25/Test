package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 7/2/2016.
 */
public class ProfessionListResponse {

    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private List<ProfessionData> professionDataList = new ArrayList<ProfessionData>();

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<ProfessionData> getProfessionDataList() {
        return professionDataList;
    }

    public void setProfessionDataList(List<ProfessionData> professionDataList) {
        this.professionDataList = professionDataList;
    }

    @Override
    public String toString() {
        return "ProfessionListResponse{" +
                "status=" + status +
                ", professionDataList=" + professionDataList +
                '}';
    }
}
