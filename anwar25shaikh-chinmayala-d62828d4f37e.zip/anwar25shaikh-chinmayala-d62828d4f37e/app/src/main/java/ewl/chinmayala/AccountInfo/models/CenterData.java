package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/2/2016.
 */

public class CenterData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("center_name")
    @Expose
    private String centerName;
    @SerializedName("center_address")
    @Expose
    private String centerAddress;
    @SerializedName("status")
    @Expose
    private String status;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The centerName
     */
    public String getCenterName() {
        return centerName;
    }

    /**
     *
     * @param centerName
     * The center_name
     */
    public void setCenterName(String centerName) {
        this.centerName = centerName;
    }

    /**
     *
     * @return
     * The centerAddress
     */
    public String getCenterAddress() {
        return centerAddress;
    }

    /**
     *
     * @param centerAddress
     * The center_address
     */
    public void setCenterAddress(String centerAddress) {
        this.centerAddress = centerAddress;
    }

    /**
     *
     * @return
     * The status
     */
    public String getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "CenterData{" +
                "id='" + id + '\'' +
                ", centerName='" + centerName + '\'' +
                ", centerAddress='" + centerAddress + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}