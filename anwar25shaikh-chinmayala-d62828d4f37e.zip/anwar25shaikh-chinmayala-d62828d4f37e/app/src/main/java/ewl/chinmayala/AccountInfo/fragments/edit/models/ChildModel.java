package ewl.chinmayala.AccountInfo.fragments.edit.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import ewl.chinmayala.Utils.Utils;

/**
 * Created by Anwar on 7/30/2016.
 */
public class ChildModel implements Serializable {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("session_id")
    @Expose
    private String sessionId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("emailid")
    @Expose
    private String emailid;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("old_password")
    @Expose
    private String oldPassword;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("designation_master_id")
    @Expose
    private Object designationMasterId;
    @SerializedName("create_date")
    @Expose
    private String createDate;
    @SerializedName("terminate_date")
    @Expose
    private Object terminateDate;
    @SerializedName("is_active")
    @Expose
    private String isActive;
    @SerializedName("other")
    @Expose
    private String other;
    @SerializedName("forgot_pass_code")
    @Expose
    private Object forgotPassCode;
    @SerializedName("member_type")
    @Expose
    private Object memberType;
    @SerializedName("member_login_id")
    @Expose
    private String memberLoginId;
    @SerializedName("language_id")
    @Expose
    private Object languageId;
    @SerializedName("grade_id")
    @Expose
    private String gradeId;
    @SerializedName("class_id")
    @Expose
    private String classId;
    @SerializedName("section_id")
    @Expose
    private Object sectionId;
    @SerializedName("full_name")
    @Expose
    private String fullName;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("mother_tongue")
    @Expose
    private String motherTongue;
    @SerializedName("home_phone")
    @Expose
    private String homePhone;
    @SerializedName("cell_phone")
    @Expose
    private String cellPhone;
    @SerializedName("email_address")
    @Expose
    private String emailAddress;
    @SerializedName("current_school_info")
    @Expose
    private String currentSchoolInfo;
    @SerializedName("district_name")
    @Expose
    private String districtName;
    @SerializedName("school_city")
    @Expose
    private String schoolCity;
    @SerializedName("next_year_school_grade")
    @Expose
    private Object nextYearSchoolGrade;
    @SerializedName("next_year_class")
    @Expose
    private Object nextYearClass;
    @SerializedName("Is_bv_class")
    @Expose
    private String isBvClass;
    @SerializedName("is_shruti_class")
    @Expose
    private String isShrutiClass;
    @SerializedName("is_available")
    @Expose
    private String isAvailable;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("grade_name")
    @Expose
    private String gradeName;
    @SerializedName("lang_name")
    @Expose
    private String langName;
    @SerializedName("session_name")
    @Expose
    private String sessionName;
    @SerializedName("session_start")
    @Expose
    private String sessionStart;
    @SerializedName("session_end")
    @Expose
    private String sessionEnd;
    @SerializedName("section_name")
    @Expose
    private Object sectionName;
    @SerializedName("status_name")
    @Expose
    private String statusName;
    @SerializedName("center_name")
    @Expose
    private String centerName;
    @SerializedName("class_name")
    @Expose
    private String className;
    @SerializedName("total_seat")
    @Expose
    private String totalSeat;
    @SerializedName("fill_seat")
    @Expose
    private String fillSeat;

    private int age ;

    public int getAge() {
        return Utils.getAge(getDob());
    }

    public void setAge(int age) {
        this.age = age;
    }

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     *
     * @return
     * The sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     *
     * @param sessionId
     * The session_id
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     *
     * @return
     * The name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     * The name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     * The dob
     */
    public String getDob() {
        return dob;
    }

    /**
     *
     * @param dob
     * The dob
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     *
     * @return
     * The emailid
     */
    public String getEmailid() {
        return emailid;
    }

    /**
     *
     * @param emailid
     * The emailid
     */
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    /**
     *
     * @return
     * The password
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     * The password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return
     * The oldPassword
     */
    public String getOldPassword() {
        return oldPassword;
    }

    /**
     *
     * @param oldPassword
     * The old_password
     */
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    /**
     *
     * @return
     * The image
     */
    public String getImage() {
        return image;
    }

    /**
     *
     * @param image
     * The image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     *
     * @return
     * The designationMasterId
     */
    public Object getDesignationMasterId() {
        return designationMasterId;
    }

    /**
     *
     * @param designationMasterId
     * The designation_master_id
     */
    public void setDesignationMasterId(Object designationMasterId) {
        this.designationMasterId = designationMasterId;
    }

    /**
     *
     * @return
     * The createDate
     */
    public String getCreateDate() {
        return createDate;
    }

    /**
     *
     * @param createDate
     * The create_date
     */
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    /**
     *
     * @return
     * The terminateDate
     */
    public Object getTerminateDate() {
        return terminateDate;
    }

    /**
     *
     * @param terminateDate
     * The terminate_date
     */
    public void setTerminateDate(Object terminateDate) {
        this.terminateDate = terminateDate;
    }

    /**
     *
     * @return
     * The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     *
     * @param isActive
     * The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    /**
     *
     * @return
     * The other
     */
    public String getOther() {
        return other;
    }

    /**
     *
     * @param other
     * The other
     */
    public void setOther(String other) {
        this.other = other;
    }

    /**
     *
     * @return
     * The forgotPassCode
     */
    public Object getForgotPassCode() {
        return forgotPassCode;
    }

    /**
     *
     * @param forgotPassCode
     * The forgot_pass_code
     */
    public void setForgotPassCode(Object forgotPassCode) {
        this.forgotPassCode = forgotPassCode;
    }

    /**
     *
     * @return
     * The memberType
     */
    public Object getMemberType() {
        return memberType;
    }

    /**
     *
     * @param memberType
     * The member_type
     */
    public void setMemberType(Object memberType) {
        this.memberType = memberType;
    }

    /**
     *
     * @return
     * The memberLoginId
     */
    public String getMemberLoginId() {
        return memberLoginId;
    }

    /**
     *
     * @param memberLoginId
     * The member_login_id
     */
    public void setMemberLoginId(String memberLoginId) {
        this.memberLoginId = memberLoginId;
    }

    /**
     *
     * @return
     * The languageId
     */
    public Object getLanguageId() {
        return languageId;
    }

    /**
     *
     * @param languageId
     * The language_id
     */
    public void setLanguageId(Object languageId) {
        this.languageId = languageId;
    }

    /**
     *
     * @return
     * The gradeId
     */
    public String getGradeId() {
        return gradeId;
    }

    /**
     *
     * @param gradeId
     * The grade_id
     */
    public void setGradeId(String gradeId) {
        this.gradeId = gradeId;
    }

    /**
     *
     * @return
     * The classId
     */
    public String getClassId() {
        return classId;
    }

    /**
     *
     * @param classId
     * The class_id
     */
    public void setClassId(String classId) {
        this.classId = classId;
    }

    /**
     *
     * @return
     * The sectionId
     */
    public Object getSectionId() {
        return sectionId;
    }

    /**
     *
     * @param sectionId
     * The section_id
     */
    public void setSectionId(Object sectionId) {
        this.sectionId = sectionId;
    }

    /**
     *
     * @return
     * The fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     *
     * @param fullName
     * The full_name
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     *
     * @return
     * The gender
     */
    public String getGender() {
        return gender;
    }

    /**
     *
     * @param gender
     * The gender
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     *
     * @return
     * The motherTongue
     */
    public String getMotherTongue() {
        return motherTongue;
    }

    /**
     *
     * @param motherTongue
     * The mother_tongue
     */
    public void setMotherTongue(String motherTongue) {
        this.motherTongue = motherTongue;
    }

    /**
     *
     * @return
     * The homePhone
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     *
     * @param homePhone
     * The home_phone
     */
    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    /**
     *
     * @return
     * The cellPhone
     */
    public String getCellPhone() {
        return cellPhone;
    }

    /**
     *
     * @param cellPhone
     * The cell_phone
     */
    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    /**
     *
     * @return
     * The emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     *
     * @param emailAddress
     * The email_address
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     *
     * @return
     * The currentSchoolInfo
     */
    public String getCurrentSchoolInfo() {
        return currentSchoolInfo;
    }

    /**
     *
     * @param currentSchoolInfo
     * The current_school_info
     */
    public void setCurrentSchoolInfo(String currentSchoolInfo) {
        this.currentSchoolInfo = currentSchoolInfo;
    }

    /**
     *
     * @return
     * The districtName
     */
    public String getDistrictName() {
        return districtName;
    }

    /**
     *
     * @param districtName
     * The district_name
     */
    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    /**
     *
     * @return
     * The schoolCity
     */
    public String getSchoolCity() {
        return schoolCity;
    }

    /**
     *
     * @param schoolCity
     * The school_city
     */
    public void setSchoolCity(String schoolCity) {
        this.schoolCity = schoolCity;
    }

    /**
     *
     * @return
     * The nextYearSchoolGrade
     */
    public Object getNextYearSchoolGrade() {
        return nextYearSchoolGrade;
    }

    /**
     *
     * @param nextYearSchoolGrade
     * The next_year_school_grade
     */
    public void setNextYearSchoolGrade(Object nextYearSchoolGrade) {
        this.nextYearSchoolGrade = nextYearSchoolGrade;
    }

    /**
     *
     * @return
     * The nextYearClass
     */
    public Object getNextYearClass() {
        return nextYearClass;
    }

    /**
     *
     * @param nextYearClass
     * The next_year_class
     */
    public void setNextYearClass(Object nextYearClass) {
        this.nextYearClass = nextYearClass;
    }

    /**
     *
     * @return
     * The isBvClass
     */
    public String getIsBvClass() {
        return isBvClass;
    }

    /**
     *
     * @param isBvClass
     * The Is_bv_class
     */
    public void setIsBvClass(String isBvClass) {
        this.isBvClass = isBvClass;
    }

    /**
     *
     * @return
     * The isShrutiClass
     */
    public String getIsShrutiClass() {
        return isShrutiClass;
    }

    /**
     *
     * @param isShrutiClass
     * The is_shruti_class
     */
    public void setIsShrutiClass(String isShrutiClass) {
        this.isShrutiClass = isShrutiClass;
    }

    /**
     *
     * @return
     * The isAvailable
     */
    public String getIsAvailable() {
        return isAvailable;
    }

    /**
     *
     * @param isAvailable
     * The is_available
     */
    public void setIsAvailable(String isAvailable) {
        this.isAvailable = isAvailable;
    }

    /**
     *
     * @return
     * The status
     */
    public String getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     *
     * @return
     * The gradeName
     */
    public String getGradeName() {
        return gradeName;
    }

    /**
     *
     * @param gradeName
     * The grade_name
     */
    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    /**
     *
     * @return
     * The langName
     */
    public String getLangName() {
        return langName;
    }

    /**
     *
     * @param langName
     * The lang_name
     */
    public void setLangName(String langName) {
        this.langName = langName;
    }

    /**
     *
     * @return
     * The sessionName
     */
    public String getSessionName() {
        return sessionName;
    }

    /**
     *
     * @param sessionName
     * The session_name
     */
    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

    /**
     *
     * @return
     * The sessionStart
     */
    public String getSessionStart() {
        return sessionStart;
    }

    /**
     *
     * @param sessionStart
     * The session_start
     */
    public void setSessionStart(String sessionStart) {
        this.sessionStart = sessionStart;
    }

    /**
     *
     * @return
     * The sessionEnd
     */
    public String getSessionEnd() {
        return sessionEnd;
    }

    /**
     *
     * @param sessionEnd
     * The session_end
     */
    public void setSessionEnd(String sessionEnd) {
        this.sessionEnd = sessionEnd;
    }

    /**
     *
     * @return
     * The sectionName
     */
    public Object getSectionName() {
        return sectionName;
    }

    /**
     *
     * @param sectionName
     * The section_name
     */
    public void setSectionName(Object sectionName) {
        this.sectionName = sectionName;
    }

    /**
     *
     * @return
     * The statusName
     */
    public String getStatusName() {
        return statusName;
    }

    /**
     *
     * @param statusName
     * The status_name
     */
    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    /**
     *
     * @return
     * The centerName
     */
    public String getCenterName() {
        return centerName;
    }

    /**
     *
     * @param centerName
     * The center_name
     */
    public void setCenterName(String centerName) {
        this.centerName = centerName;
    }

    /**
     *
     * @return
     * The className
     */
    public String getClassName() {
        return className;
    }

    /**
     *
     * @param className
     * The class_name
     */
    public void setClassName(String className) {
        this.className = className;
    }

    /**
     *
     * @return
     * The totalSeat
     */
    public String getTotalSeat() {
        return totalSeat;
    }

    /**
     *
     * @param totalSeat
     * The total_seat
     */
    public void setTotalSeat(String totalSeat) {
        this.totalSeat = totalSeat;
    }

    /**
     *
     * @return
     * The fillSeat
     */
    public String getFillSeat() {
        return fillSeat;
    }

    /**
     *
     * @param fillSeat
     * The fill_seat
     */
    public void setFillSeat(String fillSeat) {
        this.fillSeat = fillSeat;
    }
}
