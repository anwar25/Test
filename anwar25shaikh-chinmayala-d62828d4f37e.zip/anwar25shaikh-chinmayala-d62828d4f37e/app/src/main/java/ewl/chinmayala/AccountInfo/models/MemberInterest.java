package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 449781 on 8/10/2016.
 */
public class MemberInterest {

    @SerializedName("member_id")
    @Expose
    private String memberId;
    @SerializedName("member_interest")
    @Expose
    private String memberInterest;


    public MemberInterest(String memberId , String memberInterest){
        this.memberId = memberId ;
        this.memberInterest = memberInterest ;
    }
    /**
     * @return The memberId
     */
    public String getMemberId() {
        return memberId;
    }

    /**
     * @param memberId The member_id
     */
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    /**
     * @return The memberInterest
     */
    public String getMemberInterest() {
        return memberInterest;
    }
}