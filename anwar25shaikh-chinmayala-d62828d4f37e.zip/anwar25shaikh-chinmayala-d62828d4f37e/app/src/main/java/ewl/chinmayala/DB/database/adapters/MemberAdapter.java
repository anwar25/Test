package ewl.chinmayala.DB.database.adapters;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.google.gson.Gson;

import java.util.ArrayList;

import ewl.chinmayala.AccountInfo.models.LoginData;
import ewl.chinmayala.DB.ChinTable;

/**
 * Created by Anwar on 7/22/2016.
 */
public class MemberAdapter extends ParentAdapter{

    @Override
    public long insert(Object model) {
        long rowID = -1;
        LoginData loginData  = (LoginData)model ;
        Gson gson = new Gson();
        SQLiteDatabase sqLiteDatabase = null;
        ContentValues contentValues = new ContentValues();
        try {
            sqLiteDatabase = openDB();
            contentValues.put(ChinTable.Member.COLUMN_NAME_MEM_DATA,gson.toJson(loginData));

            rowID = sqLiteDatabase.insert(ChinTable.Member.TABLE_NAME, null, contentValues);
            if (rowID == -1) {
                Log.v(TAG, "- unsuccessful insert operation");
                throw new SQLiteException("Insertion failed :" + model.toString());
            }
            sqLiteDatabase.setTransactionSuccessful();
        } catch (SQLiteException exception) {
            Log.e(TAG, exception.getMessage());
        } finally {
            closeDB();
        }
        return rowID;
    }

    @Override
    public boolean delete(String id) {
        return false;
    }

    @Override
    public boolean update(Object model) {
        return false;
    }

    @Override
    public ArrayList<LoginData> getAll() {
        ArrayList<LoginData> loginDataArrayList = new ArrayList<LoginData>();

        String selectQuery = new StringBuilder(ChinTable.SELECT_STAR_FROM).
                append(ChinTable.Member.TABLE_NAME).append(";").toString();

        Cursor cursor = null;
        try {
            Gson gson = new Gson();
            SQLiteDatabase database = openDBForReadOperation();
            cursor = database.rawQuery(selectQuery, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    loginDataArrayList.add( gson.fromJson(cursor.getString(cursor.getColumnIndex(ChinTable.Member.COLUMN_NAME_MEM_DATA)),LoginData.class));
                }
                return loginDataArrayList;
            }
        } catch (SQLiteException exception) {
            Log.e(TAG, exception.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
                //closeDB();
            }
        }
        return null;
    }
}

