package ewl.chinmayala.AccountInfo.fragments.edit.models;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ewl.chinmayala.AccountInfo.adapters.PlacesAutoCompleteAdapter;
import ewl.chinmayala.AccountInfo.models.AddressComponent;
import ewl.chinmayala.AccountInfo.models.CenterData;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.AccountInfo.models.LanguageData;
import ewl.chinmayala.AccountInfo.models.LanguageResponseModel;
import ewl.chinmayala.AccountInfo.models.MemberRegModel;
import ewl.chinmayala.AccountInfo.models.PlaceDetails;
import ewl.chinmayala.AccountInfo.models.PredictionResponse;
import ewl.chinmayala.AccountInfo.models.ProfessionData;
import ewl.chinmayala.AccountInfo.models.ProfessionListResponse;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.UI.CustomSpinnerAdapter;
import ewl.chinmayala.Utils.DatePickerUtility;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.Utils.Utils;
import ewl.chinmayala.constants.Constants;
import ewl.chinmayala.constants.Urls;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar on 2/14/2016.
 */
public class EditMemberFragment extends BaseFragment implements View.OnClickListener {

//}, AdapterView.OnItemSelectedListener{

    private static final String TAG = EditMemberFragment.class.getSimpleName();
    private CustomSpinnerAdapter mLanguageAdapter;
    private EditText mNameEditText;
    private TableRow mDatePicker;
    private EditText mDobEditText;

    private EditText mEmailEditText;
    private EditText mPasswordEditText;
    private EditText mRetypePwdEditText;
    private EditText mAptEditText;
    private AutoCompleteTextView mAddressAutoCompTextView;
    private EditText mStreetAddEditText;

    private EditText mStateEditText;
    private EditText mZipCodeEditText;
    private EditText mCountryEditText;
    private EditText mHomePhoneEditText;
    private EditText mCellPhoneEditText;
    private EditText mOfficePhoneEditText;
    private AutoCompleteTextView mProfessionAutoCompTextView;
    private Spinner mLanguageSpinner;

    private CustomAppCompatButton mSubmitButton;
    private HomeActivity activityHandle;

    // HashMap<String,String> centerAddressMap ;
    private CenterData mCenterData;
    private ArrayList<String> professionList;
    private ArrayList<String> languageArrayList;
    ArrayList<PlaceDetails> placeDetailsList;
    private ArrayAdapter<String> mAutoCompProfessionAdapter;
    private PlacesAutoCompleteAdapter mAutoPlaceCompleteAdapter;

    private String memberReg;
    private boolean isFromDashboard = false;
    private MemberModel mMemberDetails;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.edit_member_fragment_layout, container, false);
        mapControls(view);
        if(getArguments() != null) {
            mMemberDetails = (MemberModel) getArguments().getSerializable(Constants.MEMBER_DETAILS);
        }
        if (null != mMemberDetails)
            new DownloadData().execute(mMemberDetails.getCenterId());
        // activityHandle.setToolbarInitialization(this, memberReg);
        activityHandle.setToolbarInitialization(this, getString(R.string.update_member));
        return view;
    }

    @Override
    public void mapControls(View rootView) {
        mNameEditText = (EditText) rootView.findViewById(R.id.nameEditText);
        mDatePicker = (TableRow) rootView.findViewById(R.id.birthDatePicker);
        mDatePicker.setOnClickListener(this);
        mDobEditText = (EditText) rootView.findViewById(R.id.dobEditText);

        mEmailEditText = (CustomEditText) rootView.findViewById(R.id.emailEditText);
        mPasswordEditText = (CustomEditText) rootView.findViewById(R.id.passwordEditText);
        mRetypePwdEditText = (CustomEditText) rootView.findViewById(R.id.passwordRetypeEditText);
        mAptEditText = (CustomEditText) rootView.findViewById(R.id.aptEdiText);
        mStreetAddEditText = (CustomEditText) rootView.findViewById(R.id.streetAddressEditText);
        mStateEditText = (CustomEditText) rootView.findViewById(R.id.stateEditText);
        mCountryEditText = (CustomEditText) rootView.findViewById(R.id.countryEditText);
        mZipCodeEditText = (CustomEditText) rootView.findViewById(R.id.zipEditText);
        mHomePhoneEditText = (CustomEditText) rootView.findViewById(R.id.homePhoneEditText);
        mCellPhoneEditText = (CustomEditText) rootView.findViewById(R.id.cellPhoneEditText);
        mOfficePhoneEditText = (CustomEditText) rootView.findViewById(R.id.officePhoneEditText);
        mSubmitButton = (CustomAppCompatButton) rootView.findViewById(R.id.btnSubmit);
        mSubmitButton.setOnClickListener(this);

        mLanguageSpinner = (Spinner) rootView.findViewById(R.id.languageSpinner);
        languageArrayList = new ArrayList<String>();
        languageArrayList.add(getString(R.string.select_language));
        mLanguageAdapter = new CustomSpinnerAdapter(getActivity(), R.layout.spinner_item_layout, languageArrayList);
        // Drop down layout style - list view with radio button
        mLanguageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mLanguageSpinner.setAdapter(mLanguageAdapter);

        mProfessionAutoCompTextView = (AutoCompleteTextView) rootView.findViewById(R.id.professionEditText);
        mProfessionAutoCompTextView.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
        mProfessionAutoCompTextView.setThreshold(2);
        professionList = new ArrayList<String>();
        mAutoCompProfessionAdapter = new ArrayAdapter<String>(activityHandle, R.layout.spinner_item_layout, professionList);
        mProfessionAutoCompTextView.setAdapter(mAutoCompProfessionAdapter);
        mProfessionAutoCompTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Logger.e(TAG, mAutoCompProfessionAdapter.getItem(position));
            }
        });

        mAddressAutoCompTextView = (AutoCompleteTextView) rootView.findViewById(R.id.addressEditText);
        mAddressAutoCompTextView.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
        mAddressAutoCompTextView.setThreshold(2);
        placeDetailsList = new ArrayList<PlaceDetails>();
        mAutoPlaceCompleteAdapter = new PlacesAutoCompleteAdapter(activityHandle, 1, placeDetailsList);
        mAddressAutoCompTextView.setAdapter(mAutoPlaceCompleteAdapter);
        mAddressAutoCompTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Logger.e(TAG, mAutoPlaceCompleteAdapter.getItem(position));
                //PlaceDetails placeDetails = mAutoPlaceCompleteAdapter.getItem(position);
                mAddressAutoCompTextView.setText(mAutoPlaceCompleteAdapter.getItem(position).getDescription());
                getAddress(mAutoPlaceCompleteAdapter.getItem(position));
            }
        });
    }

    private void getAddress(PlaceDetails placeDetails) {
        activityHandle.showProgress(getString(R.string.loading_msg));
        Call<PredictionResponse> call = RetrofitInstance.getInstance(Urls.GOOGLE_PLACES_BASE_URL)
                .getPlaceDetails(placeDetails.getPlaceId(), Constants.GOOGLE_PLACES_API_KEY);
        call.enqueue(new Callback<PredictionResponse>() {
            @Override
            public void onResponse(Call<PredictionResponse> call, Response<PredictionResponse> response) {
                PredictionResponse predictionRes = response.body();
                if (predictionRes.getStatus().equalsIgnoreCase("ok")) {
                    loadAddress(predictionRes);
                }
                activityHandle.hideProgress();
            }

            @Override
            public void onFailure(Call<PredictionResponse> call, Throwable t) {
                activityHandle.hideProgress();
            }
        });
    }

    private String mRoute;
    private String mLocality;

    private void loadAddress(PredictionResponse predictionRes) {
        List<AddressComponent> addressComponents = predictionRes.getResult().getAddressComponents();
        for (AddressComponent address : addressComponents) {
            List<String> types = address.getTypes();
            for (String type : types) {
                if (type.equalsIgnoreCase("premise")) {
                    mAptEditText.setText(address.getLongName());
                } else if (type.equalsIgnoreCase("route")) {
                    mStreetAddEditText.setText(address.getLongName());
                } else if (type.equalsIgnoreCase("locality")) {
                    mLocality = address.getLongName();
                } else if (type.equalsIgnoreCase("administrative_area_level_2")) {
                    //city
                } else if (type.equalsIgnoreCase("administrative_area_level_1")) {
                    mStateEditText.setText(address.getLongName());
                } else if (type.equalsIgnoreCase("country")) {
                    mCountryEditText.setText(address.getLongName());
                } else if (type.equalsIgnoreCase("postal_code")) {
                    mZipCodeEditText.setText(address.getLongName());
                }
            }
        }
    }


    private class DownloadData extends AsyncTask<String, Void, HashMap<String, Object>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
                activityHandle.showNetworkErrorToast();
                return;
            }
            activityHandle.showProgress(getString(R.string.loading_msg));
        }

        @Override
        protected HashMap<String, Object> doInBackground(String... params) {
            HashMap<String, Object> resultMap = new HashMap<String, Object>();
            //    Call<CenterListResponse> centerCall = RetrofitInstance.getInstance().getCenterList();
            Call<ProfessionListResponse> profCall = RetrofitInstance.getInstance().getProfessionList();
            GenericRequestModel genericRequestModel = new GenericRequestModel(Integer.parseInt(params[0]));
            Call<LanguageResponseModel> langCall = RetrofitInstance.getInstance()
                    .getLanguages(genericRequestModel);
            try {
                //    Response<CenterListResponse> centerListResponseResponse  = centerCall.execute();
                Response<ProfessionListResponse> professionListResponseResponse = profCall.execute();
                Response<LanguageResponseModel> languageResponseModelResponse = langCall.execute();
                resultMap.put(Constants.PROFESSION_OBJ, professionListResponseResponse.body());
                resultMap.put(Constants.LANG_OBJ, languageResponseModelResponse.body());
                Logger.e(TAG, resultMap.toString());

            } catch (IOException e) {
                Logger.e(TAG, e.toString());
            }
            return resultMap;
        }

        @Override
        protected void onPostExecute(HashMap<String, Object> resultMap) {
            super.onPostExecute(resultMap);
            activityHandle.hideProgress();
            loadData(resultMap);
        }
    }

    private HashMap<String, String> mLanguageMapping;
    private HashMap<String, String> mProfessionMapping;

    private void loadData(HashMap<String, Object> resultMap) {
        ProfessionListResponse professionListResponse = (ProfessionListResponse) resultMap.get(Constants.PROFESSION_OBJ);
        LanguageResponseModel languageResponseModel = (LanguageResponseModel) resultMap.get(Constants.LANG_OBJ);

        mLanguageMapping = new HashMap<String, String>();
        mProfessionMapping = new HashMap<String, String>();
        int selectionIndex = 0 , count = 0;
        if (languageResponseModel != null && languageResponseModel.getLanguageDataList() != null) {
            for (LanguageData languageData : languageResponseModel.getLanguageDataList()) {
                count++ ;
                if(languageData.getLangName().equalsIgnoreCase(mMemberDetails.getLangName())){
                    selectionIndex = count ;
                }
                languageArrayList.add(languageData.getLangName());
                mLanguageMapping.put(languageData.getLangName(), languageData.getId());
            }
            mLanguageAdapter.notifyDataSetChanged();

            mLanguageSpinner.setSelection(selectionIndex);
        }

        if (professionListResponse != null && professionListResponse.getProfessionDataList() != null) {
            for (ProfessionData professionData : professionListResponse.getProfessionDataList()) {
                professionList.add(professionData.getOccupationName());
                mProfessionMapping.put(professionData.getOccupationName(), professionData.getId());
            }
            mAutoCompProfessionAdapter.notifyDataSetChanged();
        }


        if (mMemberDetails != null) {
            mNameEditText.setText(mMemberDetails.getName());
            mDobEditText.setText(mMemberDetails.getDob());
            mEmailEditText.setText(mMemberDetails.getEmailid());
            mPasswordEditText.setText(String.valueOf(mMemberDetails.getPassword()));
            mRetypePwdEditText.setText(String.valueOf(mMemberDetails.getPassword()));

            mAptEditText.setText(mMemberDetails.getAppartment());
            mAddressAutoCompTextView.setText(mMemberDetails.getMemberAddresses());
            mStreetAddEditText.setText(mMemberDetails.getStreetNumber());

            mStateEditText.setText(mMemberDetails.getState());
            mZipCodeEditText.setText(mMemberDetails.getPostalCode());
            mCountryEditText.setText(mMemberDetails.getCountry());

            mProfessionAutoCompTextView.setText(mMemberDetails.getOccupationName());
            //mLanguageSpinner
            mHomePhoneEditText.setText(mMemberDetails.getHomePhone());
            mCellPhoneEditText.setText(mMemberDetails.getCellPhone());
            mOfficePhoneEditText.setText(mMemberDetails.getOfficePhone());
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }

    @Override
    public boolean validate() {

        mNameEditText.setError(null);
        mEmailEditText.setError(null);
        mPasswordEditText.setError(null);
        mRetypePwdEditText.setError(null);
        mAddressAutoCompTextView.setError(null);
        mStreetAddEditText.setError(null);
        mStateEditText.setError(null);
        mZipCodeEditText.setError(null);
        mCountryEditText.setError(null);
        mHomePhoneEditText.setError(null);
        mCellPhoneEditText.setError(null);

        if (TextUtils.isEmpty(String.valueOf(mNameEditText.getText()))) {
            mNameEditText.requestFocus();
            mNameEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mDobEditText.getText()))) {
            Toast.makeText(activityHandle, getString(R.string.select_dob), Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mEmailEditText.getText()))) {
            mEmailEditText.requestFocus();
            mEmailEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (!TextUtils.isEmpty(mEmailEditText.getText().toString()) && !Utils.validateEmail(mEmailEditText.getText().toString())) {
            mEmailEditText.requestFocus();
            mEmailEditText.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mPasswordEditText.getText()))) {
            mPasswordEditText.requestFocus();
            mPasswordEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (!TextUtils.isEmpty(String.valueOf(mPasswordEditText.getText())) && !Utils.validatePassword(mPasswordEditText.getText().toString())) {
            mPasswordEditText.requestFocus();
            mPasswordEditText.setError(getString(R.string.password_must_be6_char));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mRetypePwdEditText.getText()))) {
            mRetypePwdEditText.requestFocus();
            mRetypePwdEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (!String.valueOf(mPasswordEditText.getText()).equals(String.valueOf(mRetypePwdEditText.getText()))) {
            Toast.makeText(activityHandle, getString(R.string.password_error), Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(String.valueOf(mAddressAutoCompTextView.getText()))) {
            mAddressAutoCompTextView.requestFocus();
            mAddressAutoCompTextView.setError(getString(R.string.error_field_required));
            return false;
        }

        if (TextUtils.isEmpty(String.valueOf(mHomePhoneEditText.getText()))) {
            mHomePhoneEditText.requestFocus();
            mHomePhoneEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mCellPhoneEditText.getText()))) {
            mCellPhoneEditText.requestFocus();
            mCellPhoneEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mProfessionAutoCompTextView.getText()))) {
            mProfessionAutoCompTextView.requestFocus();
            mProfessionAutoCompTextView.setError(getString(R.string.error_field_required));
            return false;
        }
        if (String.valueOf(mLanguageSpinner.getSelectedItem()).equalsIgnoreCase(getString(R.string.select_language))) {
            mLanguageSpinner.requestFocus();
            Toast.makeText(activityHandle, getString(R.string.select_language), Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:

                if (validate()) {
                    editMember();
                }
                //  paypalTest();
                break;
            case R.id.birthDatePicker:
                new DatePickerUtility(mDobEditText, getContext());
                break;
        }
    }

    private MemberRegModel getModel() {
        MemberRegModel memberRegModel = new MemberRegModel();

        memberRegModel.setType(Constants.MEMBER);
        memberRegModel.setMemberLoginId(mMemberDetails.getMemberLoginId());
        memberRegModel.setMember1Emailid1(String.valueOf(mEmailEditText.getText()));
        memberRegModel.setMemberName1(String.valueOf(mNameEditText.getText()));
        memberRegModel.setMember1Dob(String.valueOf(mDobEditText.getText()));
        memberRegModel.setMember1Password(String.valueOf(mPasswordEditText.getText()));
        memberRegModel.setMember1Apartment(String.valueOf(mAptEditText.getText()));
        memberRegModel.setMember1Address(String.valueOf(mAddressAutoCompTextView.getText()));
        memberRegModel.setMember1StreetNumber(String.valueOf(mStreetAddEditText.getText()));
        memberRegModel.setMember1Route(String.valueOf(mStreetAddEditText.getText()));
        memberRegModel.setMember1Locality(mLocality);
        memberRegModel.setMember1State(String.valueOf(mStateEditText.getText()));
        memberRegModel.setMember1PostalCode(String.valueOf(mZipCodeEditText.getText()));
        memberRegModel.setMember1Country(String.valueOf(mCountryEditText.getText()));
        memberRegModel.setMamber1Homephone(String.valueOf(mHomePhoneEditText.getText()));
        memberRegModel.setMamber1Cellphone(String.valueOf(mCellPhoneEditText.getText()));
        memberRegModel.setMamber1Profession(mProfessionMapping.get(String.valueOf(mProfessionAutoCompTextView.getText())));
        memberRegModel.setMamber1Lang(mLanguageMapping.get(String.valueOf(mLanguageSpinner.getSelectedItem())));
        memberRegModel.setMamber1Officephone(String.valueOf(mOfficePhoneEditText.getText()));

        return memberRegModel;
    }

    private void editMember() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.updating));

        MemberRegModel memberRegModel = getModel();

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().updateMember(memberRegModel);
        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                if (genericResponseModel.getStatus() == 1) {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, genericResponseModel.getMsg(), Toast.LENGTH_SHORT).show();
                    activityHandle.getSupportFragmentManager().popBackStack();
                } else {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, genericResponseModel.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mLanguageAdapter = null;

        mNameEditText = null;
        mDatePicker = null;
        mDobEditText = null;

        mEmailEditText = null;
        mPasswordEditText = null;
        mRetypePwdEditText = null;
        mAptEditText = null;
        mAddressAutoCompTextView = null;
        mStreetAddEditText = null;

        mStateEditText = null;
        mZipCodeEditText = null;
        mCountryEditText = null;
        mHomePhoneEditText = null;
        mCellPhoneEditText = null;
        mOfficePhoneEditText = null;
        mProfessionAutoCompTextView = null;
        mLanguageSpinner = null;

        mSubmitButton = null;
        activityHandle = null;

        mCenterData = null;
        professionList = null;
        languageArrayList = null;
        placeDetailsList = null;
        mAutoCompProfessionAdapter = null;
        mAutoPlaceCompleteAdapter = null;

        memberReg = null;
    }
}
