package ewl.chinmayala.Interface;

import android.support.v4.app.Fragment;

/**
 * Created by Akash.Singh on 2/3/2016.
 */
public interface IDialogClick {

    void OnClickListener(Fragment fragment);
}
