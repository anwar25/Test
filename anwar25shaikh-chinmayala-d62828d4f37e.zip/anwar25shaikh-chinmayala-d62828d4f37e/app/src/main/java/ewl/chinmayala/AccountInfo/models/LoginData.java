package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by  Anwar on 7/1/2016.
 */
public class LoginData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("session_id")
    @Expose
    private String sessionId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("emailid")
    @Expose
    private String emailid;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("old_password")
    @Expose
    private String oldPassword;
    @SerializedName("designation_master_id")
    @Expose
    private String designationMasterId;
    @SerializedName("create_date")
    @Expose
    private String createDate;
    @SerializedName("terminate_date")
    @Expose
    private Object terminateDate;
    @SerializedName("is_active")
    @Expose
    private String isActive;
    @SerializedName("other")
    @Expose
    private String other;
    @SerializedName("forgot_pass_code")
    @Expose
    private Object forgotPassCode;
    @SerializedName("member_type")
    @Expose
    private String memberType;
    @SerializedName("member_login_id")
    @Expose
    private String memberLoginId;
    @SerializedName("class_id")
    @Expose
    private Object classId;
    @SerializedName("section_id")
    @Expose
    private Object sectionId;
    @SerializedName("home_phone")
    @Expose
    private String homePhone;
    @SerializedName("cell_phone")
    @Expose
    private String cellPhone;
    @SerializedName("office_phone")
    @Expose
    private String officePhone;
    @SerializedName("occupation_master_id")
    @Expose
    private Object occupationMasterId;
    @SerializedName("mother_tongue")
    @Expose
    private String motherTongue;
    @SerializedName("appartment")
    @Expose
    private String appartment;
    @SerializedName("member_addresses")
    @Expose
    private String memberAddresses;
    @SerializedName("street_number")
    @Expose
    private String streetNumber;
    @SerializedName("route")
    @Expose
    private String route;
    @SerializedName("locality")
    @Expose
    private String locality;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("postal_code")
    @Expose
    private String postalCode;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("member_emails")
    @Expose
    private Object memberEmails;

    @SerializedName("tax_info")
    @Expose
    private Object taxInfo;
    @SerializedName("special_class_id")
    @Expose
    private Object specialClassId;
    @SerializedName("is_coordinator")
    @Expose
    private String isCoordinator;
    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("image")
    @Expose
    private String profileImage;

    @SerializedName("verify_code")
    @Expose
    private String verifyCode;

    @SerializedName("member_intrest")
    @Expose
    private List<String> memberIntrest = new ArrayList<String>();
    @SerializedName("center_name")
    @Expose
    private String centerName;

    @SerializedName("center_address")
    @Expose
    private String centerAddress;

    /**
     *
     * @return
     * The centerAddress
     */
    public String getCenterAddress() {
        return centerAddress;
    }

    /**
     *
     * @param centerAddress
     * The center_address
     */
    public void setCenterAddress(String centerAddress) {
        this.centerAddress = centerAddress;
    }

    /**
     *
     * @return
     * The memberIntrest
     */
    public List<String> getMemberIntrest() {
        return memberIntrest;
    }

    /**
     *
     * @param memberIntrest
     * The member_intrest
     */
    public void setMemberIntrest(List<String> memberIntrest) {
        this.memberIntrest = memberIntrest;
    }

    /**
     *
     * @return
     * The centerName
     */
    public String getCenterName() {
        return centerName;
    }

    /**
     *
     * @param centerName
     * The center_name
     */
    public void setCenterName(String centerName) {
        this.centerName = centerName;
    }
    /**
     *
     * @return
     * The verifyCode
     */
    public String getVerifyCode() {
        return verifyCode;
    }

    /**
     *
     * @param verifyCode
     * The verify_code
     */
    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }
    /**
     *
     * @return
     * The profileImage
     */
    public String getProfileImage() {
        return profileImage;
    }

    /**
     *
     * @param profileImage
     * The profile_image
     */
    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }
    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     *
     * @return
     * The sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     *
     * @param sessionId
     * The session_id
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     *
     * @return
     * The name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     * The name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     * The dob
     */
    public String getDob() {
        return dob;
    }

    /**
     *
     * @param dob
     * The dob
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     *
     * @return
     * The emailid
     */
    public String getEmailid() {
        return emailid;
    }

    /**
     *
     * @param emailid
     * The emailid
     */
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    /**
     *
     * @return
     * The password
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     * The password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return
     * The oldPassword
     */
    public String getOldPassword() {
        return oldPassword;
    }

    /**
     *
     * @param oldPassword
     * The old_password
     */
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    /**
     *
     * @return
     * The designationMasterId
     */
    public String getDesignationMasterId() {
        return designationMasterId;
    }

    /**
     *
     * @param designationMasterId
     * The designation_master_id
     */
    public void setDesignationMasterId(String designationMasterId) {
        this.designationMasterId = designationMasterId;
    }

    /**
     *
     * @return
     * The createDate
     */
    public String getCreateDate() {
        return createDate;
    }

    /**
     *
     * @param createDate
     * The create_date
     */
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    /**
     *
     * @return
     * The terminateDate
     */
    public Object getTerminateDate() {
        return terminateDate;
    }

    /**
     *
     * @param terminateDate
     * The terminate_date
     */
    public void setTerminateDate(Object terminateDate) {
        this.terminateDate = terminateDate;
    }

    /**
     *
     * @return
     * The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     *
     * @param isActive
     * The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    /**
     *
     * @return
     * The other
     */
    public String getOther() {
        return other;
    }

    /**
     *
     * @param other
     * The other
     */
    public void setOther(String other) {
        this.other = other;
    }

    /**
     *
     * @return
     * The forgotPassCode
     */
    public Object getForgotPassCode() {
        return forgotPassCode;
    }

    /**
     *
     * @param forgotPassCode
     * The forgot_pass_code
     */
    public void setForgotPassCode(Object forgotPassCode) {
        this.forgotPassCode = forgotPassCode;
    }

    /**
     *
     * @return
     * The memberType
     */
    public String getMemberType() {
        return memberType;
    }

    /**
     *
     * @param memberType
     * The member_type
     */
    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    /**
     *
     * @return
     * The memberLoginId
     */
    public String getMemberLoginId() {
        return memberLoginId;
    }

    /**
     *
     * @param memberLoginId
     * The member_login_id
     */
    public void setMemberLoginId(String memberLoginId) {
        this.memberLoginId = memberLoginId;
    }

    /**
     *
     * @return
     * The classId
     */
    public Object getClassId() {
        return classId;
    }

    /**
     *
     * @param classId
     * The class_id
     */
    public void setClassId(Object classId) {
        this.classId = classId;
    }

    /**
     *
     * @return
     * The sectionId
     */
    public Object getSectionId() {
        return sectionId;
    }

    /**
     *
     * @param sectionId
     * The section_id
     */
    public void setSectionId(Object sectionId) {
        this.sectionId = sectionId;
    }

    /**
     *
     * @return
     * The homePhone
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     *
     * @param homePhone
     * The home_phone
     */
    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    /**
     *
     * @return
     * The cellPhone
     */
    public String getCellPhone() {
        return cellPhone;
    }

    /**
     *
     * @param cellPhone
     * The cell_phone
     */
    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    /**
     *
     * @return
     * The officePhone
     */
    public String getOfficePhone() {
        return officePhone;
    }

    /**
     *
     * @param officePhone
     * The office_phone
     */
    public void setOfficePhone(String officePhone) {
        this.officePhone = officePhone;
    }

    /**
     *
     * @return
     * The occupationMasterId
     */
    public Object getOccupationMasterId() {
        return occupationMasterId;
    }

    /**
     *
     * @param occupationMasterId
     * The occupation_master_id
     */
    public void setOccupationMasterId(Object occupationMasterId) {
        this.occupationMasterId = occupationMasterId;
    }

    /**
     *
     * @return
     * The motherTongue
     */
    public String getMotherTongue() {
        return motherTongue;
    }

    /**
     *
     * @param motherTongue
     * The mother_tongue
     */
    public void setMotherTongue(String motherTongue) {
        this.motherTongue = motherTongue;
    }

    /**
     *
     * @return
     * The appartment
     */
    public String getAppartment() {
        return appartment;
    }

    /**
     *
     * @param appartment
     * The appartment
     */
    public void setAppartment(String appartment) {
        this.appartment = appartment;
    }

    /**
     *
     * @return
     * The memberAddresses
     */
    public String getMemberAddresses() {
        return memberAddresses;
    }

    /**
     *
     * @param memberAddresses
     * The member_addresses
     */
    public void setMemberAddresses(String memberAddresses) {
        this.memberAddresses = memberAddresses;
    }

    /**
     *
     * @return
     * The streetNumber
     */
    public String getStreetNumber() {
        return streetNumber;
    }

    /**
     *
     * @param streetNumber
     * The street_number
     */
    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    /**
     *
     * @return
     * The route
     */
    public String getRoute() {
        return route;
    }

    /**
     *
     * @param route
     * The route
     */
    public void setRoute(String route) {
        this.route = route;
    }

    /**
     *
     * @return
     * The locality
     */
    public String getLocality() {
        return locality;
    }

    /**
     *
     * @param locality
     * The locality
     */
    public void setLocality(String locality) {
        this.locality = locality;
    }

    /**
     *
     * @return
     * The state
     */
    public String getState() {
        return state;
    }

    /**
     *
     * @param state
     * The state
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     *
     * @return
     * The postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     *
     * @param postalCode
     * The postal_code
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     *
     * @return
     * The country
     */
    public String getCountry() {
        return country;
    }

    /**
     *
     * @param country
     * The country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     *
     * @return
     * The memberEmails
     */
    public Object getMemberEmails() {
        return memberEmails;
    }

    /**
     *
     * @param memberEmails
     * The member_emails
     */
    public void setMemberEmails(Object memberEmails) {
        this.memberEmails = memberEmails;
    }

    /**
     *
     * @return
     * The taxInfo
     */
    public Object getTaxInfo() {
        return taxInfo;
    }

    /**
     *
     * @param taxInfo
     * The tax_info
     */
    public void setTaxInfo(Object taxInfo) {
        this.taxInfo = taxInfo;
    }

    /**
     *
     * @return
     * The specialClassId
     */
    public Object getSpecialClassId() {
        return specialClassId;
    }

    /**
     *
     * @param specialClassId
     * The special_class_id
     */
    public void setSpecialClassId(Object specialClassId) {
        this.specialClassId = specialClassId;
    }

    /**
     *
     * @return
     * The isCoordinator
     */
    public String getIsCoordinator() {
        return isCoordinator;
    }

    /**
     *
     * @param isCoordinator
     * The is_coordinator
     */
    public void setIsCoordinator(String isCoordinator) {
        this.isCoordinator = isCoordinator;
    }

    /**
     *
     * @return
     * The status
     */
    public String getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(String status) {
        this.status = status;
    }
}
