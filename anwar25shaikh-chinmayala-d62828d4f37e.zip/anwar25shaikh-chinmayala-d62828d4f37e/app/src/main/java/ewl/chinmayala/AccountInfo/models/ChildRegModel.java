package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar Shaikh on 7/20/2016.
 */
public class ChildRegModel {
    @SerializedName("child_emailid")
    @Expose
    private String childEmailid;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("member_center_id")
    @Expose
    private String memberCenterId;
    @SerializedName("member_session_id")
    @Expose
    private String memberSessionId;
    @SerializedName("child_name")
    @Expose
    private String childName;
    @SerializedName("child_dob")
    @Expose
    private String childDob;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("child_gender")
    @Expose
    private String childGender;
    @SerializedName("child_lang")
    @Expose
    private String childLang;
    @SerializedName("child_homephone")
    @Expose
    private String childHomephone;
    @SerializedName("child_cellphone")
    @Expose
    private String childCellphone;
    @SerializedName("child_current_school")
    @Expose
    private String childCurrentSchool;
    @SerializedName("district_name")
    @Expose
    private String districtName;
    @SerializedName("child_school_city")
    @Expose
    private String childSchoolCity;
    @SerializedName("child_class_id")
    @Expose
    private String childClassId;
    @SerializedName("child_grade_id")
    @Expose
    private String childGradeId;

    private int age ;


    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("child_id")
    @Expose
    private String childId;
    @SerializedName("member_login_id")
    @Expose
    private String memberLoginId;

    /**
     *
     * @return
     * The type
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     * The type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     *
     * @return
     * The childId
     */
    public String getChildId() {
        return childId;
    }

    /**
     *
     * @param childId
     * The child_id
     */
    public void setChildId(String childId) {
        this.childId = childId;
    }

    /**
     *
     * @return
     * The memberLoginId
     */
    public String getMemberLoginId() {
        return memberLoginId;
    }

    /**
     *
     * @param memberLoginId
     * The member_login_id
     */
    public void setMemberLoginId(String memberLoginId) {
        this.memberLoginId = memberLoginId;
    }



    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    /**
     *
     * @return
     * The childEmailid
     */
    public String getChildEmailid() {
        return childEmailid;
    }

    /**
     *
     * @param childEmailid
     * The child_emailid
     */
    public void setChildEmailid(String childEmailid) {
        this.childEmailid = childEmailid;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The memberCenterId
     */
    public String getMemberCenterId() {
        return memberCenterId;
    }

    /**
     *
     * @param memberCenterId
     * The member_center_id
     */
    public void setMemberCenterId(String memberCenterId) {
        this.memberCenterId = memberCenterId;
    }

    /**
     *
     * @return
     * The memberSessionId
     */
    public String getMemberSessionId() {
        return memberSessionId;
    }

    /**
     *
     * @param memberSessionId
     * The member_session_id
     */
    public void setMemberSessionId(String memberSessionId) {
        this.memberSessionId = memberSessionId;
    }

    /**
     *
     * @return
     * The childName
     */
    public String getChildName() {
        return childName;
    }

    /**
     *
     * @param childName
     * The child_name
     */
    public void setChildName(String childName) {
        this.childName = childName;
    }

    /**
     *
     * @return
     * The childDob
     */
    public String getChildDob() {
        return childDob;
    }

    /**
     *
     * @param childDob
     * The child_dob
     */
    public void setChildDob(String childDob) {
        this.childDob = childDob;
    }

    /**
     *
     * @return
     * The password
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     * The password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return
     * The childGender
     */
    public String getChildGender() {
        return childGender;
    }

    /**
     *
     * @param childGender
     * The child_gender
     */
    public void setChildGender(String childGender) {
        this.childGender = childGender;
    }

    /**
     *
     * @return
     * The childLang
     */
    public String getChildLang() {
        return childLang;
    }

    /**
     *
     * @param childLang
     * The child_lang
     */
    public void setChildLang(String childLang) {
        this.childLang = childLang;
    }

    /**
     *
     * @return
     * The childHomephone
     */
    public String getChildHomephone() {
        return childHomephone;
    }

    /**
     *
     * @param childHomephone
     * The child_homephone
     */
    public void setChildHomephone(String childHomephone) {
        this.childHomephone = childHomephone;
    }

    /**
     *
     * @return
     * The childCellphone
     */
    public String getChildCellphone() {
        return childCellphone;
    }

    /**
     *
     * @param childCellphone
     * The child_cellphone
     */
    public void setChildCellphone(String childCellphone) {
        this.childCellphone = childCellphone;
    }

    /**
     *
     * @return
     * The childCurrentSchool
     */
    public String getChildCurrentSchool() {
        return childCurrentSchool;
    }

    /**
     *
     * @param childCurrentSchool
     * The child_current_school
     */
    public void setChildCurrentSchool(String childCurrentSchool) {
        this.childCurrentSchool = childCurrentSchool;
    }

    /**
     *
     * @return
     * The districtName
     */
    public String getDistrictName() {
        return districtName;
    }

    /**
     *
     * @param districtName
     * The district_name
     */
    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    /**
     *
     * @return
     * The childSchoolCity
     */
    public String getChildSchoolCity() {
        return childSchoolCity;
    }

    /**
     *
     * @param childSchoolCity
     * The child_school_city
     */
    public void setChildSchoolCity(String childSchoolCity) {
        this.childSchoolCity = childSchoolCity;
    }

    /**
     *
     * @return
     * The childClassId
     */
    public String getChildClassId() {
        return childClassId;
    }

    /**
     *
     * @param childClassId
     * The child_class_id
     */
    public void setChildClassId(String childClassId) {
        this.childClassId = childClassId;
    }

    /**
     *
     * @return
     * The childGradeId
     */
    public String getChildGradeId() {
        return childGradeId;
    }

    /**
     *
     * @param childGradeId
     * The child_grade_id
     */
    public void setChildGradeId(String childGradeId) {
        this.childGradeId = childGradeId;
    }
}
