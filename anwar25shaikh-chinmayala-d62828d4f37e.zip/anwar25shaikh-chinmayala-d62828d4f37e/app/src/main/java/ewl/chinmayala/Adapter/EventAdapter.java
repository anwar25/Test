package ewl.chinmayala.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import ewl.chinmayala.Entity.Event;
import ewl.chinmayala.R;
import ewl.chinmayala.constants.Constants;

/**
 * Created by Akash.Singh on 02/10/16.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.RecyclerViewHolder> {
  //  ImageLoader imageLoader;
    List<Event> mItems;
    Context context;
    public EventAdapter(Context context, ArrayList<Event> mItems) {
        super();
        this.mItems = mItems;
        this.context = context;
     //   imageLoader =  new ImageLoader(context);
    }

    @Override
    public int getItemCount() {
        return (null != mItems ? mItems.size() : 0);

    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        final Event nature = mItems.get(position);
        holder.tvSpecies.setText(nature.getEventTitle());
        if(!TextUtils.isEmpty(nature.getResource()))
            Glide.with(this.context)
                    .load(nature.getResource())
                    .error(R.drawable.default_image) // will be displayed if the image cannot be loaded
                    .crossFade(Constants.IMAGE_ANIM_DURATION)
                    .into(holder.imgThumbnail);
            //imageLoader.DisplayImage(nature.getResource(),holder.imgThumbnail);
        holder.imgThumbnail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });


    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        // This method will inflate the custom layout and return as viewholder
        LayoutInflater mInflater = LayoutInflater.from(viewGroup.getContext());

        ViewGroup mainGroup = (ViewGroup) mInflater.inflate(
                R.layout.event_grid_item, viewGroup, false);
        RecyclerViewHolder listHolder = new RecyclerViewHolder(mainGroup);
        return listHolder;

    }

    class RecyclerViewHolder extends RecyclerView.ViewHolder{

        public ImageView imgThumbnail;
        public TextView tvSpecies;

        public RecyclerViewHolder(View itemView) {
            super(itemView);
            imgThumbnail = (ImageView)itemView.findViewById(R.id.img_thumbnail);
            tvSpecies = (TextView)itemView.findViewById(R.id.tv_species);

        }
    }

}
