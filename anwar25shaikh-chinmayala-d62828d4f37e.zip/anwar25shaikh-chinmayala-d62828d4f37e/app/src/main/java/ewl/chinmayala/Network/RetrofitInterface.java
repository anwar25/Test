package ewl.chinmayala.Network;

import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.MemberDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.PaymentDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.TrustDataList;
import ewl.chinmayala.AccountInfo.models.BvAaratiFeesRes;
import ewl.chinmayala.AccountInfo.models.BvClassListResModel;
import ewl.chinmayala.AccountInfo.models.CenterListResponse;
import ewl.chinmayala.AccountInfo.models.ChildRegModel;
import ewl.chinmayala.AccountInfo.models.ForgotPasReq;
import ewl.chinmayala.AccountInfo.models.ForgotPasRes;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.AccountInfo.models.ImageUploadRes;
import ewl.chinmayala.AccountInfo.models.LanguageResponseModel;
import ewl.chinmayala.AccountInfo.models.LoginResponse;
import ewl.chinmayala.AccountInfo.models.MagazineListRes;
import ewl.chinmayala.AccountInfo.models.MemberInterestList;
import ewl.chinmayala.AccountInfo.models.MemberRegModel;
import ewl.chinmayala.AccountInfo.models.PaymentReqModel;
import ewl.chinmayala.AccountInfo.models.PaymentResModel;
import ewl.chinmayala.AccountInfo.models.PredictionResponse;
import ewl.chinmayala.AccountInfo.models.PrevAmountPaidRes;
import ewl.chinmayala.AccountInfo.models.ProfessionListResponse;
import ewl.chinmayala.AccountInfo.models.SchoolGradeResModel;
import ewl.chinmayala.AccountInfo.models.SessionListData;
import ewl.chinmayala.AccountInfo.models.TrustRegModel;
import ewl.chinmayala.constants.Urls;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

/**
 * Created by Anwar on 5/21/2016.
 */
public interface RetrofitInterface {

    @POST(Urls.LOGIN_API)
    Call<LoginResponse> login(@Body GenericRequestModel genericRequestModel);

    @GET(Urls.CENTER_LIST_API)
    Call<CenterListResponse> getCenterList();

    @GET(Urls.PROFESSION_LIST_API)
    Call<ProfessionListResponse> getProfessionList();

    @POST(Urls.MOTHER_TONGUE_API)
    Call<LanguageResponseModel> getLanguages(@Body GenericRequestModel genericRequestModel);

    @GET(Urls.GET_ADRESS_API)
    Call<ResponseBody> getAddress(@Query("input") String adress , @Query("key") String key );

    @GET(Urls.GET_PLACE_DETAILS)
    Call<PredictionResponse> getPlaceDetails(@Query("placeid") String placeId , @Query("key") String key );

    @POST(Urls.REGISTER_PRIMARY_MEMBER_API)
    Call<LoginResponse> registerPrimaryMember(@Body MemberRegModel memberRegModel ) ;

    @POST(Urls.REGISTER_SECONDARY_MEMBER_API)
    Call<LoginResponse> registerSecondaryMember(@Body MemberRegModel memberRegModel ) ;

    @POST(Urls.REGISTER_TRUST_API)
    Call<GenericResponseModel> registerTrust(@Body TrustRegModel trustRequestModel);

    @POST(Urls.REGISTER_CHILD_API)
    Call<GenericResponseModel> registerChild(@Body ChildRegModel childRegModel);

    @GET(Urls.GET_SCHOOL_GRADE_API)
    Call<SchoolGradeResModel> getSchoolGradeList();

    @POST(Urls.GET_BV_CLASS_LIST_API)
    Call<BvClassListResModel> getBvClassList(@Body GenericRequestModel genericRequestModel);

    @GET(Urls.GET_MEMBER_INTEREST_LIST)
    Call<MemberInterestList> getMemberInterestList();

    @POST(Urls.GET_SESSION_LIST_API)
    Call<SessionListData> getSessionList(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.FORGOT_PASSWORD_API)
    Call<ForgotPasRes> forgotPassword(@Body ForgotPasReq forgotPasReq);

    @Multipart
    @POST(Urls.UPLOAD_PROFILE_PIC_API)
    Call<ImageUploadRes> uploadProfileImage(@Part("member_login_id") RequestBody memberId ,
                                            @Part MultipartBody.Part imageFile);

    @POST(Urls.GET_MAGAZINES_API)
    Call<MagazineListRes> getMagazinesList(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.GET_ALL_MEMBER_LIST)
    Call<MemberDataList> getAllMemberList(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.GET_ALL_CHILD_LIST)
    Call<ChildDataList> getAllChildList(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.GET_ALL_TRUST_LIST)
    Call<TrustDataList> getAllTrustList(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.GET_ALL_PAYMENT_LIST)
    Call<PaymentDataList> getAllPaymentList(@Body GenericRequestModel genericRequestModel);


    @POST(Urls.DELETE_ITEM)
    Call<GenericResponseModel> deleteItem(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.UPDATE_ITEM)
    Call<GenericResponseModel> updateTrust(@Body TrustRegModel trustRequestModel);

    @POST(Urls.UPDATE_ITEM)
    Call<GenericResponseModel> updateChild(@Body ChildRegModel childRegModel);

    @POST(Urls.UPDATE_ITEM)
    Call<GenericResponseModel> updateMember(@Body MemberRegModel memberRegModel);

    @POST(Urls.PREVIOUS_PAYMENT_API)
    Call<PrevAmountPaidRes> getPreviousPayment(@Body GenericRequestModel genericRequestModel);

    @POST(Urls.PAYMENT_API)
    Call<PaymentResModel> doPayment(@Body PaymentReqModel paymentReqModel);

    @POST(Urls.BV_AARATI_FEES_API)
    Call<BvAaratiFeesRes> getBvAndAaratiFees(@Body GenericRequestModel genericRequestModel);
}
