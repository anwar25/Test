package ewl.chinmayala.AccountInfo.fragments.edit;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildModel;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.AlertDialogUtility;
import ewl.chinmayala.Utils.AlertMagnatic;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar on 7/28/2016.
 */
public class ChildDetailPage extends Fragment implements View.OnClickListener{

    private ChildModel mChildDetails;
    private ImageButton mDeleteChildButton;
    private ImageButton mEditChildButton;
    private HomeActivity activityHandle;

    private  CustomTextView mChildNameTextView ;
    private  CustomTextView mDobTextView ;
    private  CustomTextView mLanguageTextView ;
    private  CustomTextView mCenterNameTextView ;
    private  CustomTextView mSessionTextView ;
    private  CustomTextView mBvClassTextView ;
    private  CustomTextView mSectionTextView ;
    private  CustomTextView mShrutiTextView ;
    private  CustomTextView mPaymentTextView ;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.child_detail_page_layout, container, false);
        if(getArguments() != null){
            mChildDetails = (ChildModel)getArguments().getSerializable(Constants.CHILD_DETAILS);

            mChildNameTextView = ((CustomTextView)rootView.findViewById(R.id.childNameTextView));
            mChildNameTextView.setText(mChildDetails.getName());
            mDobTextView = ((CustomTextView)rootView.findViewById(R.id.dobTextView));
            mDobTextView.setText(mChildDetails.getDob());
            mLanguageTextView = ((CustomTextView)rootView.findViewById(R.id.languageTextView));
            mLanguageTextView.setText(mChildDetails.getLangName());
            mCenterNameTextView = ((CustomTextView)rootView.findViewById(R.id.centerNameTextView));
            mCenterNameTextView.setText(mChildDetails.getCenterName());
            mSessionTextView = ((CustomTextView)rootView.findViewById(R.id.sessionTextView));
            mSessionTextView.setText(mChildDetails.getSessionName()+"( "+mChildDetails.getSessionStart()+" - "+mChildDetails.getSessionEnd()+" )");
            mBvClassTextView = ((CustomTextView)rootView.findViewById(R.id.bvClassTextView));
            mBvClassTextView.setText(mChildDetails.getClassName());

            String sectionName = String.valueOf(mChildDetails.getSectionName()) ;
            if(! sectionName.equals("null") || TextUtils.isEmpty(sectionName)){
                mSectionTextView = ((CustomTextView)rootView.findViewById(R.id.sectionTextView));
                mSectionTextView.setText(String.valueOf(mChildDetails.getSectionName()));
            }
            //((CustomTextView)rootView.findViewById(R.id.roomTextView)).setText(String.valueOf(mChildDetails.roo()));

            mShrutiTextView = ((CustomTextView)rootView.findViewById(R.id.shrutiTextView));
            mShrutiTextView.setText(mChildDetails.getIsShrutiClass().equalsIgnoreCase("0") ? "No" : "Yes");

            mPaymentTextView = ((CustomTextView)rootView.findViewById(R.id.paymentStatusTextView));
            mPaymentTextView.setText(mChildDetails.getStatusName());

            mDeleteChildButton = (ImageButton)rootView.findViewById(R.id.deleteChildButton);
            mEditChildButton = (ImageButton)rootView.findViewById(R.id.editChildButton);
            mDeleteChildButton.setOnClickListener(this);
            mEditChildButton.setOnClickListener(this);

        }
        return rootView;
    }

    public void setData(ChildModel childModel) {
        if(isAdded()){
            this.mChildDetails = childModel ;
            mChildNameTextView.setText(mChildDetails.getName());
            mDobTextView.setText(mChildDetails.getDob());
            mLanguageTextView.setText(mChildDetails.getLangName());
            mCenterNameTextView.setText(mChildDetails.getCenterName());
            mSessionTextView.setText(mChildDetails.getSessionName()+"( "+mChildDetails.getSessionStart()+" - "+mChildDetails.getSessionEnd()+" )");
            mBvClassTextView.setText(mChildDetails.getClassName());

            String sectionName = String.valueOf(mChildDetails.getSectionName()) ;
            if(! sectionName.equals("null") || TextUtils.isEmpty(sectionName)){
                mSectionTextView.setText(String.valueOf(mChildDetails.getSectionName()));
            }
            //((CustomTextView)rootView.findViewById(R.id.roomTextView)).setText(String.valueOf(mChildDetails.roo()));
            mShrutiTextView.setText(mChildDetails.getIsShrutiClass().equalsIgnoreCase("0") ? "No" : "Yes");
            mPaymentTextView.setText(mChildDetails.getStatusName());

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.editChildButton :
                EditChildFragment editChildFragment  = new EditChildFragment() ;
                Bundle bundle = new Bundle( );
                bundle.putSerializable(Constants.CHILD_DETAILS,mChildDetails);
                editChildFragment.setArguments(bundle);
                activityHandle.onReplaceFragment(editChildFragment,true);
                break;
            case R.id.deleteChildButton :
                AlertDialogUtility.showDeleteDialog(activityHandle, getString(R.string.delete_child),
                        getString(R.string.delete_child_msg),
                        getString(R.string.yes),
                        getString(R.string.no),
                        false,
                        new AlertMagnatic() {
                            @Override
                            public void onButtonClicked(boolean yes) {
                                if(yes){
                                    deleteChild();
                                }
                            }
                        });
                break;
        }
    }

    private void deleteChild() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.deleting));

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setId(mChildDetails.getId());
        genericRequestModel.setType(Constants.CHILD);

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().deleteItem(genericRequestModel);

        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                activityHandle.hideProgress();
                if (genericResponseModel != null && genericResponseModel.getStatus() == 1) {
                    //store user response in session
                    Toast.makeText(activityHandle,genericResponseModel.getMsg(), Toast.LENGTH_LONG).show();
                    ((ChildDetailsParentFragment) getParentFragment()).getChildList();
                } else {
                    Toast.makeText(activityHandle,genericResponseModel.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity){
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mChildDetails = null ;
        mDeleteChildButton= null ;
        mEditChildButton = null ;
        mChildNameTextView = null ;
        mDobTextView = null ;
        mLanguageTextView = null ;
        mCenterNameTextView = null ;
        mSessionTextView = null ;
        mBvClassTextView = null ;
        mSectionTextView = null ;
        mShrutiTextView = null ;
        mPaymentTextView = null ;
    }


}
