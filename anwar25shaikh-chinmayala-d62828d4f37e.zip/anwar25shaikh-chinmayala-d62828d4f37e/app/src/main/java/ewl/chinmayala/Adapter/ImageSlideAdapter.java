package ewl.chinmayala.Adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import ewl.chinmayala.R;
import ewl.chinmayala.constants.Constants;

/**
 * Created by Akash.Singh on 9/8/2015.
 */
public class ImageSlideAdapter extends PagerAdapter {
   // ImageLoader imageLoader ;
    Context activity;
    ArrayList<String> carouselImageList =  new ArrayList<String>();

    public ImageSlideAdapter(Context activity, ArrayList<String> carouselImageList) {
        this.activity = activity;
        this.carouselImageList = carouselImageList;
       // imageLoader = new ImageLoader(activity);
    }


    @Override
    public int getCount() {
        return carouselImageList.size();
    }

    @Override
    public View instantiateItem(ViewGroup container, final int position) {
        LayoutInflater inflater = (LayoutInflater) activity
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.content_image_header_view, container, false);

        ImageView mImageView = (ImageView) view
                .findViewById(R.id.image_display);
        if (!TextUtils.isEmpty(carouselImageList.get(position))){
            Glide.with(mImageView.getContext())
                    .load(carouselImageList.get(position))
                //    .thumbnail(0.5f)
                //    .override(75, 75)
                  //  .diskCacheStrategy(DiskCacheStrategy.ALL)
                   .error(R.drawable.default_image) // will be displayed if the image cannot be loaded
                   .crossFade(Constants.IMAGE_ANIM_DURATION)
                   .into(mImageView);
            //imageLoader.DisplayImage(carouselImageList.get(position), mImageView);
        }

        else
            mImageView.setImageResource(R.drawable.default_image);

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }


}
