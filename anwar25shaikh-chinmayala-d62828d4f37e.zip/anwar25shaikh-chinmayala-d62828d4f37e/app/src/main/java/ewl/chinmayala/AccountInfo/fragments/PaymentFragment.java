package ewl.chinmayala.AccountInfo.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.paypal.android.sdk.payments.PayPalConfiguration;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PaymentConfirmation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildModel;
import ewl.chinmayala.AccountInfo.fragments.edit.models.MemberDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.MemberModel;
import ewl.chinmayala.AccountInfo.models.BvAaratiFeesRes;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.AccountInfo.models.LanguageData;
import ewl.chinmayala.AccountInfo.models.LanguageResponseModel;
import ewl.chinmayala.AccountInfo.models.LoginData;
import ewl.chinmayala.AccountInfo.models.Magazine;
import ewl.chinmayala.AccountInfo.models.MagazineListRes;
import ewl.chinmayala.AccountInfo.models.MagazineModel;
import ewl.chinmayala.AccountInfo.models.MemberInterest;
import ewl.chinmayala.AccountInfo.models.MemberInterestList;
import ewl.chinmayala.AccountInfo.models.MemberInterestModel;
import ewl.chinmayala.AccountInfo.models.PaymentReqModel;
import ewl.chinmayala.AccountInfo.models.PaymentResModel;
import ewl.chinmayala.AccountInfo.models.PrevAmountPaidRes;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.UI.CustomCheckBox;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.UI.CustomSpinnerAdapter;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.AlertDialogUtility;
import ewl.chinmayala.Utils.AlertMagnatic;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.Utils.Utils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar  on 2/11/2016.
 */
public class PaymentFragment extends BaseFragment implements View.OnClickListener {

    private static final String TAG = PaymentFragment.class.getSimpleName();
    private CustomEditText mCenterNameText;
    private CustomEditText mCenterAddressText;
    private HomeActivity activityHandle;

    private LinearLayout mMemberInfoLayout;
    private LinearLayout mChildInfoLayout;
    private LinearLayout mMagazineInfoLayout;

    private CustomAppCompatButton mPaypalPaymentButton;
    private  MemberInterestList mMemberInterestList ;
    private Spinner mPaymentSpinner;
    private ArrayList<String> paymentMethodList;
    private ArrayAdapter mPaymentAdapter;

    private CustomCheckBox mConfirmCheckbox ;

    private LoginData loggedInMemberDetails ;

    private  List<ChildModel> mChildModels;
    private MagazineModel magazineList;

    private TextView mAaratiFeesTextView ;
    private TextView mBvFeesTextView ;
    private TextView mMagazineFeesTextView ;
    private TextView mTotalFeesTextView ;
    private TextView mTotalOnlineFeesTextView ;

    private HashMap<String, String> mLanguageMapping;
    private CustomSpinnerAdapter mLanguageAdapter;
    private ArrayList<String> languageArrayList;
    private List<MemberModel> mMemberModels;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // View view = inflater.inflate(R.layout.content_bv_registration_form_screen,container,false);
        View view = inflater.inflate(R.layout.content_payment_form_screen, container, false);
        activityHandle.setToolbarInitialization(this, getString(R.string.bv_registration));
        mapControls(view);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Paypal code
        startPaypalService();
        activityHandle.showProgress(getString(R.string.loading_msg));
        Gson gson = new Gson();
        String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        loggedInMemberDetails = gson.fromJson(member1DetailsString, LoginData.class);
        new DownloadData().execute(loggedInMemberDetails.getFamilyId());

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;

         //   Logger.e("anwar", "fragment loading");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Override
    public void mapControls(View rootView) {
        mPaymentSpinner = (Spinner) rootView.findViewById(R.id.paymentSpinner);
        paymentMethodList = new ArrayList<String>();
        paymentMethodList.add(getString(R.string.payal_credit_card));
        paymentMethodList.add(getString(R.string.cash));
        paymentMethodList.add(getString(R.string.check));
        mPaymentAdapter = new ArrayAdapter<String>(activityHandle, R.layout.spinner_item_layout, paymentMethodList);
        // Drop down layout style - list view with radio button
        mPaymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mPaymentSpinner.setAdapter(mPaymentAdapter);

        mCenterNameText = (CustomEditText) rootView.findViewById(R.id.centerNameTextView);
        mCenterAddressText = (CustomEditText) rootView.findViewById(R.id.centerAddressTextView);
       // String centerString = activityHandle.getSessionManager().getString(Constants.CENTER_INFO);
        /*Gson gson = new Gson();
        CenterData centerData = gson.fromJson(centerString, CenterData.class);
        if(null != centerData){
            mCenterAddressText.setText(centerData.getCenterAddress());
            mCenterNameText.setText(centerData.getCenterName());
        }*/

        mMemberInfoLayout = (LinearLayout) rootView.findViewById(R.id.memberInfoLayout);
        mPaypalPaymentButton = (CustomAppCompatButton) rootView.findViewById(R.id.payNowButton);
        mPaypalPaymentButton.setOnClickListener(this);
        mChildInfoLayout = (LinearLayout) rootView.findViewById(R.id.childInfoLayout);

        mConfirmCheckbox = (CustomCheckBox) rootView.findViewById(R.id.confirmRegCheckbox) ;
        mConfirmCheckbox.setOnClickListener(this);

        mMagazineInfoLayout = (LinearLayout)rootView.findViewById(R.id.magazineLayout);
       // Logger.e("anwar", "fragment oncreate start");

       /* TrustAdapter trustAdapter = new TrustAdapter();
        ArrayList<TrustRegModel> trustRegModelArrayList = trustAdapter.getAll();*/
      //  Logger.e("anwar", "fragment oncreate end ");
        mAaratiFeesTextView = (TextView) rootView.findViewById(R.id.aaratiFees);
        mBvFeesTextView = (TextView) rootView.findViewById(R.id.bvFees);
        mMagazineFeesTextView = (TextView) rootView.findViewById(R.id.magazineFees);
        mTotalFeesTextView = (TextView) rootView.findViewById(R.id.totalFees);
        mTotalOnlineFeesTextView = (TextView) rootView.findViewById(R.id.totalOnlineFees) ;

        languageArrayList = new ArrayList<String>();
        mLanguageAdapter = new CustomSpinnerAdapter(activityHandle, R.layout.spinner_item_layout, languageArrayList);
        // Drop down layout style - list view with radio button
        mLanguageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
    }

    @Override
    public boolean validate() {

        for(ChildModel childModel : mChildModels){
           try{
               int filledSeat = Integer.parseInt(childModel.getFillSeat());
               int totalSeat = Integer.parseInt(childModel.getTotalSeat());
               if((totalSeat - filledSeat) == 0){
                   Toast.makeText(activityHandle,getString(R.string.no_seat_available), Toast.LENGTH_SHORT).show();
                   return  false ;
               }
           }catch (NumberFormatException e){
               Logger.e("PaymentFragment",":"+e.getMessage());
               Toast.makeText(activityHandle,getString(R.string.no_seat_available), Toast.LENGTH_SHORT).show();
               return  false ;
           }
        }
        if(!((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.balavihar)).isChecked() &&
                !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked()){
            Toast.makeText(activityHandle,getString(R.string.pls_select_mand_magazine), Toast.LENGTH_SHORT).show();
            return false ;
        }
        if(!isMazSelectionValid){
            Toast.makeText(activityHandle,getString(R.string.invalid_mag_selection), Toast.LENGTH_SHORT).show();
            return  false ;
        }
        if(!mConfirmCheckbox.isChecked()){
            Toast.makeText(activityHandle,getString(R.string.confirm_the_registration), Toast.LENGTH_SHORT).show();
            return  false ;
        }
        return true;
    }

    ////////////////////////////////PAYPAL CODE ///////////////////////////
    private void doPaypalPayment() {
        PayPalPayment payment = new PayPalPayment(new BigDecimal(mTotalOnlineFees), getString(R.string.currency_USD)
                , getString(R.string.balvihar_payment),
                PayPalPayment.PAYMENT_INTENT_SALE);
        Intent intent = new Intent(getContext(), PaymentActivity.class);
        // send the same configuration for restart resiliency
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);
        intent.putExtra(PaymentActivity.EXTRA_PAYMENT, payment);
        startActivityForResult(intent, 0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            PaymentConfirmation confirm = data.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION);
            if (confirm != null) {
                try {

                    JSONObject paymentObject = confirm.toJSONObject();
                    if(paymentObject.has(Constants.PAYPAL_RESPONSE)){
                        JSONObject response = (JSONObject) paymentObject.get(Constants.PAYPAL_RESPONSE);
                        String paymentState = (String)response.get(Constants.PAYMENT_STATE);
                        if(paymentState.equalsIgnoreCase(Constants.STATE_APPROVED)){
                            PaymentReqModel paymentRegModel =  getModel();
                            paymentRegModel.setPaymentMethod(Constants.PAY_PAYPAL);
                            paymentRegModel.setTransactionId((String) response.get(Constants.PAY_ID));
                            paymentRegModel.setAck(Constants.SUCESS);
                            sendPaymentDetails(paymentRegModel);
                            Toast.makeText(activityHandle, getString(R.string.payment_done), Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(activityHandle, getString(R.string.payment_failed), Toast.LENGTH_SHORT).show();
                    }
                    Log.i("paymentExample", confirm.toJSONObject().toString(4));

                    // TODO: send 'confirm' to your server for verification.
                    // see https://developer.paypal.com/webapps/developer/docs/integration/mobile/verify-mobile-payment/
                    // for more details.
                } catch (JSONException e) {
                    Toast.makeText(activityHandle, getString(R.string.payment_failed), Toast.LENGTH_SHORT).show();
                    Log.e("paymentExample", "an extremely unlikely failure occurred: ", e);
                }
            }
        } else if (resultCode == Activity.RESULT_CANCELED) {
            Log.i("paymentExample", "The user canceled.");
        } else if (resultCode == PaymentActivity.RESULT_EXTRAS_INVALID) {
            Log.i("paymentExample", "An invalid Payment or PayPalConfiguration was submitted. Please see the docs.");
        }
    }

    private void sendPaymentDetails(final PaymentReqModel paymentRegModel) {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            activityHandle.hideProgress();
            return;
        }
        activityHandle.showProgress(getString(R.string.processing_please_wait));
        Call<PaymentResModel> call = RetrofitInstance.getInstance().doPayment(paymentRegModel);
        call.enqueue(new Callback<PaymentResModel>() {
            @Override
            public void onResponse(Call<PaymentResModel> call, Response<PaymentResModel> response) {
                activityHandle.hideProgress();
                PaymentResModel paymentResModel = response.body();
                if(paymentResModel != null && paymentResModel.getStatus() == 1){
                   // Toast.makeText(activityHandle, paymentResModel.getMsg(), Toast.LENGTH_LONG).show();
                    if(!paymentRegModel.getPaymentMethod().equalsIgnoreCase(getString(R.string.payal_credit_card))){
                        showPaymentReviewDialog(Constants.PAY_CASH);
                    }
                    //activityHandle.redirectDashboard();
                }else{
                    Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                }

            }
            @Override
            public void onFailure(Call<PaymentResModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });

    }


    private class DownloadData extends AsyncTask<String,Void,  HashMap<String, Object>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
                activityHandle.showNetworkErrorToast();
                activityHandle.hideProgress();
                return;
            }
        }

        @Override
        protected  HashMap<String, Object> doInBackground(String... params) {
            HashMap<String, Object> resultMap = new HashMap<String, Object>();
            Call<MemberInterestList> memberInterestListCall = RetrofitInstance.getInstance().getMemberInterestList();

            GenericRequestModel genericRequestModel = new GenericRequestModel();
            genericRequestModel.setFamilyId(params[0]);
            genericRequestModel.setCenterId(Integer.parseInt(loggedInMemberDetails.getCenterId()));
            Call<MemberDataList> memberList = RetrofitInstance.getInstance().getAllMemberList(genericRequestModel);
            Call<ChildDataList> listChildDataCall = RetrofitInstance.getInstance().getAllChildList(genericRequestModel);
            Call<MagazineListRes> magazineListResCall = RetrofitInstance.getInstance().getMagazinesList(genericRequestModel);
            Call<LanguageResponseModel> languageResponseModelCall = RetrofitInstance.getInstance().getLanguages(genericRequestModel);
            Call<PrevAmountPaidRes> prePaymentCall = RetrofitInstance.getInstance().getPreviousPayment(genericRequestModel);
            Call<BvAaratiFeesRes> bvAaratiFeesResCall = RetrofitInstance.getInstance().getBvAndAaratiFees(genericRequestModel);
            try {
                Response<MemberInterestList> memberInterestList = memberInterestListCall.execute();
                resultMap.put(Constants.MEM_INTEREST_LIST,memberInterestList.body());

                Response<MemberDataList> listMemberDataResponse = memberList.execute() ;
                resultMap.put(Constants.MEMBER_LIST,listMemberDataResponse.body());

                Response<ChildDataList> listChildDataResponse = listChildDataCall.execute() ;
                resultMap.put(Constants.CHILD_LIST,listChildDataResponse.body());

                Response<MagazineListRes> magazineListResResponse = magazineListResCall.execute();
                resultMap.put(Constants.MAGAZINE_LIST,magazineListResResponse.body());

                Response<LanguageResponseModel> languageResponseModelResponse = languageResponseModelCall.execute();
                resultMap.put(Constants.LANG_OBJ,languageResponseModelResponse.body());

                Response<PrevAmountPaidRes> prevAmountPaidResResponse = prePaymentCall.execute();
                PrevAmountPaidRes prevAmountPaidRes = prevAmountPaidResResponse.body();
                if(prevAmountPaidRes.getStatus() == 1)
                    mPrevAmountPaid = prevAmountPaidRes.getUserdata();

                Response<BvAaratiFeesRes> bvAaratiFeesResResponse = bvAaratiFeesResCall.execute();
                BvAaratiFeesRes bvAaratiFeesRes = bvAaratiFeesResResponse.body();
                if(bvAaratiFeesRes.getStatus() == 1){
                    mBVFees = Integer.parseInt(bvAaratiFeesRes.getUserdata().getBvFee());
                    mAaratiFees = Integer.parseInt(bvAaratiFeesRes.getUserdata().getAaratiFee());
                }
                Logger.e(TAG, resultMap.toString());
                return  resultMap ;
            } catch (IOException e) {
                Logger.e(TAG, e.toString());
                activityHandle.hideProgress();
            }
            return null;
        }

        @Override
        protected void onPostExecute( HashMap<String, Object> resultMap) {
            super.onPostExecute(resultMap);
            loadData(resultMap);
        }
    }

    private void loadData(HashMap<String, Object> resultMap) {
        mMemberInterestList = (MemberInterestList)resultMap.get(Constants.MEM_INTEREST_LIST) ;
        MemberDataList mMemberList = (MemberDataList)resultMap.get(Constants.MEMBER_LIST);
        ChildDataList childDataList = (ChildDataList)resultMap.get(Constants.CHILD_LIST);
        MagazineListRes mMagazineList = (MagazineListRes)resultMap.get(Constants.MAGAZINE_LIST);
        LanguageResponseModel languageResponseModel = (LanguageResponseModel) resultMap.get(Constants.LANG_OBJ);
        mLanguageMapping = new HashMap<String, String>();

        if (languageResponseModel != null && languageResponseModel.getLanguageDataList() != null
                && languageArrayList != null ) {
            for (LanguageData languageData : languageResponseModel.getLanguageDataList()) {
                languageArrayList.add(languageData.getLangName());
                mLanguageMapping.put(languageData.getLangName(),languageData.getId());
            }
            mLanguageAdapter.notifyDataSetChanged();
        }

        boolean firstMember = true;
        List<MemberInterestModel> memberInterestList = mMemberInterestList.getUserdata();
        mCenterAddressText.setText(loggedInMemberDetails.getCenterAddress());
        mCenterNameText.setText(loggedInMemberDetails.getCenterName());

        mMemberModels = mMemberList.getUserdata() ;
        for (MemberModel memberModel : mMemberModels) {
            LinearLayout memberInfoLayout = (LinearLayout) activityHandle.getLayoutInflater()
                    .inflate(R.layout.member_info_layout, null);
            if (firstMember) {
                ((TextView) memberInfoLayout.findViewById(R.id.memberNameTextView)).
                        setText(getString(R.string.member_name_primary, memberModel.getName()));
                firstMember = false;

            } else {
                ((TextView) memberInfoLayout.findViewById(R.id.memberNameTextView)).
                        setText(getString(R.string.member_name_secondary, memberModel.getName()));
            }
            List<String> currentInterestList = memberModel.getMemberIntrest() ;
            if(memberInterestList != null && memberInterestList.size() > 0){
                for(MemberInterestModel memberInterestModel : memberInterestList){
                    CheckBox checkbox = (CheckBox)activityHandle.getLayoutInflater().inflate(R.layout.checkbox_layout,null);
                    checkbox.setText(memberInterestModel.getInterestName());
                    if(currentInterestList != null && currentInterestList.size() > 0){
                        for(String interest : currentInterestList){
                            if(interest.equalsIgnoreCase(memberInterestModel.getInterestName())){
                                checkbox.setChecked(true);
                                break;
                            }
                        }

                    }
                    memberInfoLayout.addView(checkbox);
                }

            }
            mMemberInfoLayout.addView(memberInfoLayout);
        }
        mChildModels =  childDataList.getUserdata() ;
        int childCount = 0 ;
        for (ChildModel childModel : mChildModels) {
            final TableLayout childInfoLayout = (TableLayout) activityHandle.getLayoutInflater()
                    .inflate(R.layout.child_info_layout, null);
            //set Tag for remove
            childInfoLayout.setTag(childModel.getId());
          //  childCount++ ;
            ((TextView) childInfoLayout.findViewById(R.id.childNameTextView)).
                    setText(childModel.getName());
            ((TextView)childInfoLayout.findViewById(R.id.preferredSessionTextView))
                    .setText(childModel.getSessionName()+"( "+ childModel.getSessionStart()+" - "+ childModel.getSessionEnd()+" )");

            ((TextView) childInfoLayout.findViewById(R.id.bvClassTextView)).
                    setText(childModel.getClassName());

            TextView availableTextView = ((TextView) childInfoLayout.findViewById(R.id.availabilityTextView)) ;

            //        setText(childModel.getFillSeat()+"/"+ childModel.getTotalSeat());
            int filledSeat = 0 ;
            int totalSeat = 0 ;
            try {
                filledSeat = Integer.parseInt(childModel.getFillSeat());
                totalSeat = Integer.parseInt(childModel.getTotalSeat());
            }catch (NumberFormatException e){
                Logger.e("PaymentFragment",":"+e.getMessage());
            }

            if((totalSeat - filledSeat) == 0){
                availableTextView.setTextColor(ContextCompat.getColor(activityHandle,R.color.red));
            }
            availableTextView.setText((totalSeat - filledSeat)+"/"+ childModel.getTotalSeat());

            if(childModel.getIsShrutiClass().equals("1")){
                ((CheckBox) childInfoLayout.findViewById(R.id.shrutiCheckbox)).setChecked(true); ;
            }

            if(childModel.getStatus().equalsIgnoreCase("3")){
                ((CheckBox) childInfoLayout.findViewById(R.id.shrutiCheckbox)).setEnabled(false);
                ((Spinner) childInfoLayout.findViewById(R.id.languageSpinner)).setEnabled(false);
                ((TextView) childInfoLayout.findViewById(R.id.deleteChild)).setEnabled(false);
                ((TextView) childInfoLayout.findViewById(R.id.deleteChild)).setCompoundDrawables( null, null, null, null );
            }else{
                ((TextView) childInfoLayout.findViewById(R.id.deleteChild)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showRemoveChildDialog(childInfoLayout);
                        //mChildInfoLayout.removeView(childInfoLayout);
                    }
                });
            }


            ((Spinner) childInfoLayout.findViewById(R.id.languageSpinner)).setAdapter(mLanguageAdapter);
            int langIndex = 0 ;
            for(String langName : languageArrayList){

                if(childModel.getLangName()!= null && childModel.getLangName().equalsIgnoreCase(langName)){
                    ((Spinner) childInfoLayout.findViewById(R.id.languageSpinner)).setSelection(langIndex);
                    break;
                }
                langIndex++ ;
            }

            //((TextView)childInfoLayout.findViewById(R.id.availabilityTextView)). setText();

            mChildInfoLayout.addView(childInfoLayout);
        }
        magazineList = mMagazineList.getUserdata() ;
        int magCount = 0 ;
        if(magazineList != null ){

            for(Magazine magazine : magazineList.getMandatory()){
                CheckBox checkbox = (CheckBox)activityHandle.getLayoutInflater().inflate(R.layout.checkbox_layout,null);
                checkbox.setText(magazine.getMagName()+" - $"+magazine.getPrice());
                checkbox.setId(idArrays[magCount++]);
                checkbox.setOnClickListener(this);
                mMagazineInfoLayout.addView(checkbox);
            }

            CustomTextView customTextView = (CustomTextView) activityHandle.getLayoutInflater().inflate(R.layout.textview_layout,null);
            customTextView.setText(getString(R.string.pick_additional_magazine));
            mMagazineInfoLayout.addView(customTextView);
            for(Magazine magazine : magazineList.getOptional()){
                CheckBox checkbox = (CheckBox)activityHandle.getLayoutInflater().inflate(R.layout.checkbox_layout,null);
                checkbox.setText(magazine.getMagName()+" - $"+magazine.getPrice());
                checkbox.setId(idArrays[magCount++]);
                checkbox.setOnClickListener(this);
                mMagazineInfoLayout.addView(checkbox);
            }

        }
        mAaratiFeesTextView.setText("$"+mAaratiFees);
        mBvFeesTextView.setText("$"+mBVFees);
        mTotalOnlineFees = mAaratiFees+mMagazineFees+mBVFees+mServiceFees ;
        mMagazineFeesTextView.setText("$"+ mMagazineFees);
        mTotalFeesTextView.setText("$"+(mAaratiFees+mMagazineFees+mBVFees));
        mTotalOnlineFeesTextView.setText("$"+(mTotalOnlineFees));

        activityHandle.hideProgress();
    }

    private void showRemoveChildDialog(final TableLayout childInfoLayout) {
        // get prompts.xml view
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activityHandle);
        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       /* Object position = (Object)childInfoLayout.getTag() ;
                        mChildModels.remove(Integer.parseInt(position.toString()));
                        mChildInfoLayout.removeView(childInfoLayout);*/
                        deleteChild(childInfoLayout);
                    }
                })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).setTitle(getString(R.string.delete_child)).setMessage(getString(R.string.delete_child_msg));

        // create an alert dialog
        final AlertDialog alert = alertDialogBuilder.create();

        alert.show();
        //  alert.getWindow().setBackgroundDrawableResource(ContextCompat.getColor(activityHandle, R.color.light_white));
        alert.getWindow().setBackgroundDrawableResource(R.color.light_white);
    }

    @Override
    public void onDestroy() {
        activityHandle.stopService(new Intent(getContext(), PayPalService.class));
        //  activityHandle = null;
        super.onDestroy();
    }

    private void startPaypalService() {
        Intent intent = new Intent(getContext(), PayPalService.class);
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config);
        activityHandle.startService(intent);
    }

    private static PayPalConfiguration config = new PayPalConfiguration()
            // Start with mock environment.  When ready, switch to sandbox (ENVIRONMENT_SANDBOX)
            // or live (ENVIRONMENT_PRODUCTION)
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId(Constants.PAYPAL_CLIENT_ID);

    private PaymentReqModel getModel(){
        PaymentReqModel paymentReqModel = new PaymentReqModel();
        //paymentReqModel.setPaymentMethod(paymentMethod);
        paymentReqModel.setFamilyId(loggedInMemberDetails.getFamilyId());
        paymentReqModel.setMemberLoginId(loggedInMemberDetails.getMemberLoginId());
        paymentReqModel.setMemberEmail(loggedInMemberDetails.getEmailid());
        paymentReqModel.setMemberFirstname(loggedInMemberDetails.getName());
        //paymentReqModel.setMemberLastname(loggedInMemberDetails.getName());

        ArrayList<MemberInterest> memberInterestList = new ArrayList<MemberInterest>();
        for(int i = 0; i < mMemberInfoLayout.getChildCount() ; i++){
            LinearLayout memberInfoLayout = (LinearLayout)mMemberInfoLayout.getChildAt(i);
            ArrayList<String> memberInterest = new ArrayList<String>();

            for(int j = 0 ; j < memberInfoLayout.getChildCount() ; j++){
                View view = memberInfoLayout.getChildAt(j);
                if(view instanceof CustomCheckBox){
                    if(((CustomCheckBox)view).isChecked()){
                        memberInterest.add(String.valueOf(((CustomCheckBox)view).getText()));
                    }
                }
            }
            String memberIntString  = android.text.TextUtils.join(",", memberInterest);
            memberInterestList.add(new MemberInterest(mMemberModels.get(i).getMemberLoginId(),memberIntString));
        }
        paymentReqModel.setMemberInterest(memberInterestList);

        if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.balavihar)).isChecked() ){
           paymentReqModel.setMagazinePackBalavihar( magazineList.getMandatory().get(0).getMagPackId());
        }
        if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked() ){
            paymentReqModel.setMagazinePackUdgosh( magazineList.getMandatory().get(1).getMagPackId());
        }
        if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked() ){
            paymentReqModel.setMagazinePackTapovanPrasad( magazineList.getOptional().get(0).getMagPackId());
        }
        if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked() ){
            paymentReqModel.setMagazinePackBalavihar( magazineList.getOptional().get(1).getMagPackId());
        }

        ArrayList<String> childIdList = new ArrayList<String>();
        ArrayList<String> childSessionIdList = new ArrayList<String>();
        ArrayList<String> childLanguageIdList = new ArrayList<String>();
        ArrayList<String> childShrutiClassList = new ArrayList<String>();

        for(int i = 0 ; i < mChildInfoLayout.getChildCount() ; i++){
            TableLayout childInfoLayout = (TableLayout)mChildInfoLayout.getChildAt(i);
            TableRow langSelectionRow = (TableRow)childInfoLayout.getChildAt(4);
            LinearLayout spinnerLayout = (LinearLayout)langSelectionRow.getChildAt(1);
            TableRow shrutiClassRow = (TableRow)childInfoLayout.getChildAt(5);
            String language = String.valueOf(((Spinner)spinnerLayout.getChildAt(0)).getSelectedItem());
            boolean isShruti = ((CheckBox)shrutiClassRow.getChildAt(1)).isChecked();
            /*for(int j = 0 ; j < childInfoLayout.getChildCount() ; j++){
            }*/
            childIdList.add(mChildModels.get(i).getMemberLoginId());
            childSessionIdList.add(mChildModels.get(i).getSessionId());
            childLanguageIdList.add(mLanguageMapping.get(language));
            childShrutiClassList.add((isShruti ? "1" : "0"));
        }
        paymentReqModel.setChildId(childIdList);
        paymentReqModel.setChildSessionId(childSessionIdList);
        paymentReqModel.setChildLanguageId(childLanguageIdList);
        paymentReqModel.setChildShruticlass(childShrutiClassList);
        paymentReqModel.setAaratiFee(String.valueOf(mAaratiFees));
        paymentReqModel.setMagazineFees(String.valueOf(mMagazineFees));
        paymentReqModel.setChildFees(String.valueOf(mBalviharFees));
        paymentReqModel.setServiceFees(String.valueOf(mServiceFees));
        paymentReqModel.setTotalAmount(String.valueOf(mTotalOnlineFees));
        paymentReqModel.setAmount(String.valueOf(mTotalOnlineFees));
        paymentReqModel.setCurrency(getString(R.string.currency_USD));
        return paymentReqModel;
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.confirmRegCheckbox :

                break;
            case R.id.payNowButton:
                if(validate()){

                    if(mPrevAmountPaid >= mTotalOnlineFees){
                        mTotalOnlineFees = 0 ;
                    }else{
                        mTotalOnlineFees = mTotalOnlineFees - mPrevAmountPaid ;
                    }
                    final String selectedPaymentMethod = String.valueOf(mPaymentSpinner.getSelectedItem());
                    if(selectedPaymentMethod.equalsIgnoreCase(getString(R.string.payal_credit_card))){
                        showPaymentReviewDialog(getString(R.string.payal_credit_card));
                        //doPaypalPayment();
                    }else{
                        AlertDialogUtility.showDialog(activityHandle, null,
                                getString(R.string.cash_check_dialog_header)+"\n\n"+getString(R.string.cash_check_dialog_msg),
                                getString(R.string.ok),
                                getString(R.string.cancel),
                                false,
                                new AlertMagnatic() {
                                    @Override
                                    public void onButtonClicked(boolean yes) {
                                        if(yes){
                                            if(selectedPaymentMethod.equalsIgnoreCase(getString(R.string.cash))) {
                                                PaymentReqModel paymentReqModel = getModel();
                                                paymentReqModel.setPaymentMethod(Constants.PAY_CASH);
                                                sendPaymentDetails(paymentReqModel);
                                                //cash check payment
                                            }else{
                                                PaymentReqModel paymentReqModel = getModel();
                                                paymentReqModel.setPaymentMethod(Constants.PAY_CHECK);
                                                sendPaymentDetails(paymentReqModel);
                                            }
                                        }
                                    }
                                });
                    }
                }
                break;

            default :
                if(v instanceof CustomCheckBox){
                    calculatePayment();

                }

        }
    }

    private boolean isAgeLessThan12(){
        for(ChildModel childModel : mChildModels){
            if(childModel.getAge() < 12){
                continue;
            }else{
                return false ;
            }
        }
        return true ;
    }

    private boolean isAgeGte12(){
        for(ChildModel childModel : mChildModels){
            if(childModel.getAge() >= 12){
                continue;
            }else{
                return false ;
            }
        }
        return true ;
    }

    private void deleteChild(final TableLayout childInfoLayout) {

        final String childId = (String)childInfoLayout.getTag() ;

        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.deleting));

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setId(childId);
        genericRequestModel.setType(Constants.CHILD);

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().deleteItem(genericRequestModel);

        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                activityHandle.hideProgress();
                if (genericResponseModel != null && genericResponseModel.getStatus() == 1) {
                    //store user response in session
                    Toast.makeText(activityHandle,genericResponseModel.getMsg(), Toast.LENGTH_LONG).show();
                    int count = 0 ;
                    for(ChildModel childModel : mChildModels){

                        if(childModel.getId().equalsIgnoreCase(childId)){
                           break ;
                        }
                        count++ ;
                    }
                    mChildModels.remove(count);
                    mChildInfoLayout.removeView(childInfoLayout);
                } else {
                    Toast.makeText(activityHandle,genericResponseModel.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }

    private boolean isMazSelectionValid = false ;
    private  String mErrorMsg ;
    private int mAaratiFees ;
    private int mBVFees ;
    private int mServiceFees = 10;
    private int mTotalFees = 450 ;
    private int mTotalOnlineFees = 460 ;
    private int mMagazineFees;
    private int mBalviharFees = 600;
    private int optMagFees , mandMagFees ;
    private int mPrevAmountPaid;
    int[] idArrays = new int[]{R.id.balavihar, R.id.udgosh, R.id.tapovan, R.id.mananam} ;
    private void calculatePayment() {
        isMazSelectionValid = true ;
        mErrorMsg = null ;
        //mAaratiFees = 50 ;
        //mBVFees = 400 ;
        mServiceFees = 10 ;
        mTotalFees = 0 ;
        mTotalOnlineFees = 0 ;
        optMagFees = mandMagFees= mMagazineFees = 0 ;

        if(mChildModels != null && mChildModels.size() > 0){
            if(mChildModels.size() == 1){
                if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.balavihar)).isChecked() &&
                        !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked()){
                    if(mChildModels.get(0).getAge() > 12){
                        mErrorMsg = getString(R.string.greater_than_twelve_msg) ;
                        Toast.makeText(activityHandle,mErrorMsg, Toast.LENGTH_SHORT).show();
                        isMazSelectionValid = false;

                    }
                    mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getMandatory().get(0).getPrice());
                    mandMagFees = mMagazineFees ;
                }else if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked()
                        &&  !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.balavihar)).isChecked()){
                    if(mChildModels.get(0).getAge() < 12){
                        mErrorMsg = getString(R.string.less_than_twelve_msg) ;
                        Toast.makeText(activityHandle,mErrorMsg, Toast.LENGTH_SHORT).show();
                        isMazSelectionValid = false;
                    }
                    mMagazineFees = Integer.parseInt(magazineList.getMandatory().get(1).getPrice());
                    mandMagFees = mMagazineFees ;
                }else if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.balavihar)).isChecked() &&
                        ((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked()){
                    mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getMandatory().get(0).getPrice())+
                            Integer.parseInt(magazineList.getMandatory().get(1).getPrice());
                    mandMagFees = mMagazineFees ;
                }
                //optional magazines
                if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked() &&
                        !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked()){

                    mMagazineFees = mMagazineFees +  Integer.parseInt(magazineList.getOptional().get(0).getPrice());
                    optMagFees =   Integer.parseInt(magazineList.getOptional().get(0).getPrice());
                }else if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked()
                        &&  !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked()){

                    mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                    optMagFees =   Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                }else if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked() &&
                        ((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked()){

                    mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getOptional().get(0).getPrice())+
                            Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                    optMagFees =   Integer.parseInt(magazineList.getOptional().get(0).getPrice())+
                            Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                }

              //  Toast.makeText(activityHandle,"Magazine Price :"+ mMagazineFees, Toast.LENGTH_SHORT).show();
            }else {
                if(isAgeLessThan12()){
                    if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked()){
                        mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getMandatory().get(1).getPrice());
                        mandMagFees = mMagazineFees ;
                    }

                }else if(isAgeGte12()){
                    if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.balavihar)).isChecked()){
                        mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getMandatory().get(0).getPrice());
                        mandMagFees = mMagazineFees ;
                    }
                }else {
                    if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.udgosh)).isChecked()){
                        mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getMandatory().get(1).getPrice());
                        mandMagFees = mMagazineFees ;
                    }
                }

                if(!(loggedInMemberDetails.getCenterName().equalsIgnoreCase("Rameshwaram")||
                        loggedInMemberDetails.getCenterName().equalsIgnoreCase("San Gabriel") ||
                        loggedInMemberDetails.getCenterName().equalsIgnoreCase("South Bay"))){

                    if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked() &&
                            !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked()){

                        mMagazineFees = mMagazineFees +  Integer.parseInt(magazineList.getOptional().get(0).getPrice());
                        optMagFees =   Integer.parseInt(magazineList.getOptional().get(0).getPrice());
                    }else if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked()
                            &&  !((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked()){

                        mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                        optMagFees =   Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                    }else if(((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.tapovan)).isChecked() &&
                            ((CustomCheckBox)mMagazineInfoLayout.findViewById(R.id.mananam)).isChecked()){

                        mMagazineFees = mMagazineFees + Integer.parseInt(magazineList.getOptional().get(0).getPrice())+
                                Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                        optMagFees =   Integer.parseInt(magazineList.getOptional().get(0).getPrice())+
                                Integer.parseInt(magazineList.getOptional().get(1).getPrice());
                    }
                }

            }
            Logger.e("Anwar","Optional mag cost :"+optMagFees);
            Logger.e("Anwar","Mandatory mag cost :"+mandMagFees);
            mTotalOnlineFees = mAaratiFees+mMagazineFees+mBVFees+mServiceFees ;
            mMagazineFeesTextView.setText("$"+ mMagazineFees);
            mTotalFeesTextView.setText("$"+(mAaratiFees+mMagazineFees+mBVFees));
            mTotalOnlineFeesTextView.setText("$"+(mTotalOnlineFees));
        }
    }
    ////////////////////////////////PAYPAL CODE ///////////////////////////

    private AlertDialog mAlertDialog;
    private void showPaymentReviewDialog(String paymentType) {
        // get prompts.xml view
        final LinearLayout promptView = (LinearLayout) activityHandle.getLayoutInflater()
                .inflate(R.layout.payment_review_dialog, null);

        LinearLayout cashCheckMsgLayout = (LinearLayout) promptView.findViewById(R.id.cashCheckMsgLayout);
        CustomAppCompatButton payNowButton = (CustomAppCompatButton) promptView.findViewById(R.id.payNowButton);
        if(paymentType.equalsIgnoreCase(getString(R.string.payal_credit_card))){
            cashCheckMsgLayout.setVisibility(View.GONE);
            ((TextView)promptView.findViewById(R.id.paymentMethodTextView)).setText(Constants.PAY_PAYPAL);
            ((TextView)promptView.findViewById(R.id.totalAmountTextView)).setText(String.valueOf("$"+mTotalOnlineFees));
            ((TextView)promptView.findViewById(R.id.dateTextView)).setText(Utils.getCurrentDate());
            payNowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mAlertDialog.dismiss();
                    doPaypalPayment();
                }
            });
        }else{
            final String selectedPaymentMethod = String.valueOf(mPaymentSpinner.getSelectedItem());
            payNowButton.setText(getString(R.string.ok));
            ((TextView)promptView.findViewById(R.id.paymentMethodTextView)).setText(selectedPaymentMethod);
            ((TextView)promptView.findViewById(R.id.totalAmountTextView)).setText(String.valueOf("$"+mTotalOnlineFees));
            ((TextView)promptView.findViewById(R.id.dateTextView)).setText(Utils.getCurrentDate());
            ((TextView)promptView.findViewById(R.id.paymentStatusTextView)).setText(Constants.AMOUNT_UNPAID);
            ((TextView)promptView.findViewById(R.id.paypalTextView)).setVisibility(View.GONE);
            payNowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mAlertDialog.dismiss();
                    activityHandle.redirectDashboard();
                }
            });
        }
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activityHandle);
        alertDialogBuilder.setView(promptView);
        // create an mAlertDialog dialog
        mAlertDialog = alertDialogBuilder.create();
        mAlertDialog.show();
        //  mAlertDialog.getWindow().setBackgroundDrawableResource(ContextCompat.getColor(activityHandle, R.color.light_white));
        mAlertDialog.getWindow().setBackgroundDrawableResource(R.color.light_white);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mCenterAddressText = null;
        mCenterNameText = null;
        mMemberInfoLayout = null;
        mChildInfoLayout = null;
        mMemberInterestList = null ;
        mPaymentSpinner = null ;
        paymentMethodList = null ;
        mPaymentAdapter = null;
        mConfirmCheckbox = null ;
        isMazSelectionValid = false ;
    }
}
