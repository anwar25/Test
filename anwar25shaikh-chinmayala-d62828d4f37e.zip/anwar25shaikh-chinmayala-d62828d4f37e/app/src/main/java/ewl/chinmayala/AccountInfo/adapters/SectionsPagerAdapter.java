package ewl.chinmayala.AccountInfo.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import ewl.chinmayala.AccountInfo.fragments.edit.ChildDetailPage;
import ewl.chinmayala.AccountInfo.fragments.edit.MemberDetailPage;
import ewl.chinmayala.AccountInfo.fragments.edit.TrustDetailPage;
import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildModel;
import ewl.chinmayala.AccountInfo.fragments.edit.models.MemberModel;
import ewl.chinmayala.AccountInfo.fragments.edit.models.TrustModel;

/**
 * Created by Anwar Shaikh on 7/21/2016.
 */
public class SectionsPagerAdapter extends FragmentStatePagerAdapter{

    private final List<Fragment> mFragments = new ArrayList<Fragment>();
    private final List<String> mFragmentTitles = new ArrayList<String>();
    List<TrustModel> mTrustModelsList;
    List<ChildModel> mChildModelsList;
    List<MemberModel> mMemberModelsList;
  //  FragmentManager manager;
    public SectionsPagerAdapter(FragmentManager fm) {
        super(fm);
  //      manager = fm;
    }

    public void setTrustModelList(List<TrustModel> trustModels) {
        this.mTrustModelsList = trustModels;
    }

    public void setChildModelList(List<ChildModel> childModels) {
        this.mChildModelsList = childModels;
    }

    public void setMemberModelList(List<MemberModel> memberModels) {
        this.mMemberModelsList = memberModels;
    }
    public void addFragment(Fragment fragment, String title) {
        mFragments.add(fragment);
        mFragmentTitles.add(title);
    }

    @Override
    public Fragment getItem(int position) {
       // Log.i("anwar", "********getItem:" + position );
        return mFragments.get(position);
    }

   /* @Override
    public int getItemPosition(Object object) {
        String s = "";
        Logger.e("anwar","getItemPosition");
        return POSITION_NONE ;
    }*/

    @Override
    public int getCount() {
        return mFragments.size();
    }



    @Override
    public Object instantiateItem(ViewGroup container, int position) {
       /* List<Fragment> fragmentsList = manager.getFragments();
        if (fragmentsList != null && position <= (fragmentsList.size() - 1)) {
            TrustDetailPage sampleFragment = (TrustDetailPage) fragmentsList.get(position);
            sampleFragment.setData(mTrustModelsList.get(position));
        } else {
            //No fragment instance available for this index, create a new fragment by calling getItem() and show the data.
            Log.i("anwar", "********instantiateItem position:" + position + " NewFragmentCreated");
        }*/
       // Log.i("anwar", "********instantiateItem position:" + position + " NewFragmentCreated");
        Object obj = super.instantiateItem(container, position);
        if (obj instanceof TrustDetailPage) {
            // record the fragment tag here.
            TrustDetailPage f = (TrustDetailPage) obj;
         //   String tag = f.getTag();
            f.setData(mTrustModelsList.get(position));
        }else if(obj instanceof ChildDetailPage){
            ChildDetailPage f = (ChildDetailPage) obj;
            f.setData(mChildModelsList.get(position));
        }else if(obj instanceof MemberDetailPage){
            MemberDetailPage f = (MemberDetailPage) obj;
            f.setData(mMemberModelsList.get(position));
        }
        return obj;

       // return super.instantiateItem(container, position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mFragmentTitles.get(position);
    }
}