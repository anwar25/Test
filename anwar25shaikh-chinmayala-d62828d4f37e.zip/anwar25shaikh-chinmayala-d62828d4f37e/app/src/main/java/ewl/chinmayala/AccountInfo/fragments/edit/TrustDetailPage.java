package ewl.chinmayala.AccountInfo.fragments.edit;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import ewl.chinmayala.AccountInfo.fragments.AddEditTrustFragment;
import ewl.chinmayala.AccountInfo.fragments.edit.models.TrustModel;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.AlertDialogUtility;
import ewl.chinmayala.Utils.AlertMagnatic;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar on 7/28/2016.
 */
public class TrustDetailPage extends Fragment implements View.OnClickListener{
    private TrustModel mTrustDetails;
    private ImageButton mDeleteTrustButton;
    private ImageButton mEditTrustButton;
    private HomeActivity activityHandle;
    private CustomTextView mCompanyNameTextView;
    private CustomTextView mCompanyPhoneTextView;
    private CustomTextView mCompanyAddTextView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.trust_details_page_layout, container, false);

        mCompanyNameTextView = (CustomTextView)rootView.findViewById(R.id.compNameTextView) ;
        mCompanyPhoneTextView = (CustomTextView)rootView.findViewById(R.id.compPhoneTextView) ;
        mCompanyAddTextView = (CustomTextView)rootView.findViewById(R.id.compAddressTextView) ;
        mDeleteTrustButton = (ImageButton)rootView.findViewById(R.id.deleteTrustButton);
        mEditTrustButton = (ImageButton)rootView.findViewById(R.id.editTrustButton);
        if(getArguments() != null){
            mTrustDetails = (TrustModel)getArguments().getSerializable(Constants.TRUST_DETAILS);
            mCompanyNameTextView.setText(mTrustDetails.getCompany());
            mCompanyPhoneTextView.setText(mTrustDetails.getCompanyPhone());
            mCompanyAddTextView.setText(mTrustDetails.getCompanyAddress());
        }
        mDeleteTrustButton.setOnClickListener(this);
        mEditTrustButton.setOnClickListener(this);
        return rootView;
    }

    public void setData(TrustModel trustModel) {
        if(isAdded()) {
            this.mTrustDetails = trustModel;
            mCompanyNameTextView.setText(mTrustDetails.getCompany());
            mCompanyPhoneTextView.setText(mTrustDetails.getCompanyPhone());
            mCompanyAddTextView.setText(mTrustDetails.getCompanyAddress());
            Logger.e("anwar", "setData:" + trustModel);
        }
    }


   /* @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        Logger.e("anwar","setUserVisibleHint");
        if(mCompanyAddTextView != null)
            mCompanyNameTextView.setText(mTrustDetails.getCompany());
        if(mCompanyPhoneTextView != null)
            mCompanyPhoneTextView.setText(mTrustDetails.getCompanyPhone());
        if(mCompanyAddTextView != null )
            mCompanyAddTextView.setText(mTrustDetails.getCompanyAddress());
    }*/


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Logger.e("anwar","TrustdetailsPage onDestroyView:"+mTrustDetails);
        mTrustDetails = null ;
        mCompanyNameTextView = null ;
        mCompanyPhoneTextView = null ;
        mCompanyAddTextView = null ;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Logger.e("anwar","TrustdetailsPage onDestroy:"+mTrustDetails);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.editTrustButton :
                AddEditTrustFragment trustInfoFragment  = new AddEditTrustFragment() ;
                Bundle bundle = new Bundle( );
                bundle.putSerializable(Constants.TRUST_DETAILS,mTrustDetails);
                trustInfoFragment.setArguments(bundle);
                activityHandle.onReplaceFragment(trustInfoFragment,true);
                break;
            case R.id.deleteTrustButton :
                AlertDialogUtility.showDeleteDialog(activityHandle, getString(R.string.delete_trust),
                        getString(R.string.delete_trust_msg),
                        getString(R.string.yes),
                        getString(R.string.no),
                        false,
                        new AlertMagnatic() {
                            @Override
                            public void onButtonClicked(boolean yes) {
                                if(yes){
                                    deleteTrust();
                                }
                            }
                        });
                break;
        }
    }


    private void deleteTrust() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.deleting));

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setId(mTrustDetails.getTrustId());
        genericRequestModel.setType(Constants.TRUST);

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().deleteItem(genericRequestModel);

        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                activityHandle.hideProgress();
                if (genericResponseModel != null && genericResponseModel.getStatus() == 1) {
                    //store user response in session
                    Toast.makeText(activityHandle,genericResponseModel.getMsg(), Toast.LENGTH_LONG).show();
                    ((TrustDetailsParentFragment) getParentFragment()).getTrustList();
                } else {
                    Toast.makeText(activityHandle,genericResponseModel.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity){
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }



}
