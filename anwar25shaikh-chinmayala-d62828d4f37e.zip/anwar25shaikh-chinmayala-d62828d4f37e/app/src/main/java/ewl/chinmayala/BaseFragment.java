package ewl.chinmayala;

import android.support.v4.app.Fragment;
import android.view.View;

/**
 * Created by Anwar on 6/29/2016.
 */
abstract  public class BaseFragment extends Fragment{

    public abstract void mapControls(View rootView);

    public abstract boolean validate();

}
