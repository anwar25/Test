package ewl.chinmayala;

import android.*;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.util.List;

import ewl.chinmayala.AccountInfo.fragments.DashboardFragment;
import ewl.chinmayala.AccountInfo.fragments.LoginFragment;
import ewl.chinmayala.Balavihar.BalaviharFragment;
import ewl.chinmayala.Home.HomeFragment;
import ewl.chinmayala.Interface.IMenuItemClick;
import ewl.chinmayala.constants.Constants;

public class HomeActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener,IMenuItemClick {

    private ActionBarDrawerToggle mActionBarToggle;
    private  DrawerLayout mDrawerLayout;
    private  NavigationView navigationView ;

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mActionBarToggle = null ;
        mDrawerLayout = null ;
        navigationView = null ;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_activity_screen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mActionBarToggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(mActionBarToggle);
        mActionBarToggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view_left);
        navigationView.setNavigationItemSelectedListener(this);


        onReplaceFragment(new HomeFragment(), false);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.container);
                if (currentFragment instanceof HomeFragment){
                    String userResponse = getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
                    if(!TextUtils.isEmpty(userResponse)){
                        navigationView.getMenu().findItem(R.id.nav_login).setVisible(false);
                        navigationView.getMenu().findItem(R.id.nav_logout).setVisible(true);
                    }else{
                        navigationView.getMenu().findItem(R.id.nav_login).setVisible(true);
                        navigationView.getMenu().findItem(R.id.nav_logout).setVisible(false);
                    }
                    mDrawerLayout.openDrawer(GravityCompat.START);
                }else{
                    onBackPressed();
                }


            }
        });
        mHandler = new Handler();
        Log.d("HomeActivity", "InstanceID token: " + FirebaseInstanceId.getInstance().getToken());
        //MARSHMALLOW SUPPORT
        mayRequestPermission();
    }

    private final int REQUEST_WRITE_EXT_STORAGE = 3;

    private boolean mayRequestPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(this, getString(R.string.permission_storage_ratinale)
                    , Toast.LENGTH_LONG).show();
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_EXT_STORAGE);
        } else {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_EXT_STORAGE);
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_WRITE_EXT_STORAGE) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //startLocationUpdates();
            } else {
                if (requestCode == REQUEST_WRITE_EXT_STORAGE) {
                    Toast.makeText(this, getString(R.string.permission_storage_denied)
                            , Toast.LENGTH_LONG).show();
                }

            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Fragment fragment  = getSupportFragmentManager().findFragmentById(R.id.container);
        if(fragment instanceof HomeFragment) {
            getMenuInflater().inflate(R.menu.base_activity_screen, menu);
            return super.onCreateOptionsMenu(menu);
        }
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

  //  private static BalaviharFragment mBalviharFragment ;
    private Handler mHandler ;
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
      //  Fragment fragment  = getSupportFragmentManager().findFragmentById(R.id.container);
        int id = item.getItemId();
        if (id == R.id.nav_rate_app) {
            RateYourExperience();
        }else if(id == R.id.nav_balavihar){
           /* if(mBalviharFragment == null){
                mBalviharFragment =  new BalaviharFragment();
            }*/
            onReplaceFragment(new BalaviharFragment(),true);
        }else if(id == R.id.nav_login){
            onReplaceFragment(new LoginFragment(),true);
        }else if(id == R.id.nav_logout){
            getSessionManager().logoutUser();
            Toast.makeText(HomeActivity.this, getString(R.string.logged_out), Toast.LENGTH_SHORT).show();
         //   navigationView.getMenu().findItem(R.id.nav_login).setVisible(true);
         //   navigationView.getMenu().findItem(R.id.nav_logout).setVisible(false);
        }
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mDrawerLayout.closeDrawer(GravityCompat.START);
            }
        },0);

        return true;
    }



    public void shareToGMail(String[] email, String subject, String content) {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_EMAIL, email);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_TEXT, content);
        final PackageManager pm = getPackageManager();
        final List<ResolveInfo> matches = pm.queryIntentActivities(emailIntent, 0);
        ResolveInfo best = null;
        for (final ResolveInfo info : matches)
            if (info.activityInfo.packageName.endsWith(".gm") || info.activityInfo.name.toLowerCase().contains("gmail"))
                best = info;
        if (best != null)
            emailIntent.setClassName(best.activityInfo.packageName, best.activityInfo.name);
        startActivity(emailIntent);
    }

    public void onReplaceFragment(Fragment fragment, boolean flag) {
        FragmentManager fragmentmanager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentmanager.beginTransaction();
        String backStateName = fragment.getClass().getName();
        if (flag) {
            String s = fragmentmanager.getClass().getName();
            if (!fragmentmanager.popBackStackImmediate(s, 0)) {

                if(fragment instanceof DashboardFragment){
                    Fragment loginFragment = fragmentmanager.findFragmentByTag("ewl.chinmayala.AccountInfo.fragments.LoginFragment");
                    if(loginFragment != null){
                        fragmentmanager.popBackStack();
                    }
                }
                fragmentTransaction.replace(R.id.container, fragment, backStateName);
                fragmentTransaction.addToBackStack(s);
                fragmentTransaction.commit();
            }
            return;
        } else {
            fragmentTransaction.replace(R.id.container, fragment, backStateName);
            fragmentTransaction.commit();
            return;
        }
    }

    public void redirectDashboard() {
        FragmentManager fragmentmanager = getSupportFragmentManager();
        fragmentmanager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        //onReplaceFragment(new HomeFragment(),false);
        onReplaceFragment(new DashboardFragment(),true);

    }


    private void RateYourExperience() {
        LayoutInflater factory = LayoutInflater.from(this);
        final View deleteDialogView = factory.inflate(
                R.layout.content_rateyourexperience_dialog, null);
        final AlertDialog deleteDialog = new AlertDialog.Builder(this).create();
        deleteDialog.setView(deleteDialogView);
        ((RatingBar)deleteDialogView.findViewById(R.id.ratingbar_default)).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                deleteDialog.show();
                if (rating > 3) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(getString(R.string.app_play_store_link, getPackageName())))));
                } else {
                    String[] EMail = new String[1];
                    EMail[0] = "android.eweblabs@gmail.com";
                    shareToGMail(EMail, "Suggest Something", "Briefly explain what could improve \r\nPlease write below this line -----------------------------" + "\r\n");
                }
            }
        });
        deleteDialog.show();
    }



    public void setToolbarInitialization(Fragment fragment, String title) {
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view_left);
        setTitle(title);
       // getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorPrimary)));
       if (fragment instanceof HomeFragment){
          // PaddingToolbar(true);
           SetDrawerVisibility(0);
           navigationView.setCheckedItem(R.id.nav_home);
           navigationView.invalidate();
           invalidateOptionsMenu();
        }else {
         //  PaddingToolbar(true);
           SetDrawerVisibility(1);
           navigationView.setCheckedItem(R.id.nav_home);
           navigationView.invalidate();
           invalidateOptionsMenu();
           getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       }

    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            FragmentManager fm = getSupportFragmentManager();
            Fragment fragment = fm.findFragmentById(R.id.container);
            if (fm.getBackStackEntryCount() > 0) {
                fm.popBackStack();
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);

            } else {
                if (fragment instanceof HomeFragment) {
                    super.onBackPressed();
                } else {
                    onReplaceFragment(new HomeFragment(), false);
                }
            }
            hideKeyboard();
        }

    }
    public void hideKeyboard(){
        InputMethodManager inputManager =  (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        if(getCurrentFocus() != null)
            inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
    }

    public void hideKeyboarFromDialog(View view){
        InputMethodManager inputManager =  (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(view.getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
    }
    public void SetDrawerVisibility(int status) {
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view_left);
        if (status == 0) {
            mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, navigationView);
            mActionBarToggle.onDrawerStateChanged(DrawerLayout.LOCK_MODE_UNLOCKED);
            mActionBarToggle.setDrawerIndicatorEnabled(true);
            mActionBarToggle.syncState();
        } else if (status == 1) {
            mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, navigationView);
            mActionBarToggle.onDrawerStateChanged(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            mActionBarToggle.setDrawerIndicatorEnabled(false);
          //  mActionBarToggle.setHomeAsUpIndicator(R.drawable.abc_ic_ab_back_mtrl_am_alpha);
            mActionBarToggle.syncState();
        }
    }

    @Override
    public void onMenuClick(Fragment fragment) {
        onReplaceFragment(fragment,false);

    }


}
