package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/1/2016.
 */
public class LoginResponse {

    @SerializedName("userdata")
    @Expose
    private LoginData loginData;
    @SerializedName("status")
    @Expose
    private Integer status;

    @SerializedName("error_msg")
    @Expose
    private String errorMsg;

    @SerializedName("msg")
    @Expose
    private String msg;



    /**
     *
     * @return
     * The msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     *
     * @param msg
     * The msg
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }


    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    /**
     *
     * @return
     * The loginData
     */
    public LoginData getLoginData() {
        return loginData;
    }

    /**
     *
     * @param loginData
     * The loginData
     */
    public void setLoginData(LoginData loginData) {
        this.loginData = loginData;
    }

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

}