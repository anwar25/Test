package ewl.chinmayala.UI;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;

import ewl.chinmayala.R;

/**
 * Created by Akash.Singh on 9/8/2015.
 */
public class CustomLoadingDialog extends Dialog {


  /*  ProgressBar customProgressBar;*/

    Context context;
    public CustomLoadingDialog(Context context) {
        super(context);
        this.context = context;

    }
    TextView customProgressBar_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        setContentView(R.layout.custom_loading_dialog);
        // MapWidgetIds();
        customProgressBar_message = (TextView)findViewById(R.id.customProgressBar_message);
        setCancelable(true);
        setCanceledOnTouchOutside(false);
    }


    /*private void MapWidgetIds() {
        customProgressBar = (ProgressBar) findViewById(R.id.customProgressBar);
    }*/


}
