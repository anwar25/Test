package ewl.chinmayala.constants;

/**
 * Created by Anwar on 5/23/2016.
 */
public interface Constants {

    int IMAGE_ANIM_DURATION = 1000;

    String PREF_FILE_NAME = "chinmayala_sp";
    String USER_RESPONSE = "user_response";
    String PROFESSION_OBJ = "professsionObj";
    String CENTER_OBJ = "centerObj";
    String LANG_OBJ = "langObj";

    String GOOGLE_PLACES_API_KEY = "AIzaSyC7pmeRSJkgUWUEvJhEteu-OtyPlxftkck";

    String REGISTER_MEMBER = "register_member";
    String REGISTER_TRUST = "register_trust";
    String REGISTER_MEMBER1_DETAILS = "member1_details";
    String SCHOOL_GRADE_OBJ = "school_grade";
    String IS_FROM_DASHBOARD = "is_from_dashboard";

    String CENTER_INFO = "center_info";
    String PAYPAL_CLIENT_ID = "Ad9Ji5jPd9AGdvt8f3DPnZpF1uvfNYO8UbnT7gP5f05lsET4fEmVhUuakczJ6eOwhzREnUu-kN7_dHCU";
    String SESSION_LIST_OBJ = "sessionObj";
    String MEM_INTEREST_LIST = "memIntObj";
    String MEMBER_DETAILS = "member_details";
    String CHILD_DETAILS = "children_details";
    String TRUST_DETAILS = "trust_details";
    String PAYMENT_DETAILS = "payment_details";
    String MEMBER = "member";
    String CHILD = "child";
    String TRUST = "trust";
    String MEMBER_LIST = "member_list";
    String CHILD_LIST = "child_list";
    String MAGAZINE_LIST = "magazine_list";
    String PAYPAL_RESPONSE = "response";
    String PAYMENT_STATE = "state";
    String STATE_APPROVED = "approved";
    String PAY_PAYPAL = "Paypal";
    String PAY_CASH = "Cash";
    String PAY_CHECK = "Check";
    String PAY_ID = "id";
    String SUCESS = "Success";
    String PREV_AMOUNT = "previous_amount";
    String AMOUNT_UNPAID = "Amount unpaid";
    String CHILD_NOT_PAID = "3";
}
