package ewl.chinmayala.AccountInfo.fragments.edit;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.List;

import ewl.chinmayala.AccountInfo.adapters.SectionsPagerAdapter;
import ewl.chinmayala.AccountInfo.fragments.PaymentFragment;
import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildModel;
import ewl.chinmayala.AccountInfo.fragments.edit.models.PaymentDataList;
import ewl.chinmayala.AccountInfo.fragments.edit.models.PaymentModel;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.LoginData;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar Shaikh on 2/11/2016.
 */
public class PaymentDetailsParentFragment extends Fragment implements View.OnClickListener{

    private ViewPager mViewPager;
    private CustomAppCompatButton mPayNowButton;
    private HomeActivity activityHandle;
    private static SectionsPagerAdapter mSectionsPagerAdapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.payment_details_parent_fragment, container, false);
        mapControls(rootView);
        activityHandle.setToolbarInitialization(this, getString(R.string.payment));
        getPaymentList();
        return rootView;
    }

    private void getPaymentList() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.loading_msg));
        Gson gson = new Gson();
        String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        LoginData member1Details = gson.fromJson(member1DetailsString, LoginData.class);

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setFamilyId(member1Details.getFamilyId());

        Call<PaymentDataList> call = RetrofitInstance.getInstance().getAllPaymentList(genericRequestModel);

        call.enqueue(new Callback<PaymentDataList>() {
            @Override
            public void onResponse(Call<PaymentDataList> call, Response<PaymentDataList> response) {
                PaymentDataList listMemberData = response.body();
                if (listMemberData != null && listMemberData.getStatus() == 1) {
                    //store user response in session
                    loadPaymentDetails(listMemberData.getUserdata());
                } else {
                    Toast.makeText(activityHandle,listMemberData.getErrorMsg(), Toast.LENGTH_LONG).show();
                }
                activityHandle.hideProgress();
            }

            @Override
            public void onFailure(Call<PaymentDataList> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }

    private void loadPaymentDetails(List<PaymentModel> paymentDataList) {
        for(PaymentModel paymentModel : paymentDataList){
            //addPage(member);
            Bundle bundle = new Bundle( );
            bundle.putSerializable(Constants.PAYMENT_DETAILS,paymentModel);
            PaymentDetailPage paymentDetailPage = new PaymentDetailPage() ;
            paymentDetailPage.setArguments(bundle);
            mSectionsPagerAdapter.addFragment(paymentDetailPage, getString(R.string.payment));

        }
        mSectionsPagerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mViewPager = null;
        mSectionsPagerAdapter = null ;
    }

    private void mapControls(View rootView) {
        mViewPager = (ViewPager) rootView.findViewById(R.id.childContainer);
        if (mViewPager != null) {
            setupViewPager(mViewPager);
        }
        mPayNowButton = (CustomAppCompatButton) rootView.findViewById(R.id.payNowButton);
        mPayNowButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.payNowButton :
                getChildList() ;
        }
    }


    public void getChildList() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.loading_msg));
        Gson gson = new Gson();
        String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        LoginData member1Details = gson.fromJson(member1DetailsString, LoginData.class);

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setFamilyId(member1Details.getFamilyId());

        Call<ChildDataList> call = RetrofitInstance.getInstance().getAllChildList(genericRequestModel);

        call.enqueue(new Callback<ChildDataList>() {
            @Override
            public void onResponse(Call<ChildDataList> call, Response<ChildDataList> response) {
                ChildDataList childDataList = response.body();
                activityHandle.hideProgress();
                if (childDataList != null && childDataList.getStatus() == 1) {
                    //store user response in session
                    boolean isAllChildPaid = true ;
                    for(ChildModel childModel : childDataList.getUserdata()){
                        if(!childModel.getStatus().equalsIgnoreCase(Constants.CHILD_NOT_PAID)){
                            isAllChildPaid = false ;
                            activityHandle.onReplaceFragment(new PaymentFragment(),true);

                            break;
                        }
                    }
                    if(isAllChildPaid){
                        Toast.makeText(activityHandle, getString(R.string.payment_already_done), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(activityHandle, childDataList.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ChildDataList> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }

    private void setupViewPager(ViewPager mViewPager) {
        mSectionsPagerAdapter = new SectionsPagerAdapter(getChildFragmentManager());
        mViewPager.setAdapter(mSectionsPagerAdapter);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity){
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }
}
