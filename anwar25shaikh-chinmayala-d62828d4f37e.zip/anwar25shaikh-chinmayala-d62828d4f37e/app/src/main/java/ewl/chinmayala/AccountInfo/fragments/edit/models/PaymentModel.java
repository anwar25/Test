package ewl.chinmayala.AccountInfo.fragments.edit.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Anwar on 7/31/2016.
 */
public class PaymentModel implements Serializable {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("member_login_id")
    @Expose
    private String memberLoginId;
    @SerializedName("total_child_donation")
    @Expose
    private String totalChildDonation;
    @SerializedName("child_ids")
    @Expose
    private String childIds;
    @SerializedName("cc_charges")
    @Expose
    private String ccCharges;
    @SerializedName("start_year")
    @Expose
    private String startYear;
    @SerializedName("end_year")
    @Expose
    private String endYear;
    @SerializedName("is_payment")
    @Expose
    private String isPayment;
    @SerializedName("payment_by")
    @Expose
    private String paymentBy;
    @SerializedName("cheque_no")
    @Expose
    private String chequeNo;
    @SerializedName("cheque_date")
    @Expose
    private String chequeDate;
    @SerializedName("case_date")
    @Expose
    private String caseDate;
    @SerializedName("payment_date")
    @Expose
    private String paymentDate;
    @SerializedName("magazine_pack_1")
    @Expose
    private String magazinePack1;
    @SerializedName("magazine_pack_2")
    @Expose
    private String magazinePack2;
    @SerializedName("aarati_fee")
    @Expose
    private String aaratiFee;
    @SerializedName("magfee")
    @Expose
    private String magfee;
    @SerializedName("member_fee")
    @Expose
    private String memberFee;
    @SerializedName("childfee")
    @Expose
    private String childfee;
    @SerializedName("serviceFees")
    @Expose
    private String serviceFees;
    @SerializedName("total_amount")
    @Expose
    private String totalAmount;
    @SerializedName("last_login_id")
    @Expose
    private Object lastLoginId;
    @SerializedName("last_updated")
    @Expose
    private String lastUpdated;
    @SerializedName("is_amnt_refund_requested")
    @Expose
    private String isAmntRefundRequested;
    @SerializedName("refund_rqst_amount")
    @Expose
    private Object refundRqstAmount;
    @SerializedName("request_by")
    @Expose
    private Object requestBy;
    @SerializedName("request_date")
    @Expose
    private Object requestDate;
    @SerializedName("refund_processd_amount")
    @Expose
    private Object refundProcessdAmount;
    @SerializedName("refund_cheque_no")
    @Expose
    private Object refundChequeNo;
    @SerializedName("refund_date")
    @Expose
    private Object refundDate;
    @SerializedName("refund_status")
    @Expose
    private String refundStatus;
    @SerializedName("payment_reason")
    @Expose
    private String paymentReason;

    public String getPaymentReason() {
        return paymentReason;
    }

    public void setPaymentReason(String paymentReason) {
        this.paymentReason = paymentReason;
    }

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The memberLoginId
     */
    public String getMemberLoginId() {
        return memberLoginId;
    }

    /**
     *
     * @param memberLoginId
     * The member_login_id
     */
    public void setMemberLoginId(String memberLoginId) {
        this.memberLoginId = memberLoginId;
    }

    /**
     *
     * @return
     * The totalChildDonation
     */
    public String getTotalChildDonation() {
        return totalChildDonation;
    }

    /**
     *
     * @param totalChildDonation
     * The total_child_donation
     */
    public void setTotalChildDonation(String totalChildDonation) {
        this.totalChildDonation = totalChildDonation;
    }

    /**
     *
     * @return
     * The childIds
     */
    public String getChildIds() {
        return childIds;
    }

    /**
     *
     * @param childIds
     * The child_ids
     */
    public void setChildIds(String childIds) {
        this.childIds = childIds;
    }

    /**
     *
     * @return
     * The ccCharges
     */
    public String getCcCharges() {
        return ccCharges;
    }

    /**
     *
     * @param ccCharges
     * The cc_charges
     */
    public void setCcCharges(String ccCharges) {
        this.ccCharges = ccCharges;
    }

    /**
     *
     * @return
     * The startYear
     */
    public String getStartYear() {
        return startYear;
    }

    /**
     *
     * @param startYear
     * The start_year
     */
    public void setStartYear(String startYear) {
        this.startYear = startYear;
    }

    /**
     *
     * @return
     * The endYear
     */
    public String getEndYear() {
        return endYear;
    }

    /**
     *
     * @param endYear
     * The end_year
     */
    public void setEndYear(String endYear) {
        this.endYear = endYear;
    }

    /**
     *
     * @return
     * The isPayment
     */
    public String getIsPayment() {
        return isPayment;
    }

    /**
     *
     * @param isPayment
     * The is_payment
     */
    public void setIsPayment(String isPayment) {
        this.isPayment = isPayment;
    }

    /**
     *
     * @return
     * The paymentBy
     */
    public String getPaymentBy() {
        return paymentBy;
    }

    /**
     *
     * @param paymentBy
     * The payment_by
     */
    public void setPaymentBy(String paymentBy) {
        this.paymentBy = paymentBy;
    }

    /**
     *
     * @return
     * The chequeNo
     */
    public String getChequeNo() {
        return chequeNo;
    }

    /**
     *
     * @param chequeNo
     * The cheque_no
     */
    public void setChequeNo(String chequeNo) {
        this.chequeNo = chequeNo;
    }

    /**
     *
     * @return
     * The chequeDate
     */
    public String getChequeDate() {
        return chequeDate;
    }

    /**
     *
     * @param chequeDate
     * The cheque_date
     */
    public void setChequeDate(String chequeDate) {
        this.chequeDate = chequeDate;
    }

    /**
     *
     * @return
     * The caseDate
     */
    public String getCaseDate() {
        return caseDate;
    }

    /**
     *
     * @param caseDate
     * The case_date
     */
    public void setCaseDate(String caseDate) {
        this.caseDate = caseDate;
    }

    /**
     *
     * @return
     * The paymentDate
     */
    public String getPaymentDate() {
        return paymentDate;
    }

    /**
     *
     * @param paymentDate
     * The payment_date
     */
    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    /**
     *
     * @return
     * The magazinePack1
     */
    public String getMagazinePack1() {
        return magazinePack1;
    }

    /**
     *
     * @param magazinePack1
     * The magazine_pack_1
     */
    public void setMagazinePack1(String magazinePack1) {
        this.magazinePack1 = magazinePack1;
    }

    /**
     *
     * @return
     * The magazinePack2
     */
    public String getMagazinePack2() {
        return magazinePack2;
    }

    /**
     *
     * @param magazinePack2
     * The magazine_pack_2
     */
    public void setMagazinePack2(String magazinePack2) {
        this.magazinePack2 = magazinePack2;
    }

    /**
     *
     * @return
     * The aaratiFee
     */
    public String getAaratiFee() {
        return aaratiFee;
    }

    /**
     *
     * @param aaratiFee
     * The aarati_fee
     */
    public void setAaratiFee(String aaratiFee) {
        this.aaratiFee = aaratiFee;
    }

    /**
     *
     * @return
     * The magfee
     */
    public String getMagfee() {
        return magfee;
    }

    /**
     *
     * @param magfee
     * The magfee
     */
    public void setMagfee(String magfee) {
        this.magfee = magfee;
    }

    /**
     *
     * @return
     * The memberFee
     */
    public String getMemberFee() {
        return memberFee;
    }

    /**
     *
     * @param memberFee
     * The member_fee
     */
    public void setMemberFee(String memberFee) {
        this.memberFee = memberFee;
    }

    /**
     *
     * @return
     * The childfee
     */
    public String getChildfee() {
        return childfee;
    }

    /**
     *
     * @param childfee
     * The childfee
     */
    public void setChildfee(String childfee) {
        this.childfee = childfee;
    }

    /**
     *
     * @return
     * The serviceFees
     */
    public String getServiceFees() {
        return serviceFees;
    }

    /**
     *
     * @param serviceFees
     * The serviceFees
     */
    public void setServiceFees(String serviceFees) {
        this.serviceFees = serviceFees;
    }

    /**
     *
     * @return
     * The totalAmount
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     *
     * @param totalAmount
     * The total_amount
     */
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     *
     * @return
     * The lastLoginId
     */
    public Object getLastLoginId() {
        return lastLoginId;
    }

    /**
     *
     * @param lastLoginId
     * The last_login_id
     */
    public void setLastLoginId(Object lastLoginId) {
        this.lastLoginId = lastLoginId;
    }

    /**
     *
     * @return
     * The lastUpdated
     */
    public String getLastUpdated() {
        return lastUpdated;
    }

    /**
     *
     * @param lastUpdated
     * The last_updated
     */
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    /**
     *
     * @return
     * The isAmntRefundRequested
     */
    public String getIsAmntRefundRequested() {
        return isAmntRefundRequested;
    }

    /**
     *
     * @param isAmntRefundRequested
     * The is_amnt_refund_requested
     */
    public void setIsAmntRefundRequested(String isAmntRefundRequested) {
        this.isAmntRefundRequested = isAmntRefundRequested;
    }

    /**
     *
     * @return
     * The refundRqstAmount
     */
    public Object getRefundRqstAmount() {
        return refundRqstAmount;
    }

    /**
     *
     * @param refundRqstAmount
     * The refund_rqst_amount
     */
    public void setRefundRqstAmount(Object refundRqstAmount) {
        this.refundRqstAmount = refundRqstAmount;
    }

    /**
     *
     * @return
     * The requestBy
     */
    public Object getRequestBy() {
        return requestBy;
    }

    /**
     *
     * @param requestBy
     * The request_by
     */
    public void setRequestBy(Object requestBy) {
        this.requestBy = requestBy;
    }

    /**
     *
     * @return
     * The requestDate
     */
    public Object getRequestDate() {
        return requestDate;
    }

    /**
     *
     * @param requestDate
     * The request_date
     */
    public void setRequestDate(Object requestDate) {
        this.requestDate = requestDate;
    }

    /**
     *
     * @return
     * The refundProcessdAmount
     */
    public Object getRefundProcessdAmount() {
        return refundProcessdAmount;
    }

    /**
     *
     * @param refundProcessdAmount
     * The refund_processd_amount
     */
    public void setRefundProcessdAmount(Object refundProcessdAmount) {
        this.refundProcessdAmount = refundProcessdAmount;
    }

    /**
     *
     * @return
     * The refundChequeNo
     */
    public Object getRefundChequeNo() {
        return refundChequeNo;
    }

    /**
     *
     * @param refundChequeNo
     * The refund_cheque_no
     */
    public void setRefundChequeNo(Object refundChequeNo) {
        this.refundChequeNo = refundChequeNo;
    }

    /**
     *
     * @return
     * The refundDate
     */
    public Object getRefundDate() {
        return refundDate;
    }

    /**
     *
     * @param refundDate
     * The refund_date
     */
    public void setRefundDate(Object refundDate) {
        this.refundDate = refundDate;
    }

    /**
     *
     * @return
     * The refundStatus
     */
    public String getRefundStatus() {
        return refundStatus;
    }

    /**
     *
     * @param refundStatus
     * The refund_status
     */
    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }
}
