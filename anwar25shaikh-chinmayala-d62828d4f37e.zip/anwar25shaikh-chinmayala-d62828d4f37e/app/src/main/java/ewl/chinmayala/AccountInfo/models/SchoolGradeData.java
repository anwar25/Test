package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar Shaikh on 7/20/2016.
 */
public class SchoolGradeData {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("grade_name")
    @Expose
    private String gradeName;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The gradeName
     */
    public String getGradeName() {
        return gradeName;
    }

    /**
     *
     * @param gradeName
     * The grade_name
     */
    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

}
