package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/19/2016.
 */
public class MemberRegModel {

    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("member1_emailid_1")
    @Expose
    private String member1Emailid1;
    @SerializedName("memberName1")
    @Expose
    private String memberName1;
    @SerializedName("member1_dob")
    @Expose
    private String member1Dob;
    @SerializedName("member1_password")
    @Expose
    private String member1Password;
    @SerializedName("member1_apartment")
    @Expose
    private String member1Apartment;
    @SerializedName("member1Address")
    @Expose
    private String member1Address;
    @SerializedName("member1_street_number")
    @Expose
    private String member1StreetNumber;
    @SerializedName("member1_route")
    @Expose
    private String member1Route;
    @SerializedName("member1_locality")
    @Expose
    private String member1Locality;
    @SerializedName("member1_state")
    @Expose
    private String member1State;
    @SerializedName("member1_postal_code")
    @Expose
    private String member1PostalCode;
    @SerializedName("member1_country")
    @Expose
    private String member1Country;
    @SerializedName("mamber1_homephone")
    @Expose
    private String mamber1Homephone;
    @SerializedName("mamber1_cellphone")
    @Expose
    private String mamber1Cellphone;
    @SerializedName("mamber1_profession")
    @Expose
    private String mamber1Profession;
    @SerializedName("mamber1_lang")
    @Expose
    private String mamber1Lang;
    @SerializedName("mamber1_officephone")
    @Expose
    private String mamber1Officephone;

    @SerializedName("verify_code")
    @Expose
    private String verifyCode;

    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("member_login_id")
    @Expose
    private String memberLoginId;

    @SerializedName("family_id")
    @Expose
    private String familyId;

    public String getFamilyId() {
        return familyId;
    }

    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The type
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     * The type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     *
     * @return
     * The memberLoginId
     */
    public String getMemberLoginId() {
        return memberLoginId;
    }

    /**
     *
     * @param memberLoginId
     * The member_login_id
     */
    public void setMemberLoginId(String memberLoginId) {
        this.memberLoginId = memberLoginId;
    }

    /**
     *
     * @return
     * The verifyCode
     */
    public String getVerifyCode() {
        return verifyCode;
    }

    /**
     *
     * @param verifyCode
     * The verify_code
     */
    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }
    /**
     *
     * @return
     * The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     *
     * @return
     * The member1Emailid1
     */
    public String getMember1Emailid1() {
        return member1Emailid1;
    }

    /**
     *
     * @param member1Emailid1
     * The member1_emailid_1
     */
    public void setMember1Emailid1(String member1Emailid1) {
        this.member1Emailid1 = member1Emailid1;
    }

    /**
     *
     * @return
     * The memberName1
     */
    public String getMemberName1() {
        return memberName1;
    }

    /**
     *
     * @param memberName1
     * The memberName1
     */
    public void setMemberName1(String memberName1) {
        this.memberName1 = memberName1;
    }

    /**
     *
     * @return
     * The member1Dob
     */
    public String getMember1Dob() {
        return member1Dob;
    }

    /**
     *
     * @param member1Dob
     * The member1_dob
     */
    public void setMember1Dob(String member1Dob) {
        this.member1Dob = member1Dob;
    }

    /**
     *
     * @return
     * The member1Password
     */
    public String getMember1Password() {
        return member1Password;
    }

    /**
     *
     * @param member1Password
     * The member1_password
     */
    public void setMember1Password(String member1Password) {
        this.member1Password = member1Password;
    }

    /**
     *
     * @return
     * The member1Apartment
     */
    public String getMember1Apartment() {
        return member1Apartment;
    }

    /**
     *
     * @param member1Apartment
     * The member1_apartment
     */
    public void setMember1Apartment(String member1Apartment) {
        this.member1Apartment = member1Apartment;
    }

    /**
     *
     * @return
     * The member1Address
     */
    public String getMember1Address() {
        return member1Address;
    }

    /**
     *
     * @param member1Address
     * The member1Address
     */
    public void setMember1Address(String member1Address) {
        this.member1Address = member1Address;
    }

    /**
     *
     * @return
     * The member1StreetNumber
     */
    public String getMember1StreetNumber() {
        return member1StreetNumber;
    }

    /**
     *
     * @param member1StreetNumber
     * The member1_street_number
     */
    public void setMember1StreetNumber(String member1StreetNumber) {
        this.member1StreetNumber = member1StreetNumber;
    }

    /**
     *
     * @return
     * The member1Route
     */
    public String getMember1Route() {
        return member1Route;
    }

    /**
     *
     * @param member1Route
     * The member1_route
     */
    public void setMember1Route(String member1Route) {
        this.member1Route = member1Route;
    }

    /**
     *
     * @return
     * The member1Locality
     */
    public String getMember1Locality() {
        return member1Locality;
    }

    /**
     *
     * @param member1Locality
     * The member1_locality
     */
    public void setMember1Locality(String member1Locality) {
        this.member1Locality = member1Locality;
    }

    /**
     *
     * @return
     * The member1State
     */
    public String getMember1State() {
        return member1State;
    }

    /**
     *
     * @param member1State
     * The member1_state
     */
    public void setMember1State(String member1State) {
        this.member1State = member1State;
    }

    /**
     *
     * @return
     * The member1PostalCode
     */
    public String getMember1PostalCode() {
        return member1PostalCode;
    }

    /**
     *
     * @param member1PostalCode
     * The member1_postal_code
     */
    public void setMember1PostalCode(String member1PostalCode) {
        this.member1PostalCode = member1PostalCode;
    }

    /**
     *
     * @return
     * The member1Country
     */
    public String getMember1Country() {
        return member1Country;
    }

    /**
     *
     * @param member1Country
     * The member1_country
     */
    public void setMember1Country(String member1Country) {
        this.member1Country = member1Country;
    }

    /**
     *
     * @return
     * The mamber1Homephone
     */
    public String getMamber1Homephone() {
        return mamber1Homephone;
    }

    /**
     *
     * @param mamber1Homephone
     * The mamber1_homephone
     */
    public void setMamber1Homephone(String mamber1Homephone) {
        this.mamber1Homephone = mamber1Homephone;
    }

    /**
     *
     * @return
     * The mamber1Cellphone
     */
    public String getMamber1Cellphone() {
        return mamber1Cellphone;
    }

    /**
     *
     * @param mamber1Cellphone
     * The mamber1_cellphone
     */
    public void setMamber1Cellphone(String mamber1Cellphone) {
        this.mamber1Cellphone = mamber1Cellphone;
    }

    /**
     *
     * @return
     * The mamber1Profession
     */
    public String getMamber1Profession() {
        return mamber1Profession;
    }

    /**
     *
     * @param mamber1Profession
     * The mamber1_profession
     */
    public void setMamber1Profession(String mamber1Profession) {
        this.mamber1Profession = mamber1Profession;
    }

    /**
     *
     * @return
     * The mamber1Lang
     */
    public String getMamber1Lang() {
        return mamber1Lang;
    }

    /**
     *
     * @param mamber1Lang
     * The mamber1_lang
     */
    public void setMamber1Lang(String mamber1Lang) {
        this.mamber1Lang = mamber1Lang;
    }

    /**
     *
     * @return
     * The mamber1Officephone
     */
    public String getMamber1Officephone() {
        return mamber1Officephone;
    }

    /**
     *
     * @param mamber1Officephone
     * The mamber1_officephone
     */
    public void setMamber1Officephone(String mamber1Officephone) {
        this.mamber1Officephone = mamber1Officephone;
    }

}
