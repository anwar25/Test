package ewl.chinmayala.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;

import ewl.chinmayala.R;

/**
 * Created by Anwar on 7/31/2016.
 */
public class AlertDialogUtility {

    public static void showDeleteDialog(final Context mContext,
                                        final String title, final String msg,
                                        final String positiveBtnCaption, final String negativeBtnCaption,
                                        final boolean isCancelable, final AlertMagnatic target) {

        ((Activity) mContext).runOnUiThread(new Runnable() {

            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

                int imageResource = R.drawable.ic_delete_red_24dp;
                Drawable image = ContextCompat.getDrawable(mContext,imageResource);

                builder.setTitle(title)
                        .setMessage(msg)
                        .setIcon(image)
                        .setCancelable(false)
                        .setPositiveButton(positiveBtnCaption,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        target.onButtonClicked(true);
                                    }
                                })
                        .setNegativeButton(negativeBtnCaption,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        target.onButtonClicked(false);
                                    }
                                });

                AlertDialog alert = builder.create();
                alert.setCancelable(isCancelable);
                alert.show();
                alert.getWindow().setBackgroundDrawableResource(R.color.light_white);
                if (isCancelable) {
                    alert.setOnCancelListener(new DialogInterface.OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface arg0) {
                            target.onButtonClicked(false);
                        }
                    });
                }
            }
        });

    }

    public static void showDialog(final Context mContext,
                                        final String title, final String msg,
                                        final String positiveBtnCaption, final String negativeBtnCaption,
                                        final boolean isCancelable, final AlertMagnatic target) {

        ((Activity) mContext).runOnUiThread(new Runnable() {

            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

                builder
                        .setTitle(title)
                        .setMessage(msg)
                        .setCancelable(false)
                        .setPositiveButton(positiveBtnCaption,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        target.onButtonClicked(true);
                                    }
                                })
                        .setNegativeButton(negativeBtnCaption,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        target.onButtonClicked(false);
                                    }
                                });

                AlertDialog alert = builder.create();
                alert.setCancelable(isCancelable);
                alert.show();
                alert.getWindow().setBackgroundDrawableResource(R.color.light_white);
                if (isCancelable) {
                    alert.setOnCancelListener(new DialogInterface.OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface arg0) {
                            target.onButtonClicked(false);
                        }
                    });
                }
            }
        });

    }
}
