package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 7/2/2016.
 */
public class LanguageResponseModel {
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private List<LanguageData> languageDataList = new ArrayList<LanguageData>();

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<LanguageData> getLanguageDataList() {
        return languageDataList;
    }

    public void setLanguageDataList(List<LanguageData> languageDataList) {
        this.languageDataList = languageDataList;
    }

}
