package ewl.chinmayala.Entity;

/**
 * Created by Akash.Singh on 2/10/2016.
 */
public class Event {

    int id ;
    String EventTitle;
    String EventSubTitle;
    String EventStartDateTime;
    String EventEndTime;
    String EventAddress;
    double EventLatitude;
    double EventLongitude;
    String Resource;

    public String getEventSubTitle() {
        return EventSubTitle;
    }

    public void setEventSubTitle(String eventSubTitle) {
        EventSubTitle = eventSubTitle;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEventTitle() {
        return EventTitle;
    }

    public void setEventTitle(String eventTitle) {
        EventTitle = eventTitle;
    }

    public String getEventStartDateTime() {
        return EventStartDateTime;
    }

    public void setEventStartDateTime(String eventStartDateTime) {
        EventStartDateTime = eventStartDateTime;
    }

    public String getEventEndTime() {
        return EventEndTime;
    }

    public void setEventEndTime(String eventEndTime) {
        EventEndTime = eventEndTime;
    }

    public String getEventAddress() {
        return EventAddress;
    }

    public void setEventAddress(String eventAddress) {
        EventAddress = eventAddress;
    }

    public double getEventLatitude() {
        return EventLatitude;
    }

    public void setEventLatitude(double eventLatitude) {
        EventLatitude = eventLatitude;
    }

    public double getEventLongitude() {
        return EventLongitude;
    }

    public void setEventLongitude(double eventLongitude) {
        EventLongitude = eventLongitude;
    }

    public String getResource() {
        return Resource;
    }

    public void setResource(String resource) {
        Resource = resource;
    }
}
