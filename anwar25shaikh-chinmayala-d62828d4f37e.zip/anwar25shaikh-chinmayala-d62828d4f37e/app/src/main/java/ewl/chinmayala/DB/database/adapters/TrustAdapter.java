package ewl.chinmayala.DB.database.adapters;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.google.gson.Gson;

import java.util.ArrayList;

import ewl.chinmayala.AccountInfo.models.TrustRegModel;
import ewl.chinmayala.DB.ChinTable;

/**
 * Created by Anwar on 7/22/2016.
 */
public class TrustAdapter extends ParentAdapter {
    @Override
    public long insert(Object model) {
        long rowID = -1;
        TrustRegModel loginData  = (TrustRegModel)model ;
        Gson gson = new Gson();
        SQLiteDatabase sqLiteDatabase = null;
        ContentValues contentValues = new ContentValues();
        try {
            sqLiteDatabase = openDB();
            contentValues.put(ChinTable.Trust.COLUMN_NAME_TRUST_DATA,gson.toJson(loginData));

            rowID = sqLiteDatabase.insert(ChinTable.Trust.TABLE_NAME, null, contentValues);
            if (rowID == -1) {
                Log.v(TAG, "- unsuccessful insert operation");
                throw new SQLiteException("Insertion failed :" + model.toString());
            }
            sqLiteDatabase.setTransactionSuccessful();
        } catch (SQLiteException exception) {
            Log.e(TAG, exception.getMessage());
        } finally {
            closeDB();
        }
        return rowID;
    }

    @Override
    public boolean delete(String id) {
        return false;
    }

    @Override
    public boolean update(Object model) {
        return false;
    }

    @Override
    public ArrayList<TrustRegModel> getAll() {
        ArrayList<TrustRegModel> loginDataArrayList = new ArrayList<TrustRegModel>();

        String selectQuery = new StringBuilder(ChinTable.SELECT_STAR_FROM).
                append(ChinTable.Trust.TABLE_NAME).append(";").toString();

        Cursor cursor = null;
        try {
            Gson gson = new Gson();
            SQLiteDatabase database = openDBForReadOperation();
            cursor = database.rawQuery(selectQuery, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    loginDataArrayList.add( gson.fromJson(cursor.getString(
                            cursor.getColumnIndex(ChinTable.Trust.COLUMN_NAME_TRUST_DATA)),TrustRegModel.class));
                }
                return loginDataArrayList;
            }
        } catch (SQLiteException exception) {
            Log.e(TAG, exception.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
                //closeDB();
            }
        }
        return null;
    }
}
