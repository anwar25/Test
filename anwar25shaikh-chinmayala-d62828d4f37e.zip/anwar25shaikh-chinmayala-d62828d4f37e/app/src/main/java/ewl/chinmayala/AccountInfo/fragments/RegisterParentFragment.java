package ewl.chinmayala.AccountInfo.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.AppCompatImageView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;

import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.R;

/**
 * Created by Anwar Shaikh on 2/11/2016.
 */
public class RegisterParentFragment extends Fragment implements View.OnClickListener{


    private ViewPager mViewPager;
   // private TabLayout mTabLayout;

    private ArrayAdapter<String> mCenterAdapter ;

    private LinearLayout memberRegisterLayout2 ;
    private AppCompatImageView registerIcon2 ;
    private View registerLine1 ;
    private LinearLayout memberRegisterLayout3;
    private AppCompatImageView registerIcon3;
    private View registerLine2;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.content_register_screen, container, false);
        mapControls(rootView);
        ((HomeActivity) getActivity()).setToolbarInitialization(this, getString(R.string.register));
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mViewPager = null;
        mCenterAdapter = null;
        memberRegisterLayout2 = null;
        registerIcon2 = null;
        registerLine1 = null;
        memberRegisterLayout3 = null;
        registerIcon3 = null;
        registerLine2 = null;
    }

    private void mapControls(View rootView) {
       /* mViewPager = (ViewPager) rootView.findViewById(R.id.childContainer);
        if (mViewPager != null) {
            setupViewPager(mViewPager);
        }*/


       //  mTabLayout = (TabLayout) rootView.findViewById(R.id.tabs);
       //  mTabLayout.setupWithViewPager(mViewPager);
        memberRegisterLayout2 = (LinearLayout)rootView.findViewById(R.id.ll_register_icon_2) ;
        registerIcon2 = (AppCompatImageView)rootView.findViewById(R.id.img_register_icon_2) ;
        registerLine1 = (View)rootView.findViewById(R.id.Review01);

        memberRegisterLayout3 = (LinearLayout)rootView.findViewById(R.id.ll_register_icon_3) ;
        registerIcon3 = (AppCompatImageView)rootView.findViewById(R.id.img_register_icon_3) ;
        registerLine2 = (View)rootView.findViewById(R.id.Review02);

        replaceChildFragment(new UserRegisterFragment());
    }

    public void replaceChildFragment(Fragment fragment){

        if(fragment instanceof AddChildFragment){
            registerLine1.setBackgroundColor(ContextCompat.getColor(getActivity(),R.color.colorPrimary));
            memberRegisterLayout2.setBackgroundResource(R.drawable.circle_img_blue);
            registerIcon2.setImageResource(R.drawable.ic_balavihar_kids_blue);
        }
        if(fragment instanceof PaymentFragment){
            registerLine2.setBackgroundColor(ContextCompat.getColor(getActivity(),R.color.colorPrimary));
            memberRegisterLayout3.setBackgroundResource(R.drawable.circle_img_blue);
            registerIcon3.setImageResource(R.drawable.ic_balavihar_card_blue);
        }
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        if(fragment instanceof AddChildFragment || fragment instanceof PaymentFragment)
            transaction.setCustomAnimations( R.anim.enter_from_right, R.anim.exit_to_left);
        transaction.replace(R.id.childContainer,  fragment).commit();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
        }
    }

}
