package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/26/2016.
 */
public class ForgotPasRes {

    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private String userdata;

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     *
     * @return
     * The userdata
     */
    public String getUserdata() {
        return userdata;
    }

    /**
     *
     * @param userdata
     * The userdata
     */
    public void setUserdata(String userdata) {
        this.userdata = userdata;
    }

}
