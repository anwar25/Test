package ewl.chinmayala.DB;

import android.database.sqlite.SQLiteDatabase;

/**
 * <p>Class for Database connections, It returns singleton instance of DB.</p>
 *
 * @author Anwar Shaikh
 */
public class ChinDbManager {

    public static final String TAG = "ChinDbManager";

    private static ChinDbManager mDatabaseManager;
    private static ChinDbHelper mDatabaseHelper;
    private static SQLiteDatabase mDatabase = null ;

    /**
     * Method to initialize db instance
     * @param helper
     */
    public static synchronized void initializeInstance(ChinDbHelper helper) {

        if (mDatabaseManager == null) {
            mDatabaseManager = new ChinDbManager();
            mDatabaseHelper = (ChinDbHelper)helper;
        }
    }

    /**
     *  Terminating db connections
     */
    public static synchronized void terminate() {
        closeDatabase();
        mDatabaseManager = null ;
        mDatabaseHelper = null ;
        mDatabase = null ;
    }

    /**
     * Class for creating singletone instance of database
     * @return ChinDbManager instance
     */
    public static synchronized ChinDbManager getInstance() {
        if (mDatabaseManager == null) {
            throw new IllegalStateException(ChinDbManager.class.getSimpleName() +
                    " is not initialized, call initializeInstance(..) method first.");
        }
        return mDatabaseManager;
    }

    /**
     * Method to open DB connection
     * @return SQLiteDatabase instance
     */
    public synchronized SQLiteDatabase openDatabase() {
        if(mDatabase == null) {
            // Opening new database
            mDatabase = mDatabaseHelper.getWritableDatabase();
        }
        return mDatabase;
    }

    /**
     * Method to close DB connections
     */
    public static synchronized void closeDatabase() {
            if(mDatabase != null){
                mDatabase.close();
            }
    }


    public static ChinDbHelper getDbHelperInstance() {
        if (mDatabaseHelper != null) {
            return mDatabaseHelper;
        }
        return null ;
    }

    public static void resetDatabase(){
        if(mDatabase == null) {
            // Opening new database
            mDatabase = mDatabaseHelper.getWritableDatabase();
        }
        mDatabase.execSQL("DROP TABLE IF EXISTS " + ChinTable.Member.TABLE_NAME);
        mDatabase.execSQL("DROP TABLE IF EXISTS " + ChinTable.Trust.TABLE_NAME);
        mDatabase.execSQL("DROP TABLE IF EXISTS " + ChinTable.Child.TABLE_NAME);
        mDatabase.execSQL(ChinTable.SQL_CREATE_MEMBER);
        mDatabase.execSQL(ChinTable.SQL_CREATE_CHILD);
        mDatabase.execSQL(ChinTable.SQL_CREATE_TRUST);
    }

}