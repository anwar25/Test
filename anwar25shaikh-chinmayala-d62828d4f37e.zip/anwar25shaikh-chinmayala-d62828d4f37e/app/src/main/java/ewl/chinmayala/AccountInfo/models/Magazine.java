package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 449781 on 8/3/2016.
 */
public class Magazine {
    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("mag_pack_id")
    @Expose
    private String magPackId;
    @SerializedName("mag_name")
    @Expose
    private String magName;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("magpack_name")
    @Expose
    private String magpackName;
    @SerializedName("is_free")
    @Expose
    private String isFree;

    /**
     *
     * @return
     * The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     *
     * @return
     * The magPackId
     */
    public String getMagPackId() {
        return magPackId;
    }

    /**
     *
     * @param magPackId
     * The mag_pack_id
     */
    public void setMagPackId(String magPackId) {
        this.magPackId = magPackId;
    }

    /**
     *
     * @return
     * The magName
     */
    public String getMagName() {
        return magName;
    }

    /**
     *
     * @param magName
     * The mag_name
     */
    public void setMagName(String magName) {
        this.magName = magName;
    }

    /**
     *
     * @return
     * The price
     */
    public String getPrice() {
        return price;
    }

    /**
     *
     * @param price
     * The price
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     *
     * @return
     * The magpackName
     */
    public String getMagpackName() {
        return magpackName;
    }

    /**
     *
     * @param magpackName
     * The magpack_name
     */
    public void setMagpackName(String magpackName) {
        this.magpackName = magpackName;
    }

    /**
     *
     * @return
     * The isFree
     */
    public String getIsFree() {
        return isFree;
    }

    /**
     *
     * @param isFree
     * The is_free
     */
    public void setIsFree(String isFree) {
        this.isFree = isFree;
    }

}
