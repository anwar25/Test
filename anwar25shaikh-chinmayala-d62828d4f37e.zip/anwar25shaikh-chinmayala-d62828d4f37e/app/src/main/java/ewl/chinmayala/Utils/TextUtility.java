package ewl.chinmayala.Utils;

import android.text.TextUtils;

/**
 * Created by Akash.Singh on 1/6/2015.
 */
public class TextUtility {

    public static String checkIsStringEmpty(String string) {

        if (TextUtils.isEmpty(string))
            return "";
        else if (string.equals("null"))
            return "";
        else return string;
    }

    public static String checkIsIntegerEmpty(String string) {

        if (TextUtils.isEmpty(string))
            return "0";
        else if (string.equals("null"))
            return "0";

        else return string;
    }

    public static String checkIsStringDoubleEmpty(String string) {

        if (TextUtils.isEmpty(string))
            return "0.00";
        else if (string.equals("null"))
            return "0.00";
        else return string;
    }

}
