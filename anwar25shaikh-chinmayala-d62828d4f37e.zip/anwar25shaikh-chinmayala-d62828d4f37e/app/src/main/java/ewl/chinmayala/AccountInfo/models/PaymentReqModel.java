package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 8/10/2016.
 */
public class PaymentReqModel {
    @SerializedName("payment_method")
    @Expose
    private String paymentMethod;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("member_login_id")
    @Expose
    private String memberLoginId;
    @SerializedName("member_email")
    @Expose
    private String memberEmail;
    @SerializedName("member_firstname")
    @Expose
    private String memberFirstname;
    @SerializedName("member_lastname")
    @Expose
    private String memberLastname;
    @SerializedName("child_id")
    @Expose
    private List<String> childId = new ArrayList<String>();
    @SerializedName("child_session_id")
    @Expose
    private List<String> childSessionId = new ArrayList<String>();
    @SerializedName("child_language_id")
    @Expose
    private List<String> childLanguageId = new ArrayList<String>();
    @SerializedName("child_shruticlass")
    @Expose
    private List<String> childShruticlass = new ArrayList<String>();
    @SerializedName("magazine_pack_balavihar")
    @Expose
    private String magazinePackBalavihar;
    @SerializedName("magazine_pack_udgosh")
    @Expose
    private String magazinePackUdgosh;
    @SerializedName("magazine_pack_TapovanPrasad")
    @Expose
    private String magazinePackTapovanPrasad;
    @SerializedName("magazine_pack_Mananam")
    @Expose
    private String magazinePackMananam;
    @SerializedName("aarati_fee")
    @Expose
    private String aaratiFee;
    @SerializedName("magazine_fees")
    @Expose
    private String magazineFees;
    @SerializedName("child_fees")
    @Expose
    private String childFees;
    @SerializedName("service_fees")
    @Expose
    private String serviceFees;
    @SerializedName("total_amount")
    @Expose
    private String totalAmount;
    @SerializedName("txt_cheque_no")
    @Expose
    private String txtChequeNo;
    @SerializedName("cheque_date")
    @Expose
    private String chequeDate;
    @SerializedName("token")
    @Expose
    private String token;
    @SerializedName("amount")
    @Expose
    private String amount;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("checkout_status")
    @Expose
    private String checkoutStatus;
    @SerializedName("payer_id")
    @Expose
    private String payerId;
    @SerializedName("transaction_id")
    @Expose
    private String transactionId;
    @SerializedName("ack")
    @Expose
    private String ack;

    @SerializedName("member_interest")
    @Expose
    private List<MemberInterest> memberInterest = new ArrayList<MemberInterest>();


    public List<MemberInterest> getMemberInterest() {
        return memberInterest;
    }

    public void setMemberInterest(List<MemberInterest> memberInterest) {
        this.memberInterest = memberInterest;
    }

    /**
     *
     * @return
     * The paymentMethod
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     *
     * @param paymentMethod
     * The payment_method
     */
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The memberLoginId
     */
    public String getMemberLoginId() {
        return memberLoginId;
    }

    /**
     *
     * @param memberLoginId
     * The member_login_id
     */
    public void setMemberLoginId(String memberLoginId) {
        this.memberLoginId = memberLoginId;
    }

    /**
     *
     * @return
     * The memberEmail
     */
    public String getMemberEmail() {
        return memberEmail;
    }

    /**
     *
     * @param memberEmail
     * The member_email
     */
    public void setMemberEmail(String memberEmail) {
        this.memberEmail = memberEmail;
    }

    /**
     *
     * @return
     * The memberFirstname
     */
    public String getMemberFirstname() {
        return memberFirstname;
    }

    /**
     *
     * @param memberFirstname
     * The member_firstname
     */
    public void setMemberFirstname(String memberFirstname) {
        this.memberFirstname = memberFirstname;
    }

    /**
     *
     * @return
     * The memberLastname
     */
    public String getMemberLastname() {
        return memberLastname;
    }

    /**
     *
     * @param memberLastname
     * The member_lastname
     */
    public void setMemberLastname(String memberLastname) {
        this.memberLastname = memberLastname;
    }

    /**
     *
     * @return
     * The childId
     */
    public List<String> getChildId() {
        return childId;
    }

    /**
     *
     * @param childId
     * The child_id
     */
    public void setChildId(List<String> childId) {
        this.childId = childId;
    }

    /**
     *
     * @return
     * The childSessionId
     */
    public List<String> getChildSessionId() {
        return childSessionId;
    }

    /**
     *
     * @param childSessionId
     * The child_session_id
     */
    public void setChildSessionId(List<String> childSessionId) {
        this.childSessionId = childSessionId;
    }

    /**
     *
     * @return
     * The childLanguageId
     */
    public List<String> getChildLanguageId() {
        return childLanguageId;
    }

    /**
     *
     * @param childLanguageId
     * The child_language_id
     */
    public void setChildLanguageId(List<String> childLanguageId) {
        this.childLanguageId = childLanguageId;
    }

    /**
     *
     * @return
     * The childShruticlass
     */
    public List<String> getChildShruticlass() {
        return childShruticlass;
    }

    /**
     *
     * @param childShruticlass
     * The child_shruticlass
     */
    public void setChildShruticlass(List<String> childShruticlass) {
        this.childShruticlass = childShruticlass;
    }

    /**
     *
     * @return
     * The magazinePackBalavihar
     */
    public String getMagazinePackBalavihar() {
        return magazinePackBalavihar;
    }

    /**
     *
     * @param magazinePackBalavihar
     * The magazine_pack_balavihar
     */
    public void setMagazinePackBalavihar(String magazinePackBalavihar) {
        this.magazinePackBalavihar = magazinePackBalavihar;
    }

    /**
     *
     * @return
     * The magazinePackUdgosh
     */
    public String getMagazinePackUdgosh() {
        return magazinePackUdgosh;
    }

    /**
     *
     * @param magazinePackUdgosh
     * The magazine_pack_udgosh
     */
    public void setMagazinePackUdgosh(String magazinePackUdgosh) {
        this.magazinePackUdgosh = magazinePackUdgosh;
    }

    /**
     *
     * @return
     * The magazinePackTapovanPrasad
     */
    public String getMagazinePackTapovanPrasad() {
        return magazinePackTapovanPrasad;
    }

    /**
     *
     * @param magazinePackTapovanPrasad
     * The magazine_pack_TapovanPrasad
     */
    public void setMagazinePackTapovanPrasad(String magazinePackTapovanPrasad) {
        this.magazinePackTapovanPrasad = magazinePackTapovanPrasad;
    }

    /**
     *
     * @return
     * The magazinePackMananam
     */
    public String getMagazinePackMananam() {
        return magazinePackMananam;
    }

    /**
     *
     * @param magazinePackMananam
     * The magazine_pack_Mananam
     */
    public void setMagazinePackMananam(String magazinePackMananam) {
        this.magazinePackMananam = magazinePackMananam;
    }

    /**
     *
     * @return
     * The aaratiFee
     */
    public String getAaratiFee() {
        return aaratiFee;
    }

    /**
     *
     * @param aaratiFee
     * The aarati_fee
     */
    public void setAaratiFee(String aaratiFee) {
        this.aaratiFee = aaratiFee;
    }

    /**
     *
     * @return
     * The magazineFees
     */
    public String getMagazineFees() {
        return magazineFees;
    }

    /**
     *
     * @param magazineFees
     * The magazine_fees
     */
    public void setMagazineFees(String magazineFees) {
        this.magazineFees = magazineFees;
    }

    /**
     *
     * @return
     * The childFees
     */
    public String getChildFees() {
        return childFees;
    }

    /**
     *
     * @param childFees
     * The child_fees
     */
    public void setChildFees(String childFees) {
        this.childFees = childFees;
    }

    /**
     *
     * @return
     * The serviceFees
     */
    public String getServiceFees() {
        return serviceFees;
    }

    /**
     *
     * @param serviceFees
     * The service_fees
     */
    public void setServiceFees(String serviceFees) {
        this.serviceFees = serviceFees;
    }

    /**
     *
     * @return
     * The totalAmount
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     *
     * @param totalAmount
     * The total_amount
     */
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     *
     * @return
     * The txtChequeNo
     */
    public String getTxtChequeNo() {
        return txtChequeNo;
    }

    /**
     *
     * @param txtChequeNo
     * The txt_cheque_no
     */
    public void setTxtChequeNo(String txtChequeNo) {
        this.txtChequeNo = txtChequeNo;
    }

    /**
     *
     * @return
     * The chequeDate
     */
    public String getChequeDate() {
        return chequeDate;
    }

    /**
     *
     * @param chequeDate
     * The cheque_date
     */
    public void setChequeDate(String chequeDate) {
        this.chequeDate = chequeDate;
    }

    /**
     *
     * @return
     * The token
     */
    public String getToken() {
        return token;
    }

    /**
     *
     * @param token
     * The token
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     *
     * @return
     * The amount
     */
    public String getAmount() {
        return amount;
    }

    /**
     *
     * @param amount
     * The amount
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     *
     * @return
     * The currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency
     * The currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return
     * The checkoutStatus
     */
    public String getCheckoutStatus() {
        return checkoutStatus;
    }

    /**
     *
     * @param checkoutStatus
     * The checkout_status
     */
    public void setCheckoutStatus(String checkoutStatus) {
        this.checkoutStatus = checkoutStatus;
    }

    /**
     *
     * @return
     * The payerId
     */
    public String getPayerId() {
        return payerId;
    }

    /**
     *
     * @param payerId
     * The payer_id
     */
    public void setPayerId(String payerId) {
        this.payerId = payerId;
    }

    /**
     *
     * @return
     * The transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     *
     * @param transactionId
     * The transaction_id
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     *
     * @return
     * The ack
     */
    public String getAck() {
        return ack;
    }

    /**
     *
     * @param ack
     * The ack
     */
    public void setAck(String ack) {
        this.ack = ack;
    }
}
