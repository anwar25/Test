package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 7/20/2016.
 */
public class BvClassListResModel {

    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private List<BvClass> userdata = new ArrayList<BvClass>();

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     *
     * @return
     * The userdata
     */
    public List<BvClass> getUserdata() {
        return userdata;
    }

    /**
     *
     * @param userdata
     * The userdata
     */
    public void setUserdata(List<BvClass> userdata) {
        this.userdata = userdata;
    }

}