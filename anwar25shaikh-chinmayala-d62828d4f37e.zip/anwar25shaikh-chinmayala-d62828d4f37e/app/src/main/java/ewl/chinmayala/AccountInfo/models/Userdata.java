package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/3/2016.
 */
public class Userdata {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("session_id")
    @Expose
    private String sessionId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("emailid")
    @Expose
    private String emailid;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("old_password")
    @Expose
    private String oldPassword;
    @SerializedName("designation_master_id")
    @Expose
    private String designationMasterId;
    @SerializedName("create_date")
    @Expose
    private String createDate;
    @SerializedName("terminate_date")
    @Expose
    private Object terminateDate;
    @SerializedName("is_active")
    @Expose
    private String isActive;
    @SerializedName("other")
    @Expose
    private String other;
    @SerializedName("forgot_pass_code")
    @Expose
    private Object forgotPassCode;
    @SerializedName("member_type")
    @Expose
    private Object memberType;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     *
     * @return
     * The sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     *
     * @param sessionId
     * The session_id
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     *
     * @return
     * The name
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     * The name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     * The dob
     */
    public String getDob() {
        return dob;
    }

    /**
     *
     * @param dob
     * The dob
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     *
     * @return
     * The emailid
     */
    public String getEmailid() {
        return emailid;
    }

    /**
     *
     * @param emailid
     * The emailid
     */
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    /**
     *
     * @return
     * The password
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     * The password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return
     * The oldPassword
     */
    public String getOldPassword() {
        return oldPassword;
    }

    /**
     *
     * @param oldPassword
     * The old_password
     */
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    /**
     *
     * @return
     * The designationMasterId
     */
    public String getDesignationMasterId() {
        return designationMasterId;
    }

    /**
     *
     * @param designationMasterId
     * The designation_master_id
     */
    public void setDesignationMasterId(String designationMasterId) {
        this.designationMasterId = designationMasterId;
    }

    /**
     *
     * @return
     * The createDate
     */
    public String getCreateDate() {
        return createDate;
    }

    /**
     *
     * @param createDate
     * The create_date
     */
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    /**
     *
     * @return
     * The terminateDate
     */
    public Object getTerminateDate() {
        return terminateDate;
    }

    /**
     *
     * @param terminateDate
     * The terminate_date
     */
    public void setTerminateDate(Object terminateDate) {
        this.terminateDate = terminateDate;
    }

    /**
     *
     * @return
     * The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     *
     * @param isActive
     * The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    /**
     *
     * @return
     * The other
     */
    public String getOther() {
        return other;
    }

    /**
     *
     * @param other
     * The other
     */
    public void setOther(String other) {
        this.other = other;
    }

    /**
     *
     * @return
     * The forgotPassCode
     */
    public Object getForgotPassCode() {
        return forgotPassCode;
    }

    /**
     *
     * @param forgotPassCode
     * The forgot_pass_code
     */
    public void setForgotPassCode(Object forgotPassCode) {
        this.forgotPassCode = forgotPassCode;
    }

    /**
     *
     * @return
     * The memberType
     */
    public Object getMemberType() {
        return memberType;
    }

    /**
     *
     * @param memberType
     * The member_type
     */
    public void setMemberType(Object memberType) {
        this.memberType = memberType;
    }

}
