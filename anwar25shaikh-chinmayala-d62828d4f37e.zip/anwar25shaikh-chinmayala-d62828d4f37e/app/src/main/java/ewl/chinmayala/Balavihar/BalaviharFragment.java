package ewl.chinmayala.Balavihar;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import ewl.chinmayala.AccountInfo.fragments.DashboardFragment;
import ewl.chinmayala.AccountInfo.fragments.LoginFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.R;
import ewl.chinmayala.Utils.Utils;
import ewl.chinmayala.constants.Constants;

/**
 * Created by Akash.Singh on 2/11/2016.
 */
public class BalaviharFragment extends Fragment implements OnClickListener {

    private HomeActivity activityHandle;

    private Button mDashboardButton ;
    private Button mCalendarButton ;
    private Button mBlogButton ;
    private Button mServiceCenterButton ;
    private Button mCompetitionButton ;
    private Button mSyllabusButton ;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_balavihar_screen,container,false);
        ((HomeActivity)getActivity()).setToolbarInitialization(this, getString(R.string.menu_balavihar));
        MidMapping(view);
        return view;
    }

    private void MidMapping(View view) {

        mDashboardButton =((Button) view.findViewById(R.id.cb_balavihar_dashboard));
        mDashboardButton.setOnClickListener(this);

        mCalendarButton =((Button) view.findViewById(R.id.cb_balavihar_calendar));
        mCalendarButton.setOnClickListener(this);

        mBlogButton = ((Button) view.findViewById(R.id.cb_balavihar_blog));
        mBlogButton.setOnClickListener(this);

        mServiceCenterButton = ((Button) view.findViewById(R.id.cb_balavihar_satellite_center));
        mServiceCenterButton.setOnClickListener(this);
        mCompetitionButton = ((Button) view.findViewById(R.id.cb_balavihar_competition));
        mCompetitionButton.setOnClickListener(this);
        mSyllabusButton = ((Button) view.findViewById(R.id.cb_balavihar_syllabus));
        mSyllabusButton.setOnClickListener(this);

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity){
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //activityHandle= null ;
        mDashboardButton = null ;
        mCalendarButton = null ;
        mBlogButton = null ;
        mServiceCenterButton = null ;
        mCompetitionButton= null  ;
        mSyllabusButton = null ;
    }

    @Override
    public void onClick(View buttonView) {
        switch (buttonView.getId()){
            case R.id.cb_balavihar_dashboard:
               // ((HomeActivity)getActivity()).onReplaceFragment(new LoginFragment(), true);
            case R.id.text_balavihar_dashboard:
                String userResponse = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
                if(!TextUtils.isEmpty(userResponse)){
                    ((HomeActivity)getActivity()).onReplaceFragment(new DashboardFragment(), true);
                }else{
                    ((HomeActivity)getActivity()).onReplaceFragment(new LoginFragment(), true);
                }

                break;
            case R.id.cb_balavihar_calendar:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.text_balavihar_calendar:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.cb_balavihar_blog:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.text_balavihar_blog:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.cb_balavihar_satellite_center:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.text_balavihar_satellite_center:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.cb_balavihar_competition:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.text_balavihar_competition:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.cb_balavihar_syllabus:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
            case R.id.text_balavihar_syllabus:
                Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                break;
        }
    }
}
