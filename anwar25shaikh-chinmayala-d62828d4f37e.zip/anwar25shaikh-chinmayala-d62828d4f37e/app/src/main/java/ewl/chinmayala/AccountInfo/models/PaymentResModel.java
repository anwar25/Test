package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 8/10/2016.
 */
public class PaymentResModel {

    @SerializedName("msg")
    @Expose
    private String msg;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private Userdata userdata;

    /**
     *
     * @return
     * The msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     *
     * @param msg
     * The msg
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     *
     * @return
     * The userdata
     */
    public Userdata getUserdata() {
        return userdata;
    }

    /**
     *
     * @param userdata
     * The userdata
     */
    public void setUserdata(Userdata userdata) {
        this.userdata = userdata;
    }

    private class Userdata {

        @SerializedName("date")
        @Expose
        private String date;
        @SerializedName("amount")
        @Expose
        private String amount;
        @SerializedName("order_id")
        @Expose
        private Integer orderId;

        /**
         *
         * @return
         * The date
         */
        public String getDate() {
            return date;
        }

        /**
         *
         * @param date
         * The date
         */
        public void setDate(String date) {
            this.date = date;
        }

        /**
         *
         * @return
         * The amount
         */
        public String getAmount() {
            return amount;
        }

        /**
         *
         * @param amount
         * The amount
         */
        public void setAmount(String amount) {
            this.amount = amount;
        }

        /**
         *
         * @return
         * The orderId
         */
        public Integer getOrderId() {
            return orderId;
        }

        /**
         *
         * @param orderId
         * The order_id
         */
        public void setOrderId(Integer orderId) {
            this.orderId = orderId;
        }

    }
}
