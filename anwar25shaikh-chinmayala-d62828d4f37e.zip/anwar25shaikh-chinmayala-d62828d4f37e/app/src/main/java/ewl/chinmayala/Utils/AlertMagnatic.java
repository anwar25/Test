package ewl.chinmayala.Utils;

/**
 * Created by Anwar on 7/31/2016.
 */
public interface AlertMagnatic {

     void onButtonClicked(boolean value);

}