package ewl.chinmayala;

import android.app.ProgressDialog;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.widget.ProgressBar;
import android.widget.Toast;

import ewl.chinmayala.DB.ChinDbHelper;
import ewl.chinmayala.DB.ChinDbManager;
import ewl.chinmayala.UI.CustomTextView;

public class BaseActivity extends AppCompatActivity {

    private ProgressDialog mProgressBar;
    private  static SessionManager sSessionManager;
    private static ChinDbHelper mChinDatabaseHelper;
    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mChinDatabaseHelper = new ChinDbHelper(getBaseContext());
        ChinDbManager.initializeInstance(mChinDatabaseHelper);
    }

    public synchronized  SessionManager getSessionManager(){
        if(sSessionManager == null){
            sSessionManager = new SessionManager(getApplicationContext());
        }
        return sSessionManager ;
    }

    public void showProgresDialog(String msg) {
        mProgressBar = new ProgressDialog(this);
        if(msg == null)
            mProgressBar.setMessage(getString(R.string.processing_please_wait));
        else
            mProgressBar.setMessage(msg);
        mProgressBar.setIndeterminate(true);
        mProgressBar.setCancelable(false);
        mProgressBar.show();
    }

    public void hideProgressDialog() {
        mProgressBar.dismiss();
    }

    public void showProgress(String msg) {
        mProgressBar = new ProgressDialog(this);
        mProgressBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        mProgressBar.setCancelable(false);
        mProgressBar.show();
        mProgressBar.setContentView(R.layout.progress_layout);
        ((ProgressBar)mProgressBar.findViewById(R.id.progressBar1))
                .getIndeterminateDrawable()
                .setColorFilter(ContextCompat.getColor(this, R.color.colorAccent), PorterDuff.Mode.SRC_IN);
        if(msg != null)
         ((CustomTextView)mProgressBar.findViewById(R.id.progressText)).setText(msg);
    }

    public void hideProgress() {
        mProgressBar.dismiss();
    }

    public void showNetworkErrorToast() {
        Toast.makeText(BaseActivity.this, getString(R.string.network_connection_error), Toast.LENGTH_LONG).show();
    }
}
