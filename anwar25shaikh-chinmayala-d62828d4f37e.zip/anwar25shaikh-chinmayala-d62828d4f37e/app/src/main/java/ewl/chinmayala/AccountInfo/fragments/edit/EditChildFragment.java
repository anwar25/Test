package ewl.chinmayala.AccountInfo.fragments.edit;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import ewl.chinmayala.AccountInfo.fragments.edit.models.ChildModel;
import ewl.chinmayala.AccountInfo.models.ChildRegModel;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.AccountInfo.models.LanguageData;
import ewl.chinmayala.AccountInfo.models.LanguageResponseModel;
import ewl.chinmayala.AccountInfo.models.Userdata;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.UI.CustomSpinnerAdapter;
import ewl.chinmayala.Utils.DatePickerUtility;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.Utils.Utils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar Shaikh on 2/11/2016.
 */
public class EditChildFragment extends BaseFragment implements View.OnClickListener {

    private static final String TAG = EditChildFragment.class.getSimpleName();
    private CustomSpinnerAdapter mLanguageAdapter;

    private EditText mNameEditText;
    private TableRow mDatePicker;
    private EditText mDobEditText;

    private RadioButton mMaleRadioButton;
    private EditText mEmailEditText;

    private EditText mHomePhoneEditText;
    private EditText mCellPhoneEditText;


    private EditText mCurrSchoolEditText;
    private EditText mDistrictEditText;
    private EditText mSchoolCityEditText;

    private Spinner mLanguageSpinner;

    private ArrayList<String> languageArrayList;

    private CustomAppCompatButton mSubmitButton;

    private HomeActivity activityHandle;
    private HashMap<String, String> mLanguageMapping;

    private Userdata member1Details;
    private boolean isFromDashboard = false;

    private ChildModel mChildDetails;
    private CustomEditText mSchoolGradeEditText;
    private CustomEditText mBvClassEditText;

    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.edit_child_fragment_layout, container, false);
        activityHandle.setToolbarInitialization(this, getString(R.string.edit_child));
        // activityHandle.setToolbarInitialization(this, getString(R.string.register_chils));
        mapControls(view);
        Gson gson = new Gson();
        String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        member1Details = gson.fromJson(member1DetailsString, Userdata.class);
        //activityHandle.setToolbarInitialization(this, getString(R.string.child));
        new DownloadData().execute(member1Details.getCenterId());
        return view;
    }

    @Override
    public void mapControls(View rootView) {

        mSchoolGradeEditText = (CustomEditText) rootView.findViewById(R.id.schoolGradeListSpinner);
        mBvClassEditText = (CustomEditText) rootView.findViewById(R.id.bvClassListSpinner);

        mNameEditText = (EditText) rootView.findViewById(R.id.nameEditText);

        mDatePicker = (TableRow) rootView.findViewById(R.id.birthDatePicker);
        mDatePicker.setOnClickListener(this);
        mDobEditText = (EditText) rootView.findViewById(R.id.dobEditText);

        mMaleRadioButton = (RadioButton) rootView.findViewById(R.id.maleRadioButton);
        mEmailEditText = (CustomEditText) rootView.findViewById(R.id.emailEditText);
        mHomePhoneEditText = (CustomEditText) rootView.findViewById(R.id.homePhoneEditText);
        mCellPhoneEditText = (CustomEditText) rootView.findViewById(R.id.cellPhoneEditText);

        mCurrSchoolEditText = (CustomEditText) rootView.findViewById(R.id.curSchoolEditText);
        mDistrictEditText = (CustomEditText) rootView.findViewById(R.id.disctrictEditText);
        mSchoolCityEditText = (CustomEditText) rootView.findViewById(R.id.cityEditText);



        mLanguageSpinner = (Spinner) rootView.findViewById(R.id.languageSpinner);
        languageArrayList = new ArrayList<String>();
        languageArrayList.add(getString(R.string.select_language));
        mLanguageAdapter = new CustomSpinnerAdapter(activityHandle, R.layout.spinner_item_layout, languageArrayList);
        // Drop down layout style - list view with radio button
        mLanguageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mLanguageSpinner.setAdapter(mLanguageAdapter);



        mSubmitButton = (CustomAppCompatButton) rootView.findViewById(R.id.btnSubmit);
        mSubmitButton.setOnClickListener(this);

        if(getArguments() != null) {
            mChildDetails = (ChildModel) getArguments().getSerializable(Constants.CHILD_DETAILS);
        }
    }

    @Override
    public boolean validate() {

        mNameEditText.setError(null);
        mEmailEditText.setError(null);
        mHomePhoneEditText.setError(null);
        mCellPhoneEditText.setError(null);

        mCurrSchoolEditText.setError(null);
        mDistrictEditText.setError(null);
        mSchoolCityEditText.setError(null);


        if (TextUtils.isEmpty(String.valueOf(mNameEditText.getText()))) {
            mNameEditText.requestFocus();
            mNameEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mDobEditText.getText()))) {
            Toast.makeText(activityHandle, getString(R.string.select_dob), Toast.LENGTH_SHORT).show();
            return false;
        }

       /* if (String.valueOf(mLanguageSpinner.getSelectedItem()).equalsIgnoreCase(getString(R.string.select_language))) {
            mLanguageSpinner.requestFocus();
            Toast.makeText(activityHandle, getString(R.string.select_language), Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(String.valueOf(mEmailEditText.getText()))) {
            mEmailEditText.requestFocus();
            mEmailEditText.setError(getString(R.string.error_field_required));
            return false;
        }*/
        if (!TextUtils.isEmpty(mEmailEditText.getText().toString()) && !Utils.validateEmail(mEmailEditText.getText().toString())) {
            mEmailEditText.requestFocus();
            mEmailEditText.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        }

       /* if (TextUtils.isEmpty(String.valueOf(mHomePhoneEditText.getText()))) {
            mHomePhoneEditText.requestFocus();
            mHomePhoneEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mCellPhoneEditText.getText()))) {
            mCellPhoneEditText.requestFocus();
            mCellPhoneEditText.setError(getString(R.string.error_field_required));
            return false;
        }

        if (TextUtils.isEmpty(String.valueOf(mCurrSchoolEditText.getText()))) {
            mCurrSchoolEditText.requestFocus();
            mCurrSchoolEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mDistrictEditText.getText()))) {
            mDistrictEditText.requestFocus();
            mDistrictEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mSchoolCityEditText.getText()))) {
            mSchoolCityEditText.requestFocus();
            mSchoolCityEditText.setError(getString(R.string.error_field_required));
            return false;
        }*/
        return true;
    }

    private class DownloadData extends AsyncTask<String, Void, HashMap<String, Object>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
                activityHandle.showNetworkErrorToast();
                return;
            }
            //    activityHandle.showProgress(getString(R.string.loading_msg));
        }

        @Override
        protected HashMap<String, Object> doInBackground(String... params) {
            HashMap<String, Object> resultMap = new HashMap<String, Object>();
            GenericRequestModel genericRequestModel = new GenericRequestModel(Integer.parseInt(params[0]));
            Call<LanguageResponseModel> langCall = RetrofitInstance.getInstance()
                    .getLanguages(genericRequestModel);
            try {
                //    Response<CenterListResponse> centerListResponseResponse  = centerCall.execute();
                Response<LanguageResponseModel> languageResponseModelResponse = langCall.execute();
                resultMap.put(Constants.LANG_OBJ, languageResponseModelResponse.body());
                Logger.e(TAG, resultMap.toString());

            } catch (IOException e) {
                Logger.e(TAG, e.toString());
            }
            return resultMap;
        }

        @Override
        protected void onPostExecute(HashMap<String, Object> resultMap) {
            super.onPostExecute(resultMap);
            // activityHandle.hideProgress();
            loadData(resultMap);
        }
    }

    private void loadData(HashMap<String, Object> resultMap) {
        LanguageResponseModel languageResponseModel = (LanguageResponseModel) resultMap.get(Constants.LANG_OBJ);

        mLanguageMapping = new HashMap<String, String>();

        int selectionIndex = 0 , count = 0;
        if (languageResponseModel != null && languageResponseModel.getLanguageDataList() != null
                && languageArrayList != null ) {
            for (LanguageData languageData : languageResponseModel.getLanguageDataList()) {
                count++ ;
                languageArrayList.add(languageData.getLangName());
                if(languageData.getLangName().equalsIgnoreCase(mChildDetails.getLangName())){
                    selectionIndex = count ;
                }
                mLanguageMapping.put(languageData.getLangName(),languageData.getId());
            }
            mLanguageAdapter.notifyDataSetChanged();
        }

        if(mChildDetails != null){
            mSchoolGradeEditText.setText(mChildDetails.getGradeName());
            mBvClassEditText.setText(mChildDetails.getClassName());
            mNameEditText.setText(mChildDetails.getName());
            mDobEditText.setText(mChildDetails.getDob());
            if(mChildDetails.getGender().equalsIgnoreCase(getString(R.string.male))){
                mMaleRadioButton.setChecked(true);
            }else{
                mMaleRadioButton.setChecked(false);
            }
            mLanguageSpinner.setSelection(selectionIndex);
            mEmailEditText.setText(mChildDetails.getEmailid());
            mHomePhoneEditText.setText(mChildDetails.getHomePhone());
            mCellPhoneEditText.setText(mChildDetails.getCellPhone());

            mCurrSchoolEditText.setText(mChildDetails.getCurrentSchoolInfo());
            mDistrictEditText.setText(mChildDetails.getDistrictName());
            mSchoolCityEditText.setText(mChildDetails.getSchoolCity());

        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:
                if (validate()) {
                    editChild();
                }
                break;
            case R.id.birthDatePicker:
                new DatePickerUtility(mDobEditText, getContext());
                break;

        }
    }

    private ChildRegModel getModel() {

        ChildRegModel childRegModel = new ChildRegModel();
        childRegModel.setType(Constants.CHILD);
        childRegModel.setChildId(mChildDetails.getId());
        childRegModel.setMemberLoginId(mChildDetails.getMemberLoginId());

        childRegModel.setChildName(String.valueOf(mNameEditText.getText()));
        childRegModel.setChildDob(String.valueOf(mDobEditText.getText()));

        if (mMaleRadioButton.isChecked()) {
            childRegModel.setChildGender(getString(R.string.male));
        } else {
            childRegModel.setChildGender(getString(R.string.female));
        }
        childRegModel.setChildLang(mLanguageMapping.get(String.valueOf(mLanguageSpinner.getSelectedItem())));
        //childRegModel.setChildEmailid(String.valueOf(mEmailEditText.getText()));
        childRegModel.setChildHomephone(String.valueOf(mHomePhoneEditText.getText()));
        childRegModel.setChildCellphone(String.valueOf(mCellPhoneEditText.getText()));
        childRegModel.setChildCurrentSchool(String.valueOf(mCurrSchoolEditText.getText()));
        childRegModel.setDistrictName(String.valueOf(mDistrictEditText.getText()));
        childRegModel.setChildSchoolCity(String.valueOf(mSchoolCityEditText.getText()));

        //childRegModel.setAge(Utils.getAge(String.valueOf(mDobEditText.getText())));
        return childRegModel;
    }

    private void editChild() {
        //resetAllData();
        activityHandle.showProgress(getString(R.string.updating));

        RetrofitInstance.getInstance().updateChild(getModel()).enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                if (genericResponseModel.getStatus() == 1) {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, genericResponseModel.getMsg(), Toast.LENGTH_SHORT).show();
                    activityHandle.getSupportFragmentManager().popBackStack();

                } else {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, genericResponseModel.getErrorMsg(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle,getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
                activityHandle.hideProgress();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mLanguageAdapter = null;
        mNameEditText = null;
        mDatePicker = null;
        mDobEditText = null;

        mMaleRadioButton = null;
        mEmailEditText = null;

        mHomePhoneEditText = null;
        mCellPhoneEditText = null;
        mCurrSchoolEditText = null;
        mDistrictEditText = null;
        mSchoolCityEditText = null;

        mLanguageSpinner = null;
        languageArrayList = null;
        mSubmitButton = null;
        mLanguageMapping = null;
        member1Details = null;
        isFromDashboard = false;
    }

}
