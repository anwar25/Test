package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/26/2016.
 */
public class ForgotPasReq {

    @SerializedName("emailid")
    @Expose
    private String emailid;

    /**
     * @return The emailid
     */
    public String getEmailid() {
        return emailid;
    }

    /**
     * @param emailid The emailid
     */
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }
}
