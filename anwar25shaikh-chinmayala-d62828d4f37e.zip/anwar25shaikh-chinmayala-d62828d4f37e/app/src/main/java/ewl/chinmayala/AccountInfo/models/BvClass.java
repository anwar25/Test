package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 449781 on 7/20/2016.
 */
public class  BvClass {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("class_name")
    @Expose
    private String className;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The className
     */
    public String getClassName() {
        return className;
    }

    /**
     *
     * @param className
     * The class_name
     */
    public void setClassName(String className) {
        this.className = className;
    }
}
