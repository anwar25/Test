
package ewl.chinmayala;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import ewl.chinmayala.Interface.ITimeCount;
import ewl.chinmayala.TimeHandler.TimeCount;

/**
* Created by Anwar on 11/9/2015.
*/
public class SplashScreen extends AppCompatActivity implements ITimeCount {
   TimeCount timeCount;
   long SleepTime = 1000;
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.content_splash_screen);
      timeCount =  new TimeCount(SleepTime,1000);
      timeCount.setiTimeCount(this);
      timeCount.start();

      /*PackageInfo info;
      try {
          info = getPackageManager().getPackageInfo("com.bplusapp", PackageManager.GET_SIGNATURES);
          for (Signature signature : info.signatures) {
              MessageDigest md;
              md = MessageDigest.getInstance("SHA");
              md.update(signature.toByteArray());
              String something = new String(Base64.encode(md.digest(), 0));
              //String something = new String(Base64.encodeBytes(md.digest()));
              Logger.d("hash key", ":" + something);
          }
      } catch (PackageManager.NameNotFoundException e1) {
          Log.e("name not found", e1.toString());
      } catch (NoSuchAlgorithmException e) {
          Log.e("no such an algorithm", e.toString());
      } catch (Exception e) {
          Log.e("exception", e.toString());
      }*/
      getSupportActionBar().hide();
  }


    @Override
    public void OnTickListener(long Time_tick) {
    }

    @Override
    public void OnFinish() {
        timeCount.cancel();
        Intent intent = new Intent(SplashScreen.this,HomeActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(timeCount!=null)
            timeCount.cancel();
    }
}
