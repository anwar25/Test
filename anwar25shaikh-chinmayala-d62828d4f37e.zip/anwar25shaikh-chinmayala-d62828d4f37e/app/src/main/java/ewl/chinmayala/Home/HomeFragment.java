package ewl.chinmayala.Home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import ewl.chinmayala.Adapter.EventAdapter;
import ewl.chinmayala.Adapter.ImageSlideAdapter;
import ewl.chinmayala.Entity.Event;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Interface.ITimeCount;
import ewl.chinmayala.R;
import ewl.chinmayala.TimeHandler.TimeCount;
import ewl.chinmayala.UI.CirclePageIndicator;
import ewl.chinmayala.Utils.Utils;

/**
 * Created by Akash.Singh on 2/9/2016.
 */
public class HomeFragment extends Fragment implements ITimeCount, View.OnClickListener {
    //ImageLoader imageLoader;
    private TimeCount timeCount;
    private ViewPager pager;
    private ArrayList<String> imagePath = new ArrayList<String>();
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_home_screen,container,false);
        ((HomeActivity)getActivity()).setToolbarInitialization(this,getString(R.string.title_home));
        //imageLoader = new ImageLoader(getActivity());
        MidMapping(view);
        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        timeCount = null ;
        pager = null ;
        imagePath  = null ;
    }

    private void MidMapping(View view) {
       // ((FloatingActionButton)view.findViewById(R.id.fab)).setOnClickListener(this);
        imagePath = new ArrayList<String>();
        imagePath.add("https://lh3.googleusercontent.com/kVdehn2rxXWUBBWTNjIt2NGfOGGumOA_FrafaReVhSJmiv_1aCz2Lic7L7YGLrDsXCyAQ5Vwvmsh7-E=w2048-h1365-rw-no");
        imagePath.add("https://lh3.googleusercontent.com/-AJscbYcjxKw/UEwSootauYI/AAAAAAAAKXQ/4XVyaaFOkyYbAfIN3r4InqFm7KWi4VjKgCCo/s720/DSC04961.JPG");
        imagePath.add("https://lh3.googleusercontent.com/-VJhCLMuqUfA/UEwSspttX0I/AAAAAAAAKYk/Ae5Ufim1oM0VMU8l_ZpcsVa3BKp8ksQdwCCo/s720/DSC05002.JPG");
        imagePath.add("https://chinmayala.org/sites/default/files/styles/slideshow/public/tejo-smiling_0.jpg?itok=A8GqNMer");
        imagePath.add("https://chinmayala.org/sites/default/files/styles/slideshow/public/Padukapuja.jpg?itok=aMYSOUFA");
        imagePath.add("https://chinmayala.org/sites/default/files/styles/slideshow/public/439_0.jpg?itok=-_5VozCr");
        pager = (ViewPager)view.findViewById(R.id.carouselPager);
        ImageSlideAdapter imageSlideAdapter =  new ImageSlideAdapter(getActivity(),imagePath);
        pager.setAdapter(imageSlideAdapter);
        pager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });

        CirclePageIndicator circlePageIndicator = (CirclePageIndicator) view.findViewById(R.id.circlePageIndicator);
        circlePageIndicator.setViewPager(pager);
        RecyclerView mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        RecyclerView recycler_view_upcoming_event = (RecyclerView) view.findViewById(R.id.recycler_view_upcoming_event);
        setEventRecycleView(mRecyclerView);
        setEventRecycleView(recycler_view_upcoming_event);

        int NumberOfSlider = imagePath.size();
        timeCount =  new TimeCount(5000*NumberOfSlider,5000);
        timeCount.setiTimeCount(this);
        timeCount.start();
    }

    private void setEventRecycleView(RecyclerView mRecyclerView) {
        ArrayList<Event> eventArrayList =  new ArrayList<Event>();
        Utils.AddEvent(eventArrayList);
        mRecyclerView.setHasFixedSize(true);
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 1, LinearLayoutManager.HORIZONTAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        EventAdapter mAdapter = new EventAdapter(getActivity(),eventArrayList);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void OnTickListener(long timetick) {
        int position = pager.getCurrentItem();
        //Logger.d("position-", ":" + position);
        if(position<imagePath.size()-1)
            position++;
        else if(position>=imagePath.size()-1)
            position=0;
      //  Logger.d("position+", ":" + position);

        pager.setCurrentItem(position);
    }

    @Override
    public void OnFinish() {
        if(timeCount!=null)
            timeCount.start();
     //   Logger.d("position+", ":OnFinish");
    }

  /*  @Override
    public void onStart() {
        if(timeCount!=null)
            timeCount.start();
        super.onStart();
    }*/

    @Override
    public void onPause() {
        super.onPause();
        if(timeCount!=null)
            timeCount.cancel();
       // Logger.d("position+", ":onPause");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            /*case R.id.fab:
                if(timeCount!=null)
                    timeCount.cancel();
                ((HomeActivity)getActivity()).onReplaceFragment(new LoginFragment(), true);
                break;*/
        }
    }
}
