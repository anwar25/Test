package ewl.chinmayala.AccountInfo.fragments.edit;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import ewl.chinmayala.AccountInfo.fragments.edit.models.PaymentModel;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.constants.Constants;

/**
 * Created by Anwar on 7/28/2016.
 */
public class PaymentDetailPage extends Fragment {

    private PaymentModel mPaymentDetails;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.payment_detail_page_layout, container, false);
        if(getArguments() != null){
            mPaymentDetails = (PaymentModel)getArguments().getSerializable(Constants.PAYMENT_DETAILS);

            ((CustomTextView)rootView.findViewById(R.id.taxYearTextView))
                    .setText("( "+mPaymentDetails.getStartYear()+" - "+mPaymentDetails.getEndYear()+" )");
            ((CustomTextView)rootView.findViewById(R.id.paymentMethodTextView)).setText(mPaymentDetails.getPaymentBy());
            ((CustomTextView)rootView.findViewById(R.id.paymentStatusTextView)).setText(mPaymentDetails.getIsPayment());
            ((CustomTextView)rootView.findViewById(R.id.paymentReasonTextView)).setText(mPaymentDetails.getPaymentReason());
            ((CustomTextView)rootView.findViewById(R.id.totalAmountTextView)).setText("$"+mPaymentDetails.getTotalAmount());
        }
        return rootView;
    }
}
