package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 7/28/2016.
 */
public class MagazineModel {
    @SerializedName("mandatory")
    @Expose
    private List<Magazine> mandatory = new ArrayList<Magazine>();
    @SerializedName("optional")
    @Expose
    private List<Magazine> optional = new ArrayList<Magazine>();

    /**
     *
     * @return
     * The mandatory
     */
    public List<Magazine> getMandatory() {
        return mandatory;
    }

    /**
     *
     * @param mandatory
     * The mandatory
     */
    public void setMandatory(List<Magazine> mandatory) {
        this.mandatory = mandatory;
    }

    /**
     *
     * @return
     * The optional
     */
    public List<Magazine> getOptional() {
        return optional;
    }

    /**
     *
     * @param optional
     * The optional
     */
    public void setOptional(List<Magazine> optional) {
        this.optional = optional;
    }

}

