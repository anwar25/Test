package ewl.chinmayala.AccountInfo.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.gson.Gson;

import ewl.chinmayala.AccountInfo.models.ForgotPasReq;
import ewl.chinmayala.AccountInfo.models.ForgotPasRes;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.LoginResponse;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.Utils.Utils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar Shaikh on 2/10/2016.
 */
public class LoginFragment extends BaseFragment implements View.OnClickListener {

    CustomEditText edit_email_address, edit_password;
    TextInputLayout input_email_address, input_password;
    private HomeActivity activityHandle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_login_screen, container, false);
        ((HomeActivity) getActivity()).setToolbarInitialization(this, getString(R.string.Sign_in));
        mapControls(view);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroy();
        //activityHandle = null;
        edit_email_address = null;
        edit_password = null;
        input_email_address = null;
        input_password = null;
    }

    @Override
    public void mapControls(View view) {
        edit_email_address = (CustomEditText) view.findViewById(R.id.edit_email_address);
        edit_password = (CustomEditText) view.findViewById(R.id.edit_password);

        input_email_address = (TextInputLayout) view.findViewById(R.id.input_email_address);
        input_password = (TextInputLayout) view.findViewById(R.id.input_password);

        // edit_email_address.addTextChangedListener(new CustomTextWatcher(input_email_address));
        // edit_password.addTextChangedListener(new CustomTextWatcher(input_password));

        ((CustomAppCompatButton) view.findViewById(R.id.btnSignin)).setOnClickListener(this);
        ((CustomTextView) view.findViewById(R.id.textForgetPassword)).setOnClickListener(this);
        ((CustomTextView) view.findViewById(R.id.textRegister)).setOnClickListener(this);
    }

    @Override
    public boolean validate() {

        input_email_address.setError(null);
        input_password.setError(null);

        if (TextUtils.isEmpty(edit_email_address.getText().toString())) {
            edit_email_address.requestFocus();
            input_email_address.setError(getString(R.string.hint_please_enter_your_email_address));
            return false;
        } else if (!TextUtils.isEmpty(edit_email_address.getText().toString()) && !Utils.validateEmail(edit_email_address.getText().toString())) {
            edit_email_address.requestFocus();
            input_email_address.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        } else if (TextUtils.isEmpty(edit_password.getText().toString())) {
            edit_password.requestFocus();
            input_password.setError(getString(R.string.hint_please_enter_your_password));
            return false;
        } else if (!TextUtils.isEmpty(edit_password.getText().toString()) && !Utils.validatePassword(edit_password.getText().toString())) {
            edit_password.requestFocus();
            input_password.setError(getString(R.string.password_must_be6_char));
            return false;
        }

        return true;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnSignin:
                if (validate()) {
                    doSignIn();
                }
                break;
            case R.id.textForgetPassword:
                showForgotPwdDialog();
                // Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                // ((HomeActivity) getActivity()).onReplaceFragment(new PaymentFragment(), true);
                break;
            case R.id.textRegister:

                if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
                    activityHandle.showNetworkErrorToast();
                    return;
                }
                ((HomeActivity) getActivity()).onReplaceFragment(new RegisterParentFragment(), true);
                break;
        }
    }
    private AlertDialog mAlertDialog;
    private void showForgotPwdDialog() {

        // get prompts.xml view
        final LinearLayout promptView = (LinearLayout) activityHandle.getLayoutInflater()
                .inflate(R.layout.forgot_password_layout, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activityHandle);
        alertDialogBuilder.setView(promptView);


        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton(getString(R.string.submit), null)
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an mAlertDialog dialog
        mAlertDialog = alertDialogBuilder.create();
        mAlertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                Button b = mAlertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // TODO Do something
                        doForgotPassword(promptView);
                        //Dismiss once everything is OK.
                        //mAlertDialog.dismiss();
                    }
                });
            }
        });
        mAlertDialog.show();
        //  mAlertDialog.getWindow().setBackgroundDrawableResource(ContextCompat.getColor(activityHandle, R.color.light_white));
        mAlertDialog.getWindow().setBackgroundDrawableResource(R.color.light_white);
    }

    private void doForgotPassword(View dialogView) {

        final EditText emailEditText = (EditText) dialogView.findViewById(R.id.edit_email_address);
        final TextInputLayout emailTextInputLayout  = (TextInputLayout) dialogView.findViewById(R.id.input_email_address);

        emailTextInputLayout.setError(null);
        if (TextUtils.isEmpty(emailEditText.getText().toString())) {
            emailEditText.requestFocus();
            emailTextInputLayout.setError(getString(R.string.hint_please_enter_your_email_address));
        } else if (!TextUtils.isEmpty(emailEditText.getText().toString()) && !Utils.validateEmail(emailEditText.getText().toString())) {
            emailEditText.requestFocus();
            emailTextInputLayout.setError(getString(R.string.hint_please_enter_valid_email_password));
        }else {

            if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
                activityHandle.showNetworkErrorToast();
                return;
            }

            activityHandle.showProgress(getString(R.string.processing_please_wait));
            activityHandle.hideKeyboarFromDialog(dialogView);
            final ForgotPasReq forgotPasReq = new ForgotPasReq();
            Call<ForgotPasRes> call = RetrofitInstance.getInstance()
                    .forgotPassword(forgotPasReq);
            forgotPasReq.setEmailid(String.valueOf(emailEditText.getText()));
            call.enqueue(new Callback<ForgotPasRes>() {
                @Override
                public void onResponse(Call<ForgotPasRes> call, Response<ForgotPasRes> response) {
                    ForgotPasRes forgotPasRes = response.body();
                    if(forgotPasRes != null && forgotPasRes.getStatus() == 1){
                        Toast.makeText(activityHandle, forgotPasRes.getUserdata(), Toast.LENGTH_LONG).show();
                        mAlertDialog.dismiss();
                    }else{
                        emailEditText.requestFocus();
                        emailTextInputLayout.setError(forgotPasRes.getUserdata());
                    }
                    activityHandle.hideProgress();
                }
                @Override
                public void onFailure(Call<ForgotPasRes> call, Throwable t) {
                    Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                    activityHandle.hideProgress();
                }
            });
        }
    }

    private void doSignIn() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.signing_in));

        Call<LoginResponse> call = RetrofitInstance.getInstance()
                .login(new GenericRequestModel(String.valueOf(edit_email_address.getText())
                        , String.valueOf(edit_password.getText())));
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse loginResponse = response.body();
                if (loginResponse.getStatus() == 1) {
                    activityHandle.hideProgress();
                    //store user response in session
                    //Remove sign in screen from back stack
                    //     activityHandle.getSupportFragmentManager().popBackStack();
                    Gson gson = new Gson();
                    activityHandle.getSessionManager().putString(Constants.REGISTER_MEMBER1_DETAILS, gson.toJson(loginResponse.getLoginData()));
                    activityHandle.onReplaceFragment(new DashboardFragment(), true);
                } else {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, getString(R.string.invalid_username_pwd), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }
}
