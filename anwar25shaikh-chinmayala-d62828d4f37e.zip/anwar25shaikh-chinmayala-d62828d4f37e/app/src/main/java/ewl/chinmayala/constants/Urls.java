package ewl.chinmayala.constants;

/**
 * Created by Anwar on 5/23/2016.
 */
public interface Urls {

    String BASE_URL = "http://demo.evegtech.com/chinmayala/api/";

    String LOGIN_API = "member/login/format/json";
    String CENTER_LIST_API = "member/centerList/format/json";
    String PROFESSION_LIST_API = "member/professionList/format/json";
    String MOTHER_TONGUE_API = "member/motherTongueList/format/json";
    String REGISTER_PRIMARY_MEMBER_API = "member/memberRegister/format/json";
    String REGISTER_SECONDARY_MEMBER_API = "member/addSecondaryMember/format/json";
    String REGISTER_TRUST_API = "member/addTrust/format/json";
    String REGISTER_CHILD_API = "member/addChild/format/json";
    String GET_SCHOOL_GRADE_API = "member/schoolGradeList/format/json";
    String GET_BV_CLASS_LIST_API = "member/bvClassList/format/json" ;

    String GOOGLE_PLACES_BASE_URL = "https://maps.googleapis.com/maps/api/place/";
    String GET_ADRESS_API = "autocomplete/json";
    String GET_PLACE_DETAILS = "details/json";

    String GET_MEMBER_INTEREST_LIST = "member/memberInterestList/format/json";

    String GET_SESSION_LIST_API = "member/sessionList/format/json";
    String FORGOT_PASSWORD_API = "member/forgotPassword/format/json";


    String UPLOAD_PROFILE_PIC_API = "member/uploadMemberImg/format/json";

    String GET_MAGAZINES_API = "member/magListByCenter/format/json";

    String GET_ALL_MEMBER_LIST = "member/memberListByFamily/format/json";
    String GET_ALL_CHILD_LIST = "member/childListByFamily/format/json";
    String GET_ALL_TRUST_LIST = "member/trustListByFamily/format/json";
    String GET_ALL_PAYMENT_LIST = "member/paymentListByFamily/format/json";
    String DELETE_ITEM = "member/deleteMemberTrustChild/format/json";

    String UPDATE_ITEM = "member/updateMemberChildTrust/format/json" ;

    String PREVIOUS_PAYMENT_API = "member/previousPaidAmount/format/json";
    String PAYMENT_API = "member/registrationPayment/format/json";
    String BV_AARATI_FEES_API = "member/getBvAndAaratiFee/format/json";
}
