package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 7/2/2016.
 */
public class CenterListResponse {

    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private List<CenterData> centerDataList = new ArrayList<CenterData>();

    public List<CenterData> getCenterDataList() {
        return centerDataList;
    }

    public void setCenterDataList(List<CenterData> centerDataList) {
        this.centerDataList = centerDataList;
    }

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }


    @Override
    public String toString() {
        return "CenterListResponse{" +
                "status=" + status +
                ", centerDataList=" + centerDataList +
                '}';
    }
}
