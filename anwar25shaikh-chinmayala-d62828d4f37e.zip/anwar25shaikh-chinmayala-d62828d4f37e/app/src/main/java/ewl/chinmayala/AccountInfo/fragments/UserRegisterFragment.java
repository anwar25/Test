package ewl.chinmayala.AccountInfo.fragments;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.aakira.expandablelayout.ExpandableLinearLayout;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ewl.chinmayala.AccountInfo.models.CenterData;
import ewl.chinmayala.AccountInfo.models.CenterListResponse;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.UI.CustomSpinnerAdapter;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by Anwar on 2/11/2016.
 */
public class UserRegisterFragment extends BaseFragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    private static final String TAG = UserRegisterFragment.class.getSimpleName();
    private Spinner mCenterSpinner;
    private ArrayAdapter<String> mCenterAdapter;
    private EditText mCenterEditText;

    private CustomTextView mAddMemberTextView;
    private CustomTextView mAddMemberTextView1;
    private CustomTextView mAddMemberTextView2;
    private CustomTextView mAddTrustTextView;
    private CustomTextView mAddTrustTextView1;
    private CustomTextView mAddTrustTextView2;
    private ExpandableLinearLayout mAddMemberLayout;
    private ExpandableLinearLayout mAddTrustLayout;

    HashMap<String, CenterData> centerAddressMap;
    private ArrayList<String> centerArrayList;
    private HomeActivity activityHandle;

    private boolean isMember1Registered = false;
    private boolean isMember2Registered = false;
    private boolean isTrust1Registered = false;
    private boolean isTrust2Registered = false;

  // private View _rootView;
  //  private CustomAppCompatButton mDashboardButton ;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        /*if (_rootView == null) {
            _rootView = inflater.inflate(R.layout.content_register_form_screen, container, false);
            //new DownloadData().execute();
            mapControls(_rootView);
        } else {
            setSelection();
        }*/
        View  _rootView = inflater.inflate(R.layout.content_register_form_screen, container, false);
        mapControls(_rootView);
        new DownloadData().execute();
        return _rootView;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    private void setSelection() {
        Logger.e(TAG, "setSelection called");
        String registerMember = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER);
        String registerTrust = activityHandle.getSessionManager().getString(Constants.REGISTER_TRUST);
        if (registerMember.equalsIgnoreCase(getString(R.string.add_member1))) {
            isMember1Registered = true;
          /*  mAddMemberTextView1.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_check_circle_black_24dp, 0);
            SectionsPagerAdapter sectionsPagerAdapter = ((RegisterParentFragment)getParentFragment()).getmSectionsPagerAdapter();
            sectionsPagerAdapter.addFragment(new AddChildFragment(),"AddChildFragment");
            sectionsPagerAdapter.notifyDataSetChanged();
            ((RegisterParentFragment)getParentFragment()).getmViewPager().setCurrentItem(2);*/
            //((RegisterParentFragment)getParentFragment()).noti
        } else if (registerMember.equalsIgnoreCase(getString(R.string.add_member2))) {
            isMember2Registered = true;
            mAddMemberTextView2.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_check_circle_black_24dp, 0);
        } else if (registerTrust.equalsIgnoreCase(getString(R.string.add_trust1))) {
            isTrust1Registered = true;
            mAddTrustTextView1.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_check_circle_black_24dp, 0);
        } else if (registerTrust.equalsIgnoreCase(getString(R.string.add_trust2))) {
            isTrust2Registered = true;
            mAddTrustTextView2.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_check_circle_black_24dp, 0);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //new DownloadData().execute();
    }

    @Override
    public void mapControls(View rootView) {
        mAddMemberTextView = (CustomTextView) rootView.findViewById(R.id.addMemberTextView);
        mAddMemberTextView.setOnClickListener(this);
        mAddMemberTextView1 = (CustomTextView) rootView.findViewById(R.id.addMemberTextView1);
        mAddMemberTextView1.setOnClickListener(this);
        mAddMemberTextView2 = (CustomTextView) rootView.findViewById(R.id.addMemberTextView2);
        mAddMemberTextView2.setOnClickListener(this);

        mAddTrustTextView = (CustomTextView) rootView.findViewById(R.id.addTrustTextView);
        mAddTrustTextView.setOnClickListener(this);
        mAddTrustTextView1 = (CustomTextView) rootView.findViewById(R.id.addTrustTextView1);
        mAddTrustTextView1.setOnClickListener(this);
        mAddTrustTextView2 = (CustomTextView) rootView.findViewById(R.id.addTrustTextView2);
        mAddTrustTextView2.setOnClickListener(this);


        mAddMemberLayout = (ExpandableLinearLayout) rootView.findViewById(R.id.addMemberLayout);

        mAddTrustLayout = (ExpandableLinearLayout) rootView.findViewById(R.id.addTrustLayout);

        mCenterSpinner = (Spinner) rootView.findViewById(R.id.spinner_centre);
        mCenterEditText = (CustomEditText) rootView.findViewById(R.id.centerEditText);
        centerArrayList = new ArrayList<String>();
        centerArrayList.add(getString(R.string.select_center));
        mCenterAdapter = new CustomSpinnerAdapter(getActivity(), R.layout.spinner_item_layout, centerArrayList);
        // Drop down layout style - list view with radio button
        mCenterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mCenterSpinner.setAdapter(mCenterAdapter);
       /* mCenterSpinner = (Spinner) view.findViewById(R.id.mCenterSpinner);
        text_member_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getParentFragment() instanceof RegisterParentFragment){

                }
                 //   ((RegisterParentFragment) getParentFragment()).customViewPager.setCurrentItem(1);
            }
        });

        text_trust_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getParentFragment() instanceof RegisterParentFragment){

                }
                 //   ((RegisterParentFragment) getParentFragment()).customViewPager.setCurrentItem(2);
            }
        });

        setCentreInformation();
        setChildInformation()*/
        ;

       /* if(mAddMemberLayout.isExpanded()){
            mAddMemberTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_remove_circle_24dp, 0);
        }else{
            mAddMemberTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_add_item_24dp, 0);
        }
        if(mAddTrustLayout.isExpanded()){
            mAddTrustTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_remove_circle_24dp, 0);
        }else{
            mAddTrustTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_add_item_24dp, 0);
        }*/
      //  mDashboardButton = (CustomAppCompatButton)rootView.findViewById(R.id.btnDashboard);
      //  mDashboardButton.setOnClickListener(this);
    }

    private class DownloadData extends AsyncTask<Void, Void, HashMap<String, Object>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            activityHandle.showProgress(getString(R.string.loading_msg));
        }

        @Override
        protected HashMap<String, Object> doInBackground(Void... params) {
            HashMap<String, Object> resultMap = new HashMap<String, Object>();
            Call<CenterListResponse> centerCall = RetrofitInstance.getInstance().getCenterList();
            try {
                Response<CenterListResponse> centerListResponseResponse = centerCall.execute();
                resultMap.put(Constants.CENTER_OBJ, centerListResponseResponse.body());
                Logger.e(TAG, resultMap.toString());

            } catch (IOException e) {
                Logger.e(TAG, e.toString());
            }
            return resultMap;
        }

        @Override
        protected void onPostExecute(HashMap<String, Object> resultMap) {
            super.onPostExecute(resultMap);
            activityHandle.hideProgress();
            loadData(resultMap);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }

    private void loadData(HashMap<String, Object> resultMap) {
        CenterListResponse centerListResponse = (CenterListResponse) resultMap.get(Constants.CENTER_OBJ);
        if (centerListResponse != null) {
            List<CenterData> centerDataList = centerListResponse.getCenterDataList();
            centerAddressMap = new HashMap<String, CenterData>();
            for (CenterData centerData : centerDataList) {
                centerAddressMap.put(centerData.getCenterName(), centerData);
                centerArrayList.add(centerData.getCenterName());
            }
       /* for(String center : centerAddressMap.keySet()){
            centerArrayList.add(center);
        }*/
            mCenterAdapter.notifyDataSetChanged();
            mCenterSpinner.setOnItemSelectedListener(this);
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        mCenterEditText.setText(String.valueOf(centerAddressMap.get(mCenterAdapter.getItem(position)).getCenterAddress()));
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    //private  AddMemberFragment mMemberInfoFragment;


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.addMemberTextView:
                mAddMemberLayout.toggle();
               /* if(mAddMemberLayout.isExpanded()){
                    mAddMemberTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_add_item_24dp, 0);
                }else{
                    mAddMemberTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_remove_circle_24dp, 0);
                }*/
                break;
            case R.id.addTrustTextView:
                if (isMember1Registered || isMember2Registered) {
                    mAddTrustLayout.toggle();
                } else {
                    Toast.makeText(activityHandle, getString(R.string.register_member_first), Toast.LENGTH_SHORT).show();
                }

               // mAddTrustLayout.toggle();
               /* if(mAddTrustLayout.isExpanded()){
                    mAddTrustTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_add_item_24dp, 0);
                }else{
                    mAddTrustTextView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_remove_circle_24dp, 0);
                }*/
                break;
            case R.id.addMemberTextView1:
                // if(mAddMemberTextView1.getCompoundDrawables() != null)
                if(validate()){
                    if (!isMember1Registered) {
                        AddMemberFragment mAddMemberFragment = new AddMemberFragment();
                        mAddMemberFragment.setCenterAddressMapping(centerAddressMap.get(mCenterSpinner.getSelectedItem().toString()), getString(R.string.add_member1));
                        //((HomeActivity) getActivity()).onReplaceFragment(mAddMemberFragment, true);
                        ((RegisterParentFragment)getParentFragment()).replaceChildFragment(mAddMemberFragment);
                    }
                }
                break;
            //Toast.makeText(getContext(),"addMemberTextView1",Toast.LENGTH_SHORT).show();
            //break;
            case R.id.addMemberTextView2:
                //Toast.makeText(getContext(),"addMemberTextView2",Toast.LENGTH_SHORT).show();
                /*if(mMemberInfoFragment == null){
                    mMemberInfoFragment = new AddMemberFragment();
                }*/
                if(validate()) {
                    if(!isMember1Registered){
                        Toast.makeText(activityHandle,getString(R.string.must_register_member1), Toast.LENGTH_SHORT).show();
                        return ;
                    }
                    if (!isMember2Registered) {
                        AddMemberFragment mAddMemberFragment = new AddMemberFragment();
                        mAddMemberFragment.setCenterAddressMapping(centerAddressMap.get(mCenterSpinner.getSelectedItem().toString()), getString(R.string.add_member2));
                        ((RegisterParentFragment)getParentFragment()).replaceChildFragment(mAddMemberFragment);
                    }
                }
                break;
            case R.id.addTrustTextView1:
                if (!isTrust1Registered) {
                    AddEditTrustFragment addEditTrustFragment1 = new AddEditTrustFragment() ;
                    addEditTrustFragment1.setTitle(getString(R.string.add_trust1));
                    ((HomeActivity) getActivity()).onReplaceFragment(addEditTrustFragment1, true);
                }
                //Toast.makeText(getContext(),"addTrustTextView1",Toast.LENGTH_SHORT).show();
                 break;
            case R.id.addTrustTextView2:
                // Toast.makeText(getContext(),"addTrustTextView2",Toast.LENGTH_SHORT).show();
                if (!isTrust2Registered) {
                    AddEditTrustFragment addEditTrustFragment2 = new AddEditTrustFragment() ;
                    addEditTrustFragment2.setTitle(getString(R.string.add_trust2));
                    ((HomeActivity) getActivity()).onReplaceFragment(addEditTrustFragment2, true);
                }

                break;
            /*case R.id.btnDashboard :
                ((HomeActivity)getActivity()).onReplaceFragment(new DashboardFragment(),true);
                //Logger.d("anwar","i am here:");
                break;*/
        }
    }

    @Override
    public boolean validate() {
        if(mCenterSpinner.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select_center))){
            Toast.makeText(activityHandle,getString(R.string.select_center_msg), Toast.LENGTH_SHORT).show();
            return  false ;
        }

        //Logger.v(TAG,mCenterSpinner.getSelectedItem().toString());
        return true;
    }

    private void setCentreInformation() {
        ArrayList<String> ChildArrayList = new ArrayList<>();
        ChildArrayList.add("Select");
        ChildArrayList.add("Rameswaram");
        ChildArrayList.add("Rameswaram 2");
        ChildArrayList.add("Rameswaram 3");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, ChildArrayList);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        final Typeface face = Typeface.createFromAsset(getActivity().getAssets(), "LatoRegular.ttf");

        mCenterSpinner.setAdapter(dataAdapter);
        mCenterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                try {
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setTypeface(face);
                } catch (Exception ex) {

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

  /*  private void setChildInformation() {
        ArrayList<String> ChildArrayList =  new ArrayList<>();
        ChildArrayList.add("Select");
        ChildArrayList.add("Yes");
        ChildArrayList.add("No");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, ChildArrayList);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        final Typeface face= Typeface.createFromAsset(getActivity().getAssets(), "LatoRegular.ttf");

        mSpinnerChild.setAdapter(dataAdapter);
        mSpinnerChild.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                try{
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    ((TextView) parent.getChildAt(0)).setTypeface(face);
                }catch (Exception ex){

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public int ValidCondition(){
        if(mSpinnerChild.getSelectedItem().toString().equalsIgnoreCase("Select"))
         return 0;
        else if(mSpinnerChild.getSelectedItem().toString().equalsIgnoreCase("Yes"))
            return 1;
        else if(mSpinnerChild.getSelectedItem().toString().equalsIgnoreCase("No"))
            return 2;
        return 0;
    }
*/


    @Override
    public void onDestroyView() {
        // Logger.e(TAG, "onDestoryView called");
       /* if (_rootView.getParent() != null) {
            ((ViewGroup) _rootView.getParent()).removeView(_rootView);
        }*/
        super.onDestroyView();
        mCenterSpinner = null;
        mCenterAdapter = null;
        mCenterEditText = null;

        mAddMemberTextView = null;
        mAddMemberTextView1 = null;
        mAddMemberTextView2 = null;
        mAddTrustTextView = null;
        mAddTrustTextView1 = null;
        mAddTrustTextView2 = null;
        mAddMemberLayout = null;
        mAddTrustLayout = null;
        centerAddressMap = null;
        centerArrayList = null;
        //activityHandle= null;
        // private View _rootView;
        //mDashboardButton = null;
    }
}
