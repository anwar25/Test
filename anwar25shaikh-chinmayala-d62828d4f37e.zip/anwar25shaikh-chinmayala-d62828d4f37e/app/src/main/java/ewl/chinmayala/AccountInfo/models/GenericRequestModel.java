package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/19/2016.
 */
public class GenericRequestModel {

    public GenericRequestModel(){}
    public GenericRequestModel(Integer centerId){
        this.centerId = centerId ;
    }
    @SerializedName("center_id")
    @Expose
    private Integer centerId;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("pass")
    @Expose
    private String pass;
    @SerializedName("school_grade")
    @Expose
    private String schoolGrade;

    @SerializedName("family_id")
    @Expose
    private String familyId;

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("type")
    @Expose
    private String type;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The type
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     * The type
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The centerId
     */
    public Integer getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(Integer centerId) {
        this.centerId = centerId;
    }

    public GenericRequestModel(String email , String password){
        this.email  = email ;
        this.pass  = password ;
    }

    /**
     *
     * @return
     * The email
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     * The email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return
     * The pass
     */
    public String getPass() {
        return pass;
    }

    /**
     *
     * @param pass
     * The pass
     */
    public void setPass(String pass) {
        this.pass = pass;
    }





    /**
     *
     * @return
     * The schoolGrade
     */
    public String getSchoolGrade() {
        return schoolGrade;
    }

    /**
     *
     * @param schoolGrade
     * The school_grade
     */
    public void setSchoolGrade(String schoolGrade) {
        this.schoolGrade = schoolGrade;
    }
}
