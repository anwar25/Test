package ewl.chinmayala.AccountInfo.fragments.edit;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import ewl.chinmayala.AccountInfo.fragments.edit.models.EditMemberFragment;
import ewl.chinmayala.AccountInfo.fragments.edit.models.MemberModel;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.AlertDialogUtility;
import ewl.chinmayala.Utils.AlertMagnatic;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar on 7/28/2016.
 */
public class MemberDetailPage extends Fragment implements View.OnClickListener {

    private MemberModel mMemberDetails;
    private ImageButton mEditMemberButton;
    private ImageButton mDeleteMemberButton;
    private HomeActivity activityHandle;
    private  CustomTextView mMemberNameTextView ;
    private  CustomTextView mDobTextView ;
    private  CustomTextView mEmailTextView ;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.member_details_page_layout, container, false);
        if (getArguments() != null) {
            mMemberDetails = (MemberModel) getArguments().getSerializable(Constants.MEMBER_DETAILS);

            mMemberNameTextView =  (CustomTextView) rootView.findViewById(R.id.memberNameTextView);
            mMemberNameTextView.setText(mMemberDetails.getName());

            mDobTextView =  ((CustomTextView) rootView.findViewById(R.id.dobTextView)) ;
            mDobTextView.setText(mMemberDetails.getDob());
            mEmailTextView =((CustomTextView) rootView.findViewById(R.id.emailTextView));
            mEmailTextView .setText(mMemberDetails.getEmailid());

            mEditMemberButton = (ImageButton) rootView.findViewById(R.id.deleteMember);
            mDeleteMemberButton = (ImageButton) rootView.findViewById(R.id.editMemberButton);
            mEditMemberButton.setOnClickListener(this);
            mDeleteMemberButton.setOnClickListener(this);

            if (mMemberDetails.getMemberType().equalsIgnoreCase("1")) {
                ((CustomTextView) rootView.findViewById(R.id.memberTypeTextView)).setText(getString(R.string.primary));
                mEditMemberButton.setVisibility(View.GONE);
            } else {
                ((CustomTextView) rootView.findViewById(R.id.memberTypeTextView)).setText(getString(R.string.secondary));
            }

            ((CustomTextView) rootView.findViewById(R.id.centerNameTextView)).setText(mMemberDetails.getCenterName());
        }
        return rootView;
    }

    public void setData(MemberModel memberModel) {
        if (isAdded()) {
            this.mMemberDetails = memberModel;
            mMemberNameTextView.setText(mMemberDetails.getName());
            mDobTextView.setText(mMemberDetails.getDob());
            mEmailTextView .setText(mMemberDetails.getEmailid());
            Logger.e("anwar", "setData:" + memberModel);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.editMemberButton:
                EditMemberFragment editMemberFragment = new EditMemberFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.MEMBER_DETAILS, mMemberDetails);
                editMemberFragment.setArguments(bundle);
                activityHandle.onReplaceFragment(editMemberFragment, true);
                break;
            case R.id.deleteMember:
                AlertDialogUtility.showDeleteDialog(activityHandle, getString(R.string.delete_member),
                        getString(R.string.delete_member_msg),
                        getString(R.string.yes),
                        getString(R.string.no),
                        false,
                        new AlertMagnatic() {
                            @Override
                            public void onButtonClicked(boolean yes) {
                                if (yes) {
                                    deleteMember();
                                }
                            }
                        });
                break;
        }
    }

    private void deleteMember() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.deleting));

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setId(mMemberDetails.getMemberLoginId());
        genericRequestModel.setType(Constants.MEMBER);

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().deleteItem(genericRequestModel);

        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                activityHandle.hideProgress();
                if (genericResponseModel != null && genericResponseModel.getStatus() == 1) {
                    //store user response in session
                    Toast.makeText(activityHandle, genericResponseModel.getMsg(), Toast.LENGTH_LONG).show();
                    ((MemberDetailsParentFragment) getParentFragment()).getMemberList();
                } else {
                    Toast.makeText(activityHandle, genericResponseModel.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mMemberDetails = null;
        mEditMemberButton = null;
        mDeleteMemberButton = null;
        mMemberNameTextView  = null;
        mDobTextView  = null;
        mEmailTextView  = null;
    }

}
