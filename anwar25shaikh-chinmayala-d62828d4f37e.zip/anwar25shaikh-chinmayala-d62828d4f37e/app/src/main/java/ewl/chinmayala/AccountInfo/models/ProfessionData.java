package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/2/2016.
 */
public class ProfessionData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("occupation_name")
    @Expose
    private String occupationName;
    @SerializedName("occupation_description")
    @Expose
    private String occupationDescription;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("is_active")
    @Expose
    private String isActive;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The occupationName
     */
    public String getOccupationName() {
        return occupationName;
    }

    /**
     *
     * @param occupationName
     * The occupation_name
     */
    public void setOccupationName(String occupationName) {
        this.occupationName = occupationName;
    }

    /**
     *
     * @return
     * The occupationDescription
     */
    public String getOccupationDescription() {
        return occupationDescription;
    }

    /**
     *
     * @param occupationDescription
     * The occupation_description
     */
    public void setOccupationDescription(String occupationDescription) {
        this.occupationDescription = occupationDescription;
    }

    /**
     *
     * @return
     * The createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     *
     * @param createdDate
     * The created_date
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     *
     * @return
     * The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     *
     * @param isActive
     * The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    @Override
    public String toString() {
        return "ProfessionData{" +
                "id='" + id + '\'' +
                ", occupationName='" + occupationName + '\'' +
                ", occupationDescription='" + occupationDescription + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", isActive='" + isActive + '\'' +
                '}';
    }
}
