package ewl.chinmayala.AccountInfo.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import ewl.chinmayala.AccountInfo.models.BvClass;
import ewl.chinmayala.AccountInfo.models.BvClassListResModel;
import ewl.chinmayala.AccountInfo.models.ChildRegModel;
import ewl.chinmayala.AccountInfo.models.GenericRequestModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.AccountInfo.models.LanguageData;
import ewl.chinmayala.AccountInfo.models.LanguageResponseModel;
import ewl.chinmayala.AccountInfo.models.LoginData;
import ewl.chinmayala.AccountInfo.models.SchoolGradeData;
import ewl.chinmayala.AccountInfo.models.SchoolGradeResModel;
import ewl.chinmayala.AccountInfo.models.SessionData;
import ewl.chinmayala.AccountInfo.models.SessionListData;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.UI.CustomSpinnerAdapter;
import ewl.chinmayala.Utils.DatePickerUtility;
import ewl.chinmayala.Utils.Logger;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.Utils.Utils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar Shaikh on 2/11/2016.
 */
public class AddChildFragment extends BaseFragment implements View.OnClickListener {

    private static final String TAG = AddChildFragment.class.getSimpleName();
    private CustomSpinnerAdapter mLanguageAdapter;

    private EditText mNameEditText;
    private TableRow mDatePicker;
    private EditText mDobEditText;

    private RadioButton mMaleRadioButton;
    private EditText mEmailEditText;
    private EditText mPasswordEditText;
    private EditText mRetypePwdEditText;

    private EditText mHomePhoneEditText;
    private EditText mCellPhoneEditText;


    private EditText mCurrSchoolEditText;
    private EditText mDistrictEditText;
    private EditText mSchoolCityEditText;

    private Spinner mLanguageSpinner;
    private Spinner mSchoolGradeSpinner;
    private Spinner mBvClassSpinner;

    private ArrayList<String> languageArrayList;

    private CustomAppCompatButton mSubmitButton;

    private CustomAppCompatButton mGotoPaymentButton;

    private HomeActivity activityHandle;
    private ArrayList<String> schoolGradeList;
    private CustomSpinnerAdapter mSchoolGradeAdapter;
    private ArrayList<String> bvClassArrayList;
    private CustomSpinnerAdapter mBvClassAdapter;
    private HashMap<String, String> mSchoolGradeMapping;
    private HashMap<String, String> mLanguageMapping;
    private HashMap<String, String> mBvClassMapping;

 //   private Userdata member1Details;
    private boolean isFromDashboard = false;
    private HashMap<String, String> mSessionListMapping;
    private Spinner mSessionSpinner;
    private CustomSpinnerAdapter mSessionAdapter;
    private ArrayList<String> sessionArrayList;
    private LoginData loggedInMemberDetails;


    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_child_fragment_layout, container, false);
        if (getArguments() != null) {
            if (getArguments().getBoolean(Constants.IS_FROM_DASHBOARD)) {
                activityHandle.setToolbarInitialization(this, getString(R.string.register_child));
                isFromDashboard = true;
            }

        }
        // activityHandle.setToolbarInitialization(this, getString(R.string.register_chils));
        mapControls(view);
        Gson gson = new Gson();
        String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        loggedInMemberDetails = gson.fromJson(member1DetailsString, LoginData.class);
        new DownloadData().execute(loggedInMemberDetails.getCenterId());
        return view;
    }

  /*  @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            Gson gson = new Gson();
            String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
            member1Details = gson.fromJson(member1DetailsString, Userdata.class);
            activityHandle.setToolbarInitialization(this, getString(R.string.child));
            new DownloadData().execute(member1Details.getCenterId());
        }
    }*/

    @Override
    public void mapControls(View rootView) {

        mNameEditText = (EditText) rootView.findViewById(R.id.nameEditText);

        mDatePicker = (TableRow) rootView.findViewById(R.id.birthDatePicker);
        mDatePicker.setOnClickListener(this);
        mDobEditText = (EditText) rootView.findViewById(R.id.dobEditText);

        mMaleRadioButton = (RadioButton) rootView.findViewById(R.id.maleRadioButton);
        mEmailEditText = (CustomEditText) rootView.findViewById(R.id.emailEditText);
        mPasswordEditText = (CustomEditText) rootView.findViewById(R.id.passwordEditText);
        mRetypePwdEditText = (CustomEditText) rootView.findViewById(R.id.passwordRetypeEditText);
        mHomePhoneEditText = (CustomEditText) rootView.findViewById(R.id.homePhoneEditText);
        mCellPhoneEditText = (CustomEditText) rootView.findViewById(R.id.cellPhoneEditText);

        mCurrSchoolEditText = (CustomEditText) rootView.findViewById(R.id.curSchoolEditText);
        mDistrictEditText = (CustomEditText) rootView.findViewById(R.id.disctrictEditText);
        mSchoolCityEditText = (CustomEditText) rootView.findViewById(R.id.cityEditText);

        mSessionSpinner = (Spinner) rootView.findViewById(R.id.sessionSpinner);
        sessionArrayList = new ArrayList<String>();
        sessionArrayList.add(getString(R.string.select_session_m));
        mSessionAdapter = new CustomSpinnerAdapter(activityHandle, R.layout.spinner_item_layout, sessionArrayList);
        // Drop down layout style - list view with radio button
        mSessionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mSessionSpinner.setAdapter(mSessionAdapter);


        mLanguageSpinner = (Spinner) rootView.findViewById(R.id.languageSpinner);
        languageArrayList = new ArrayList<String>();
        languageArrayList.add(getString(R.string.select_language));
        mLanguageAdapter = new CustomSpinnerAdapter(activityHandle, R.layout.spinner_item_layout, languageArrayList);
        // Drop down layout style - list view with radio button
        mLanguageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mLanguageSpinner.setAdapter(mLanguageAdapter);

        mSchoolGradeSpinner = (Spinner) rootView.findViewById(R.id.schoolGradeListSpinner);
        schoolGradeList = new ArrayList<String>();
        schoolGradeList.add(getString(R.string.next_year_school_grade_m));
        mSchoolGradeAdapter = new CustomSpinnerAdapter(activityHandle, R.layout.spinner_item_layout, schoolGradeList);
        // Drop down layout style - list view with radio button
        mSchoolGradeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mSchoolGradeSpinner.setAdapter(mSchoolGradeAdapter);
        mSchoolGradeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Logger.e(TAG, mSchoolGradeAdapter.getItem(position));
                if(mSchoolGradeMapping != null){
                    getBvClasses(mSchoolGradeMapping.get(mSchoolGradeAdapter.getItem(position)));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mBvClassSpinner = (Spinner) rootView.findViewById(R.id.bvClassListSpinner);
        bvClassArrayList = new ArrayList<String>();
        bvClassArrayList.add(getString(R.string.select_bv_class_m));
        mBvClassAdapter = new CustomSpinnerAdapter(activityHandle, R.layout.spinner_item_layout, bvClassArrayList);
        // Drop down layout style - list view with radio button
        mBvClassAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        mBvClassSpinner.setAdapter(mBvClassAdapter);

        mSubmitButton = (CustomAppCompatButton) rootView.findViewById(R.id.btnSubmit);
        mSubmitButton.setOnClickListener(this);

        mGotoPaymentButton = (CustomAppCompatButton) rootView.findViewById(R.id.paymentButton);
        mGotoPaymentButton.setOnClickListener(this);

        mBvClassMapping = new HashMap<String, String>();
        mSessionListMapping = new HashMap<String, String>();
    }

    private void getBvClasses(String schoolGrade) {
        activityHandle.showProgress(getString(R.string.loading_msg));

        GenericRequestModel genericRequestModel = new GenericRequestModel();
        genericRequestModel.setCenterId(Integer.parseInt(loggedInMemberDetails.getCenterId()));
        genericRequestModel.setSchoolGrade(schoolGrade);

        Call<BvClassListResModel> call = RetrofitInstance.getInstance().getBvClassList(genericRequestModel);
        call.enqueue(new Callback<BvClassListResModel>() {
            @Override
            public void onResponse(Call<BvClassListResModel> call, Response<BvClassListResModel> response) {
                BvClassListResModel bvClassListResModel = response.body();
                if (bvClassListResModel != null && bvClassListResModel.getStatus() == 1) {
                    if (bvClassListResModel.getUserdata() != null) {
                        bvClassArrayList.clear();
                        mBvClassMapping.clear();
                        // bvClassArrayList = new ArrayList<String>();
                        bvClassArrayList.add(getString(R.string.select_bv_class_m));
                        for (BvClass bvClass : bvClassListResModel.getUserdata()) {
                            bvClassArrayList.add(bvClass.getClassName());
                            mBvClassMapping.put(bvClass.getClassName(), bvClass.getId());
                        }
                        mBvClassAdapter.notifyDataSetChanged();
                    }
                }
                activityHandle.hideProgress();
            }

            @Override
            public void onFailure(Call<BvClassListResModel> call, Throwable t) {
                activityHandle.hideProgress();
            }
        });
    }

    private void resetAllData() {

        if (mGotoPaymentButton.getVisibility() == View.GONE) {
            mGotoPaymentButton.setVisibility(View.VISIBLE);
        }
        mNameEditText.setText(null);
        mNameEditText.requestFocus();
        mDobEditText.setText(null);
        mEmailEditText.setText(null);
        mPasswordEditText.setText(null);
        mRetypePwdEditText.setText(null);
        mHomePhoneEditText.setText(null);
        mCellPhoneEditText.setText(null);

        mCurrSchoolEditText.setText(null);
        mDistrictEditText.setText(null);
        mSchoolCityEditText.setText(null);
    }

    @Override
    public boolean validate() {

        mNameEditText.setError(null);
        mEmailEditText.setError(null);
        mPasswordEditText.setError(null);
        mRetypePwdEditText.setError(null);
        mHomePhoneEditText.setError(null);
        mCellPhoneEditText.setError(null);

        mCurrSchoolEditText.setError(null);
        mDistrictEditText.setError(null);
        mSchoolCityEditText.setError(null);


        if (String.valueOf(mSessionSpinner.getSelectedItem()).equalsIgnoreCase(getString(R.string.select_session_m))) {
            mSessionSpinner.requestFocus();
            Toast.makeText(activityHandle, getString(R.string.pls_select_session), Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mNameEditText.getText()))) {
            mNameEditText.requestFocus();
            mNameEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mDobEditText.getText()))) {
            Toast.makeText(activityHandle, getString(R.string.select_dob), Toast.LENGTH_SHORT).show();
            return false;
        }

      /*  if (String.valueOf(mLanguageSpinner.getSelectedItem()).equalsIgnoreCase(getString(R.string.select_language))) {
            mLanguageSpinner.requestFocus();
            Toast.makeText(activityHandle, getString(R.string.select_language), Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(String.valueOf(mEmailEditText.getText()))) {
            mEmailEditText.requestFocus();
            mEmailEditText.setError(getString(R.string.error_field_required));
            return false;
        }*/
        if (!TextUtils.isEmpty(mEmailEditText.getText().toString()) && !Utils.validateEmail(mEmailEditText.getText().toString())) {
            mEmailEditText.requestFocus();
            mEmailEditText.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        }
       /* if (TextUtils.isEmpty(String.valueOf(mPasswordEditText.getText()))) {
            mPasswordEditText.requestFocus();
            mPasswordEditText.setError(getString(R.string.error_field_required));
            return false;
        }*/
        if (!TextUtils.isEmpty(String.valueOf(mPasswordEditText.getText())) && !Utils.validatePassword(mPasswordEditText.getText().toString())) {
            mPasswordEditText.requestFocus();
            mPasswordEditText.setError(getString(R.string.password_must_be6_char));
            return false;
        }
        if (!TextUtils.isEmpty(String.valueOf(mPasswordEditText.getText()))  && TextUtils.isEmpty(String.valueOf(mRetypePwdEditText.getText()))) {
            mRetypePwdEditText.requestFocus();
            mRetypePwdEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (!String.valueOf(mPasswordEditText.getText()).equals(String.valueOf(mRetypePwdEditText.getText()))) {
            Toast.makeText(activityHandle, getString(R.string.password_error), Toast.LENGTH_SHORT).show();
            return false;
        }

      /*  if (TextUtils.isEmpty(String.valueOf(mHomePhoneEditText.getText()))) {
            mHomePhoneEditText.requestFocus();
            mHomePhoneEditText.setError(getString(R.string.error_field_required));
            return false;
        }*/
      /*  if (TextUtils.isEmpty(String.valueOf(mCellPhoneEditText.getText()))) {
            mCellPhoneEditText.requestFocus();
            mCellPhoneEditText.setError(getString(R.string.error_field_required));
            return false;
        }

        if (TextUtils.isEmpty(String.valueOf(mCurrSchoolEditText.getText()))) {
            mCurrSchoolEditText.requestFocus();
            mCurrSchoolEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mDistrictEditText.getText()))) {
            mDistrictEditText.requestFocus();
            mDistrictEditText.setError(getString(R.string.error_field_required));
            return false;
        }
        if (TextUtils.isEmpty(String.valueOf(mSchoolCityEditText.getText()))) {
            mSchoolCityEditText.requestFocus();
            mSchoolCityEditText.setError(getString(R.string.error_field_required));
            return false;
        }*/

        if (String.valueOf(mSchoolGradeSpinner.getSelectedItem()).equalsIgnoreCase(getString(R.string.next_year_school_grade_m))) {
            mSchoolGradeSpinner.requestFocus();
            Toast.makeText(activityHandle, getString(R.string.select_school_grade), Toast.LENGTH_SHORT).show();
            return false;
        }

        if (String.valueOf(mBvClassSpinner.getSelectedItem()).equalsIgnoreCase(getString(R.string.select_bv_class_m))) {
            mBvClassSpinner.requestFocus();
            Toast.makeText(activityHandle, getString(R.string.select_bv_class), Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private class DownloadData extends AsyncTask<String, Void, HashMap<String, Object>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
                activityHandle.showNetworkErrorToast();
                return;
            }
            //    activityHandle.showProgress(getString(R.string.loading_msg));
        }

        @Override
        protected HashMap<String, Object> doInBackground(String... params) {
            HashMap<String, Object> resultMap = new HashMap<String, Object>();
            Call<SchoolGradeResModel> profCall = RetrofitInstance.getInstance().getSchoolGradeList();
            GenericRequestModel genericRequestModel = new GenericRequestModel(Integer.parseInt(params[0]));
            Call<LanguageResponseModel> langCall = RetrofitInstance.getInstance()
                    .getLanguages(genericRequestModel);
            Call<SessionListData> sessionListDataCall = RetrofitInstance.getInstance().getSessionList(genericRequestModel);
            try {
                //    Response<CenterListResponse> centerListResponseResponse  = centerCall.execute();
                Response<SchoolGradeResModel> schoolGradeDataResponse = profCall.execute();
                Response<LanguageResponseModel> languageResponseModelResponse = langCall.execute();
                Response<SessionListData> sessionListDataResponse = sessionListDataCall.execute();
                resultMap.put(Constants.SCHOOL_GRADE_OBJ, schoolGradeDataResponse.body());
                resultMap.put(Constants.LANG_OBJ, languageResponseModelResponse.body());
                resultMap.put(Constants.SESSION_LIST_OBJ, sessionListDataResponse.body());
                Logger.e(TAG, resultMap.toString());

            } catch (IOException e) {
                Logger.e(TAG, e.toString());
            }
            return resultMap;
        }

        @Override
        protected void onPostExecute(HashMap<String, Object> resultMap) {
            super.onPostExecute(resultMap);
            // activityHandle.hideProgress();
            loadData(resultMap);
        }
    }

    private void loadData(HashMap<String, Object> resultMap) {
        SchoolGradeResModel schoolGradeResModel = (SchoolGradeResModel) resultMap.get(Constants.SCHOOL_GRADE_OBJ);
        LanguageResponseModel languageResponseModel = (LanguageResponseModel) resultMap.get(Constants.LANG_OBJ);
        SessionListData sessionListData = (SessionListData) resultMap.get(Constants.SESSION_LIST_OBJ);

        mLanguageMapping = new HashMap<String, String>();
        mSchoolGradeMapping = new HashMap<String, String>();
        mSessionListMapping = new HashMap<String, String>();

        if (languageResponseModel != null && languageResponseModel.getLanguageDataList() != null
                && languageArrayList != null ) {
            for (LanguageData languageData : languageResponseModel.getLanguageDataList()) {
                languageArrayList.add(languageData.getLangName());
                mLanguageMapping.put(languageData.getLangName(),languageData.getId());
            }
            mLanguageAdapter.notifyDataSetChanged();
        }

        if (schoolGradeResModel != null && schoolGradeResModel.getUserdata() != null && schoolGradeList != null ) {
            for (SchoolGradeData schoolGradeData : schoolGradeResModel.getUserdata()) {
                schoolGradeList.add(schoolGradeData.getGradeName());
                mSchoolGradeMapping.put(schoolGradeData.getGradeName(), schoolGradeData.getId());
            }
            mSchoolGradeAdapter.notifyDataSetChanged();
        }

        if (sessionListData != null && sessionListData.getUserdata() != null && sessionArrayList != null ) {
            for (SessionData sessionData : sessionListData.getUserdata()) {
                sessionArrayList.add(sessionData.getSessionName()+"("+sessionData.getSessionStart()+"-"+sessionData.getSessionEnd()+")");
                mSessionListMapping.put(sessionData.getSessionName()+"("+sessionData.getSessionStart()+"-"+sessionData.getSessionEnd()+")",sessionData.getId());
            }
            mSessionAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:
                if (validate()) {
                    registerChild();
                }
                break;
            case R.id.birthDatePicker:
                new DatePickerUtility(mDobEditText, getContext());
                break;
            case R.id.paymentButton:
                ((RegisterParentFragment) getParentFragment()).replaceChildFragment(new PaymentFragment());
                break;
        }
    }

    private ChildRegModel getModel() {

        ChildRegModel childRegModel = new ChildRegModel();
        childRegModel.setMemberCenterId(loggedInMemberDetails.getCenterId());
        childRegModel.setMemberSessionId(mSessionListMapping.get(String.valueOf(mSessionSpinner.getSelectedItem())));
        childRegModel.setFamilyId(loggedInMemberDetails.getFamilyId());
      //  childRegModel.setMemberSessionId(loggedInMemberDetails.getSessionId());

        childRegModel.setChildName(String.valueOf(mNameEditText.getText()));
        childRegModel.setChildDob(String.valueOf(mDobEditText.getText()));

        if (mMaleRadioButton.isChecked()) {
            childRegModel.setChildGender(getString(R.string.male));
        } else {
            childRegModel.setChildGender(getString(R.string.female));
        }
        childRegModel.setChildLang(mLanguageMapping.get(String.valueOf(mLanguageSpinner.getSelectedItem())));
        childRegModel.setChildEmailid(String.valueOf(mEmailEditText.getText()));
        childRegModel.setPassword(String.valueOf(mPasswordEditText.getText()));
        childRegModel.setChildHomephone(String.valueOf(mHomePhoneEditText.getText()));
        childRegModel.setChildCellphone(String.valueOf(mCellPhoneEditText.getText()));
        childRegModel.setChildCurrentSchool(String.valueOf(mCurrSchoolEditText.getText()));
        childRegModel.setDistrictName(String.valueOf(mDistrictEditText.getText()));
        childRegModel.setChildSchoolCity(String.valueOf(mSchoolCityEditText.getText()));

        childRegModel.setChildGradeId(mSchoolGradeMapping.get(String.valueOf(mSchoolGradeSpinner.getSelectedItem())));
        childRegModel.setChildClassId(mBvClassMapping.get(String.valueOf(mBvClassSpinner.getSelectedItem())));

        childRegModel.setAge(Utils.getAge(String.valueOf(mDobEditText.getText())));
        return childRegModel;
    }

    private void registerChild() {
        //resetAllData();
        activityHandle.showProgress(getString(R.string.register_msg));

        RetrofitInstance.getInstance().registerChild(getModel()).enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel genericResponseModel = response.body();
                if (genericResponseModel.getStatus() == 1) {
                    // store data in db
                   // ChildRegModel childRegModel = getModel() ;
                   // childRegModel.setChildClassId(String.valueOf(mBvClassSpinner.getSelectedItem()));
                   // childRegModel.setMemberSessionId(String.valueOf(mSessionSpinner.getSelectedItem()));
                    //(new ChildAdapter()).insert(childRegModel);
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, getString(R.string.register_sucess), Toast.LENGTH_SHORT).show();
                    if (isFromDashboard){
                        activityHandle.getSupportFragmentManager().popBackStack();
                    } else{
                        resetAllData();
                    }

                    // ((RegisterParentFragment)getParentFragment()).replaceChildFragment(new AddChildFragment());
                } else {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, genericResponseModel.getErrorMsg(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
                activityHandle.hideProgress();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mLanguageAdapter = null;
        mNameEditText = null;
        mDatePicker = null;
        mDobEditText = null;

        mMaleRadioButton = null;
        mEmailEditText = null;
        mPasswordEditText = null;
        mRetypePwdEditText = null;

        mHomePhoneEditText = null;
        mCellPhoneEditText = null;
        mCurrSchoolEditText = null;
        mDistrictEditText = null;
        mSchoolCityEditText = null;

        mLanguageSpinner = null;
        mSchoolGradeSpinner = null;
        mBvClassSpinner = null;

        languageArrayList = null;

        mSubmitButton = null;

        mGotoPaymentButton = null;

        schoolGradeList = null;
        mSchoolGradeAdapter = null;
        bvClassArrayList = null;
        mBvClassAdapter = null;
        mSchoolGradeMapping = null;
        mLanguageMapping = null;
        mBvClassMapping = null;

        loggedInMemberDetails = null;
        isFromDashboard = false;
        mSessionListMapping = null;
        mSessionSpinner = null;
        mSessionAdapter = null;
        sessionArrayList = null;
    }

}
