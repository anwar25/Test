package ewl.chinmayala.DB;

import android.provider.BaseColumns;


/**
 * <p>This is class which contains database stucture ( tables).</p>
 *
 * @author Anwar Shaikh
 */
public final class ChinTable {

    /**
     * To prevent someone from accidentally instantiating the contract class,
     * give it an empty constructor.
     */
    public ChinTable() {
    }

    /**
     * Database query/table constants.
     */
    public static final String COMMA_SEP = ",";
    public static final String SEMICOLON = ";";
    public static final String CREATE_TABLE = "CREATE TABLE ";
    public static final String SELECT = "SELECT ";
    public static final String FROM = " FROM ";
    public static final String SELECT_STAR_FROM = "SELECT * FROM ";
    public static final String SELECT_COUNT_START_FROM = "SELECT COUNT(*) FROM ";
    private static final String DT_INTEGER_PRIMARY_KEY_AUTO = " INTEGER PRIMARY KEY AUTOINCREMENT";
    private static final String DT_TEXT = " TEXT";
    private static final String DT_REAL = " REAL";
    private static final String DT_TEXT_NOT_NULL = " TEXT NOT NULL";
    private static final String DT_NULL = " NULL ";
    public static final String OR = " OR ";
    public static final String WHERE = " WHERE ";
    public static final String BETWEEN = " BETWEEN ";
    public static final String ORDER_BY = " ORDER BY ";
    public static final String DESCENDING = " DESC ";
    public static final String ASCENDING = " ASC ";


    public static abstract class Member implements BaseColumns {

        public static final String TABLE_NAME = "member";
        public static final String COLUMN_NAME_MEM_DATA = "member_data";
    }

    public static final String SQL_CREATE_MEMBER = new StringBuilder(CREATE_TABLE)
            .append(Member.TABLE_NAME).append(" ( ")
            .append(Member._ID + DT_INTEGER_PRIMARY_KEY_AUTO).append(COMMA_SEP)
            .append(Member.COLUMN_NAME_MEM_DATA+ DT_TEXT)
            .append(" );").toString();

    public static abstract class Child implements BaseColumns {

        public static final String TABLE_NAME = "child";
        public static final String COLUMN_NAME_CHILD_DATA = "child_data";
    }

    public static final String SQL_CREATE_CHILD = new StringBuilder(CREATE_TABLE)
            .append(Child.TABLE_NAME).append(" ( ")
            .append(Child._ID + DT_INTEGER_PRIMARY_KEY_AUTO).append(COMMA_SEP)
            .append(Child.COLUMN_NAME_CHILD_DATA+ DT_TEXT)
            .append(" );").toString();

    public static abstract class Trust implements BaseColumns {

        public static final String TABLE_NAME = "trust";
        public static final String COLUMN_NAME_TRUST_DATA = "trust_data";
    }

    public static final String SQL_CREATE_TRUST = new StringBuilder(CREATE_TABLE)
            .append(Trust.TABLE_NAME).append(" ( ")
            .append(Trust._ID + DT_INTEGER_PRIMARY_KEY_AUTO).append(COMMA_SEP)
            .append(Trust.COLUMN_NAME_TRUST_DATA+ DT_TEXT)
            .append(" );").toString();
}