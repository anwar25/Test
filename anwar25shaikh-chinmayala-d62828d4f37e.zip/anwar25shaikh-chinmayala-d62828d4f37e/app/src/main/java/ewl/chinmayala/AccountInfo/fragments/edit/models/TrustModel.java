package ewl.chinmayala.AccountInfo.fragments.edit.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Anwar on 7/30/2016.
 */
public class TrustModel implements Serializable{
    @SerializedName("trust_id")
    @Expose
    private String trustId;
    @SerializedName("family_id")
    @Expose
    private String familyId;
    @SerializedName("company")
    @Expose
    private String company;
    @SerializedName("company_phone")
    @Expose
    private String companyPhone;
    @SerializedName("company_address")
    @Expose
    private String companyAddress;
    @SerializedName("street_number")
    @Expose
    private String streetNumber;
    @SerializedName("route")
    @Expose
    private String route;
    @SerializedName("locality")
    @Expose
    private String locality;
    @SerializedName("state")
    @Expose
    private String state;
    @SerializedName("postal_code")
    @Expose
    private String postalCode;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("taxid")
    @Expose
    private Object taxid;
    @SerializedName("last_update_userid")
    @Expose
    private Object lastUpdateUserid;
    @SerializedName("last_update_tstamp")
    @Expose
    private String lastUpdateTstamp;

    /**
     *
     * @return
     * The trustId
     */
    public String getTrustId() {
        return trustId;
    }

    /**
     *
     * @param trustId
     * The trust_id
     */
    public void setTrustId(String trustId) {
        this.trustId = trustId;
    }

    /**
     *
     * @return
     * The familyId
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     * The family_id
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     * The company
     */
    public String getCompany() {
        return company;
    }

    /**
     *
     * @param company
     * The company
     */
    public void setCompany(String company) {
        this.company = company;
    }

    /**
     *
     * @return
     * The companyPhone
     */
    public String getCompanyPhone() {
        return companyPhone;
    }

    /**
     *
     * @param companyPhone
     * The company_phone
     */
    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    /**
     *
     * @return
     * The companyAddress
     */
    public String getCompanyAddress() {
        return companyAddress;
    }

    /**
     *
     * @param companyAddress
     * The company_address
     */
    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    /**
     *
     * @return
     * The streetNumber
     */
    public String getStreetNumber() {
        return streetNumber;
    }

    /**
     *
     * @param streetNumber
     * The street_number
     */
    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    /**
     *
     * @return
     * The route
     */
    public String getRoute() {
        return route;
    }

    /**
     *
     * @param route
     * The route
     */
    public void setRoute(String route) {
        this.route = route;
    }

    /**
     *
     * @return
     * The locality
     */
    public String getLocality() {
        return locality;
    }

    /**
     *
     * @param locality
     * The locality
     */
    public void setLocality(String locality) {
        this.locality = locality;
    }

    /**
     *
     * @return
     * The state
     */
    public String getState() {
        return state;
    }

    /**
     *
     * @param state
     * The state
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     *
     * @return
     * The postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     *
     * @param postalCode
     * The postal_code
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     *
     * @return
     * The country
     */
    public String getCountry() {
        return country;
    }

    /**
     *
     * @param country
     * The country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     *
     * @return
     * The taxid
     */
    public Object getTaxid() {
        return taxid;
    }

    /**
     *
     * @param taxid
     * The taxid
     */
    public void setTaxid(Object taxid) {
        this.taxid = taxid;
    }

    /**
     *
     * @return
     * The lastUpdateUserid
     */
    public Object getLastUpdateUserid() {
        return lastUpdateUserid;
    }

    /**
     *
     * @param lastUpdateUserid
     * The last_update_userid
     */
    public void setLastUpdateUserid(Object lastUpdateUserid) {
        this.lastUpdateUserid = lastUpdateUserid;
    }

    /**
     *
     * @return
     * The lastUpdateTstamp
     */
    public String getLastUpdateTstamp() {
        return lastUpdateTstamp;
    }

    /**
     *
     * @param lastUpdateTstamp
     * The last_update_tstamp
     */
    public void setLastUpdateTstamp(String lastUpdateTstamp) {
        this.lastUpdateTstamp = lastUpdateTstamp;
    }

    @Override
    public String toString() {
        return "TrustModel{" +
                "trustId='" + trustId + '\'' +
                ", familyId='" + familyId + '\'' +
                ", company='" + company + '\'' +
                ", companyPhone='" + companyPhone + '\'' +
                ", companyAddress='" + companyAddress + '\'' +
                ", streetNumber='" + streetNumber + '\'' +
                ", route='" + route + '\'' +
                ", locality='" + locality + '\'' +
                ", state='" + state + '\'' +
                ", postalCode='" + postalCode + '\'' +
                ", country='" + country + '\'' +
                ", taxid=" + taxid +
                ", lastUpdateUserid=" + lastUpdateUserid +
                ", lastUpdateTstamp='" + lastUpdateTstamp + '\'' +
                '}';
    }
}
