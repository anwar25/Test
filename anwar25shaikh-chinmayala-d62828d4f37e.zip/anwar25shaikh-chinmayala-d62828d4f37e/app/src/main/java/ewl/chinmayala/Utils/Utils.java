package ewl.chinmayala.Utils;

import android.content.Context;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ewl.chinmayala.Entity.Event;
import ewl.chinmayala.R;

/**
 * Created by Anwar shaikh on 11/21/2015.
 */
public class Utils {

    public static int getToolbarHeight(Context context) {
        int height = (int) context.getResources().getDimension(R.dimen.abc_action_bar_default_height_material);
        return height;
    }

    public static void hideSoftKeyboard(Context context,View view) {
        InputMethodManager imm = (InputMethodManager) context
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
    }

    public static void showToast(Context context,String stringText) {
        Toast.makeText(context, stringText, Toast.LENGTH_SHORT).show();

    }

    public static void ShowSoftKeyboard(Context context,View view) {
        InputMethodManager imm = (InputMethodManager) context
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(view, 1);
    }
    public static boolean validateEmail(String email) {
        email = email.trim();
        Pattern pattern;
        Matcher matcher;
        String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }

    public static boolean validatePhone(String phone) {
        if(phone.length()>=10)
            return true;
        else
            return false;

    }

    public static boolean validatePassword(String phone) {
        if(phone.length()>= 6)
            return true;
        else
            return false;

    }

    public static String DeviceID(Context context){
        String device_id = ((TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE))
                .getDeviceId();
        if (device_id == null) {
            device_id = Settings.Secure.getString(context
                    .getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        return device_id;
    }

    public static int getAge(String birthDate){
        //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/DD/YYYY");
        String birthDateArray [] = birthDate.split("/");
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(Integer.parseInt(birthDateArray[2]), Integer.parseInt(birthDateArray[0]), Integer.parseInt(birthDateArray[1]));

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        /*if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }*/
        return age;
    }

    public static void  copyFile(Context context)
    {
        try
        {
            File sd = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString());
            File data = Environment.getDataDirectory();
            boolean  bool =true;
            if (sd.canWrite())
            {
                String currentDBPath = "/data/" + context.getPackageName() + "/databases/db_eyes4deal.el";

                if(android.os.Build.VERSION.SDK_INT >= 4.2){
                    currentDBPath = context.getApplicationInfo().dataDir + "/databases/db_eyes4deal.el";
                } else {
                    currentDBPath = "/data/" + context.getPackageName() + "/databases/db_eyes4deal.el";
                }
                String backupDBPath = "db_eyes4deal.el";

                File currentDB = new File(currentDBPath);
                File backupDB = new File(sd, backupDBPath);

                if (currentDB.exists()) {
                    FileChannel src = new FileInputStream(currentDB).getChannel();
                    FileChannel dst = new FileOutputStream(backupDB).getChannel();
                    dst.transferFrom(src, 0, src.size());
                    src.close();
                    dst.close();
                }

            }
        }
        catch (Exception e) {
            Logger.d("Settings Backup","::"+e);
        }
    }

    public static String DoubleDigitDecimal(Double price) {

        NumberFormat nf = NumberFormat.getNumberInstance(Locale.ENGLISH);
        DecimalFormat df = (DecimalFormat) nf;
        df.applyPattern("0.00");
        return df.format(price);
    }


    public static String getCurrentDateTime() {
        return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
    }

    public static String getCurrentDate() {
        return (new SimpleDateFormat("MM/dd/yyyy")).format(new Date());
    }

    public static void AddEvent(ArrayList<Event> eventArrayList) {
        Event event = new Event();
        event.setId(1);
        event.setEventTitle("Silent Meditation");
        event.setEventSubTitle("Come and practice meditation in the serene abode of Shiva and Sri Rama");
        event.setEventStartDateTime("02-10-2016 15:00:00");
        event.setEventEndTime("02-10-2016 16:00:00");
        event.setEventAddress("Temple Visit");
        event.setEventLongitude(34.0500);
        event.setEventLongitude(118.2500);
        event.setResource("https://chinmayala.org/sites/default/files/CMLA-JY%20Pg%201%20v2.png");
        eventArrayList.add(event);

        event = new Event();
        event.setId(2);
        event.setEventTitle("Balvihar Classes in Rameshwaram");
        event.setEventSubTitle("Weekly session for Children & Adults");
        event.setEventStartDateTime("02-10-2016 15:00:00");
        event.setEventEndTime("02-10-2016 16:00:00");
        event.setEventAddress("Visit");
        event.setEventLongitude(34.0500);
        event.setEventLongitude(118.2500);
        event.setResource("https://chinmayala.org/sites/default/files/CJY-%20On%20A%20Quest%20Screening.jpg");
        eventArrayList.add(event);

        event = new Event();
        event.setId(3);
        event.setEventTitle("Sri Rama Puja with Sri Vishnu Sahasranamam chanting");
        event.setEventSubTitle("Every Friday evening, from 7:30 PM to 9:00 PM, Shodashopachara Puja is offered...");
        event.setEventStartDateTime("02-10-2016 15:00:00");
        event.setEventEndTime("02-10-2016 16:00:00");
        event.setEventAddress("Temple Visit");
        event.setEventLongitude(34.0500);
        event.setEventLongitude(118.2500);
        event.setResource("https://chinmayala.org/sites/default/files/KailashYatra2016.png");
        eventArrayList.add(event);


        event = new Event();
        event.setId(4);
        event.setEventTitle("Silent Meditation");
        event.setEventSubTitle("Come and practice meditation in the serene abode of Shiva and Sri Rama");
        event.setEventStartDateTime("02-10-2016 15:00:00");
        event.setEventEndTime("02-10-2016 16:00:00");
        event.setEventAddress("Temple Visit");
        event.setEventLongitude(34.0500);
        event.setEventLongitude(118.2500);
        event.setResource("https://chinmayala.org/sites/default/files/CMLA-JY%20Pg%201%20v2.png");
        eventArrayList.add(event);

        event = new Event();
        event.setId(5);
        event.setEventTitle("Balvihar Classes in Rameshwaram");
        event.setEventSubTitle("Weekly session for Children & Adults");
        event.setEventStartDateTime("02-10-2016 15:00:00");
        event.setEventEndTime("02-10-2016 16:00:00");
        event.setEventAddress("Visit");
        event.setEventLongitude(34.0500);
        event.setEventLongitude(118.2500);
        event.setResource("https://chinmayala.org/sites/default/files/CJY-%20On%20A%20Quest%20Screening.jpg");
        eventArrayList.add(event);

        event = new Event();
        event.setId(6);
        event.setEventTitle("Sri Rama Puja with Sri Vishnu Sahasranamam chanting");
        event.setEventSubTitle("Every Friday evening, from 7:30 PM to 9:00 PM, Shodashopachara Puja is offered...");
        event.setEventStartDateTime("02-10-2016 15:00:00");
        event.setEventEndTime("02-10-2016 16:00:00");
        event.setEventAddress("Temple Visit");
        event.setEventLongitude(34.0500);
        event.setEventLongitude(118.2500);
        event.setResource("https://chinmayala.org/sites/default/files/KailashYatra2016.png");
        eventArrayList.add(event);

    }
}
