package ewl.chinmayala.AccountInfo.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.io.File;

import ewl.chinmayala.AccountInfo.fragments.edit.ChildDetailsParentFragment;
import ewl.chinmayala.AccountInfo.fragments.edit.MemberDetailsParentFragment;
import ewl.chinmayala.AccountInfo.fragments.edit.PaymentDetailsParentFragment;
import ewl.chinmayala.AccountInfo.fragments.edit.TrustDetailsParentFragment;
import ewl.chinmayala.AccountInfo.models.ImageUploadRes;
import ewl.chinmayala.AccountInfo.models.LoginData;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CircleImageView;
import ewl.chinmayala.UI.CustomTextView;
import ewl.chinmayala.Utils.CommonUtility;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.constants.Constants;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar on 2/10/2016.
 */
public class DashboardFragment extends BaseFragment implements View.OnClickListener {

    private HomeActivity activityHandle;

    private CustomTextView mNameTextView ;
    private CustomTextView mEmailTextView ;

    private CustomTextView mDobTextView ;
    private CustomTextView mCityTextView ;

    private LinearLayout mRegisterMember ;
    private LinearLayout mRegisterTrust;
    private LinearLayout mRegisterChild;
    private LinearLayout mPayment;
    private ImageView mAddProfilePic ;
    private CircleImageView mProfilePic  ;
    private LoginData userData ;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_dashboard_screen, container, false);
        ((HomeActivity) getActivity()).setToolbarInitialization(this, getString(R.string.dashboard));
        mapControls(view);
        return view;
    }

    @Override
    public void mapControls(View rootView) {
        mNameTextView = (CustomTextView) rootView.findViewById(R.id.nameTextView);
        mEmailTextView = (CustomTextView) rootView.findViewById(R.id.emailTextView);
        mDobTextView = (CustomTextView) rootView.findViewById(R.id.dobTextView);
        mCityTextView = (CustomTextView) rootView.findViewById(R.id.cityTextView);

        mAddProfilePic = (ImageView) rootView.findViewById(R.id.addPhotoImageView);
        mProfilePic = (CircleImageView) rootView.findViewById(R.id.profilePic);

        String userResponse = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        if(!TextUtils.isEmpty(userResponse)){
            Gson gson = new Gson();
            userData = gson.fromJson(userResponse, LoginData.class);
            //LoginData userData = loginResponse.getLoginData();
            mNameTextView.setText(userData.getName());
            mEmailTextView.setText(userData.getEmailid());
            mDobTextView.setText(userData.getDob());
            mCityTextView.setText(userData.getCountry());
            Glide.with(this)
                    .load(userData.getProfileImage())
                    .placeholder(R.drawable.avatars) // can also be a drawable
                    .dontAnimate()
                    //.error(R.drawable.avatars) // will be displayed if the image cannot be loaded
                    .into(mProfilePic);
        }

        mRegisterMember = (LinearLayout)rootView.findViewById(R.id.registerMemberLayout);
        mRegisterTrust = (LinearLayout)rootView.findViewById(R.id.registerTrustLayout);
        mRegisterChild = (LinearLayout)rootView.findViewById(R.id.registerChildLayout);
        mPayment = (LinearLayout)rootView.findViewById(R.id.paymentLayout);

        mAddProfilePic.setOnClickListener(this);
        mRegisterMember.setOnClickListener(this);
        mRegisterTrust.setOnClickListener(this);
        mRegisterChild.setOnClickListener(this);
        mPayment.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Bundle bundle = null ;
        switch (v.getId()){
            case R.id.registerMemberLayout :
               /* AddMemberFragment memberInfoFragment  = new AddMemberFragment() ;
                bundle = new Bundle();
                bundle.putBoolean(Constants.IS_FROM_DASHBOARD,true);
                memberInfoFragment.setArguments(bundle);
                String centerString = activityHandle.getSessionManager().getString(Constants.CENTER_INFO);
                Gson gson = new Gson();
                CenterData centerData = gson.fromJson(centerString , CenterData.class);
                memberInfoFragment.setCenterAddressMapping(centerData,getString(R.string.add_member2));
                activityHandle.onReplaceFragment(memberInfoFragment,true);*/
                activityHandle.onReplaceFragment(new MemberDetailsParentFragment(),true);
                break;
            case R.id.registerTrustLayout :
               /* AddEditTrustFragment trustInfoFragment  = new AddEditTrustFragment() ;
                bundle = new Bundle();
                bundle.putBoolean(Constants.IS_FROM_DASHBOARD,true);
                trustInfoFragment.setArguments(bundle);
                activityHandle.onReplaceFragment(trustInfoFragment,true);*/
                activityHandle.onReplaceFragment(new TrustDetailsParentFragment(),true);
                break;
            case R.id.registerChildLayout :
              /*  AddChildFragment childRegisterFragment  = new AddChildFragment() ;
                bundle = new Bundle();
                bundle.putBoolean(Constants.IS_FROM_DASHBOARD,true);
                childRegisterFragment.setArguments(bundle);
                activityHandle.onReplaceFragment(childRegisterFragment,true);*/
                activityHandle.onReplaceFragment(new ChildDetailsParentFragment(),true);
                break;
            case R.id.paymentLayout :
                //Utils.showToast(getActivity(), getString(R.string.work_in_progress));
                activityHandle.onReplaceFragment(new PaymentDetailsParentFragment(),true);
                break;
            case R.id.addPhotoImageView :
                Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, SELECT_FILE);
                break;
        }
    }
    private  int SELECT_FILE = 277;
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = activityHandle.getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);

            if (requestCode == SELECT_FILE) {
                String profilePicPath = cursor.getString(columnIndex);
                String scaledFilePath = CommonUtility.decodeFile(profilePicPath);
                //upload file to backend
                uploadProfilePic(scaledFilePath);
                Glide.with(this)
                        .load(profilePicPath)
                        //.placeholder(R.drawable.avatars) // can also be a drawable
                        //.error(R.drawable.avatars) // will be displayed if the image cannot be loaded
                        .into(mProfilePic);
            }
            cursor.close();
        }
    }

    private void uploadProfilePic(String profilePicPath) {
        File file = new File(profilePicPath);
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part profilePic = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
        // add another part within the multipart request
        RequestBody memberLoginId = RequestBody.create(MediaType.parse("multipart/form-data"), userData.getMemberLoginId());

        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.uploading));

        Call<ImageUploadRes> call = RetrofitInstance.getInstance().uploadProfileImage(memberLoginId,profilePic);
        call.enqueue(new Callback<ImageUploadRes>() {
            @Override
            public void onResponse(Call<ImageUploadRes> call, Response<ImageUploadRes> response) {
                ImageUploadRes imageUploadRes = response.body();
                if (imageUploadRes.getStatus() == 1) {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle,imageUploadRes.getUserdata(), Toast.LENGTH_LONG).show();
                    userData.setProfileImage(imageUploadRes.getProfileImage());
                    // store user image url locally
                    Gson gson = new Gson();
                    activityHandle.getSessionManager().putString(Constants.REGISTER_MEMBER1_DETAILS, gson.toJson(userData));
                } else {
                    activityHandle.hideProgress();
                    Toast.makeText(activityHandle, imageUploadRes.getErrorMsg(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ImageUploadRes> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });

    }

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity){
            activityHandle = (HomeActivity) context;
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        activityHandle = null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroy();
        // activityHandle = null ;
        mNameTextView = null ;
        mEmailTextView  = null ;
        mDobTextView  = null ;
        mCityTextView  = null ;
        mRegisterMember = null ;
        mRegisterTrust = null ;
        mRegisterChild = null ;
        mPayment = null ;
        mAddProfilePic = null ;
    }

}
