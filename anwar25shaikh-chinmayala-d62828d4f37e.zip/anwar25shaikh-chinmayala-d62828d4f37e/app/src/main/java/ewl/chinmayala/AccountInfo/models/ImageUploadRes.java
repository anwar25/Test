package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/27/2016.
 */
public class ImageUploadRes {

    @SerializedName("userdata")
    @Expose
    private String userdata;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("profile_image")
    @Expose
    private String profileImage;

    @SerializedName("error_msg")
    @Expose
    private String errorMsg;

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    /**
     *
     * @return
     * The userdata
     */
    public String getUserdata() {
        return userdata;
    }

    /**
     *
     * @param userdata
     * The userdata
     */
    public void setUserdata(String userdata) {
        this.userdata = userdata;
    }

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     *
     * @return
     * The profileImage
     */
    public String getProfileImage() {
        return profileImage;
    }

    /**
     *
     * @param profileImage
     * The profile_image
     */
    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

}