package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar Shaikh on 8/10/2016.
 */
public class BvAaratiFeesRes {
    @SerializedName("msg")
    @Expose
    private String msg;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private FeesModel userdata;

    /**
     *
     *
     * @return
     * The msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     *
     * @param msg
     * The msg
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

    /**
     *
     * @return
     * The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     *
     * @param status
     * The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     *
     * @return
     * The userdata
     */
    public FeesModel getUserdata() {
        return userdata;
    }

    /**
     *
     * @param userdata
     * The userdata
     */
    public void setUserdata(FeesModel userdata) {
        this.userdata = userdata;
    }


}
