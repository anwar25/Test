package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anwar on 7/24/2016.
 */
public class MemberInterestList {

    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("userdata")
    @Expose
    private List<MemberInterestModel> userdata = new ArrayList<MemberInterestModel>();

    /**
     * @return The status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status The status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return The userdata
     */
    public List<MemberInterestModel> getUserdata() {
        return userdata;
    }

    /**
     * @param userdata The userdata
     */
    public void setUserdata(List<MemberInterestModel> userdata) {
        this.userdata = userdata;
    }
}