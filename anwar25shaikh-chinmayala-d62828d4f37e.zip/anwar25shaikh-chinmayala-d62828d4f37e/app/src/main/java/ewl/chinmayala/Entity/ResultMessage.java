// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ewl.chinmayala.Entity;


import java.io.Serializable;

public class ResultMessage implements Serializable
{

    public String ERRORMESSAGE;
    public String Error;
    public String RESPONSE;
    public int STATUS;
    public String TYPE;
    public Object RESULT_OBJECT;


}
