package ewl.chinmayala.DB.database.adapters;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import java.util.ArrayList;

import ewl.chinmayala.DB.ChinDbManager;

/**
 * Created by Anwar on 6/11/2016.
 */
abstract public class ParentAdapter {//extends AsyncTask<Object, Object, Object> {

    public static final String TAG = "ParentAdapter" ;

    private SQLiteDatabase sqLiteDatabase ;

    abstract public  long insert(Object modelList);
    abstract public boolean delete(String id);
    abstract public boolean update(Object model);

    abstract public ArrayList<?> getAll();

    /*
    open database for select queries
     */
    public SQLiteDatabase openDBForReadOperation(){
        try {
            sqLiteDatabase = ChinDbManager.getInstance().openDatabase();
            return  sqLiteDatabase ;
        } catch (SQLiteException exception) {
            exception.printStackTrace();
        }
        return null ;
    }

    public SQLiteDatabase openDB(){
        try {
            Log.v(TAG, "openDB - begin");
            sqLiteDatabase = ChinDbManager.getInstance().openDatabase();
            sqLiteDatabase.beginTransaction();
            Log.v(TAG, "openDB - success");
            return  sqLiteDatabase ;
        } catch (SQLiteException exception) {
            Log.e(TAG, "openDB - exception - " + exception.getMessage());
        }
        return null ;
    }


    public void closeDB(){
        try {
            sqLiteDatabase.endTransaction();
        } catch (SQLiteException exception) {
            Log.e(TAG, "Exception in closeDB" + exception.getMessage());
        }
    }
}

