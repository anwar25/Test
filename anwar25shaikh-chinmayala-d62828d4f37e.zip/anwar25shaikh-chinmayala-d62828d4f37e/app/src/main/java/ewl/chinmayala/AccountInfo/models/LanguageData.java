package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/2/2016.
 */
public class LanguageData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("lang_name")
    @Expose
    private String langName;
    @SerializedName("is_active")
    @Expose
    private String isActive;

    /**
     * @return The id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     * @param centerId The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     * @return The langName
     */
    public String getLangName() {
        return langName;
    }

    /**
     * @param langName The lang_name
     */
    public void setLangName(String langName) {
        this.langName = langName;
    }

    /**
     * @return The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     * @param isActive The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    @Override
    public String toString() {
        return "LanguageData{" +
                "id='" + id + '\'' +
                ", centerId='" + centerId + '\'' +
                ", langName='" + langName + '\'' +
                ", isActive='" + isActive + '\'' +
                '}';
    }
}
