package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/24/2016.
 */
public class MemberInterestModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("interest_name")
    @Expose
    private String interestName;
    @SerializedName("is_active")
    @Expose
    private String isActive;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The interestName
     */
    public String getInterestName() {
        return interestName;
    }

    /**
     *
     * @param interestName
     * The interest_name
     */
    public void setInterestName(String interestName) {
        this.interestName = interestName;
    }

    /**
     *
     * @return
     * The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     *
     * @param isActive
     * The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

}
