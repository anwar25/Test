package ewl.chinmayala.UI;

import android.content.Context;
import android.widget.ExpandableListView;

/**
 * Created by Akash.Singh on 2/8/2016.
 */
public class CustExpListview extends ExpandableListView {

    public CustExpListview(Context context) {
        super(context);

    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        heightMeasureSpec = MeasureSpec.makeMeasureSpec(2000, MeasureSpec.AT_MOST);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onDetachedFromWindow() {
        try {
            super.onDetachedFromWindow();
        } catch (IllegalArgumentException e) {
        }
    }
}
