package ewl.chinmayala.AccountInfo.fragments.edit.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 8/1/2016.
 */
public class UpdateRequestModel {

    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("trust_id")
    @Expose
    private String trustId;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("company_phone")
    @Expose
    private String companyPhone;
    @SerializedName("company_address")
    @Expose
    private String companyAddress;
    @SerializedName("company_street_number")
    @Expose
    private String companyStreetNumber;
    @SerializedName("company_route")
    @Expose
    private String companyRoute;
    @SerializedName("company_locality")
    @Expose
    private String companyLocality;
    @SerializedName("company_state")
    @Expose
    private String companyState;
    @SerializedName("company_postel_code")
    @Expose
    private String companyPostelCode;
    @SerializedName("company_country")
    @Expose
    private String companyCountry;

    /**
     *
     * @return
     * The type
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     * The type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     *
     * @return
     * The trustId
     */
    public String getTrustId() {
        return trustId;
    }

    /**
     *
     * @param trustId
     * The trust_id
     */
    public void setTrustId(String trustId) {
        this.trustId = trustId;
    }

    /**
     *
     * @return
     * The companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     *
     * @param companyName
     * The company_name
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     *
     * @return
     * The companyPhone
     */
    public String getCompanyPhone() {
        return companyPhone;
    }

    /**
     *
     * @param companyPhone
     * The company_phone
     */
    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    /**
     *
     * @return
     * The companyAddress
     */
    public String getCompanyAddress() {
        return companyAddress;
    }

    /**
     *
     * @param companyAddress
     * The company_address
     */
    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    /**
     *
     * @return
     * The companyStreetNumber
     */
    public String getCompanyStreetNumber() {
        return companyStreetNumber;
    }

    /**
     *
     * @param companyStreetNumber
     * The company_street_number
     */
    public void setCompanyStreetNumber(String companyStreetNumber) {
        this.companyStreetNumber = companyStreetNumber;
    }

    /**
     *
     * @return
     * The companyRoute
     */
    public String getCompanyRoute() {
        return companyRoute;
    }

    /**
     *
     * @param companyRoute
     * The company_route
     */
    public void setCompanyRoute(String companyRoute) {
        this.companyRoute = companyRoute;
    }

    /**
     *
     * @return
     * The companyLocality
     */
    public String getCompanyLocality() {
        return companyLocality;
    }

    /**
     *
     * @param companyLocality
     * The company_locality
     */
    public void setCompanyLocality(String companyLocality) {
        this.companyLocality = companyLocality;
    }

    /**
     *
     * @return
     * The companyState
     */
    public String getCompanyState() {
        return companyState;
    }

    /**
     *
     * @param companyState
     * The company_state
     */
    public void setCompanyState(String companyState) {
        this.companyState = companyState;
    }

    /**
     *
     * @return
     * The companyPostelCode
     */
    public String getCompanyPostelCode() {
        return companyPostelCode;
    }

    /**
     *
     * @param companyPostelCode
     * The company_postel_code
     */
    public void setCompanyPostelCode(String companyPostelCode) {
        this.companyPostelCode = companyPostelCode;
    }

    /**
     *
     * @return
     * The companyCountry
     */
    public String getCompanyCountry() {
        return companyCountry;
    }

    /**
     *
     * @param companyCountry
     * The company_country
     */
    public void setCompanyCountry(String companyCountry) {
        this.companyCountry = companyCountry;
    }
}
