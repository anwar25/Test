package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by 449781 on 8/10/2016.
 */
public class FeesModel {


    @SerializedName("bv_fee")
    @Expose
    private String bvFee;
    @SerializedName("aarati_fee")
    @Expose
    private String aaratiFee;

    /**
     * @return The bvFee
     */
    public String getBvFee() {
        return bvFee;
    }

    /**
     * @param bvFee The bv_fee
     */
    public void setBvFee(String bvFee) {
        this.bvFee = bvFee;
    }

    /**
     * @return The aaratiFee
     */
    public String getAaratiFee() {
        return aaratiFee;
    }

    /**
     * @param aaratiFee The aarati_fee
     */
    public void setAaratiFee(String aaratiFee) {
        this.aaratiFee = aaratiFee;
    }

}
