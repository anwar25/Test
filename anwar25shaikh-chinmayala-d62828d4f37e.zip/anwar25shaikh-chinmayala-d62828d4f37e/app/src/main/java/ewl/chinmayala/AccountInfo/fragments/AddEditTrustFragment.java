package ewl.chinmayala.AccountInfo.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import ewl.chinmayala.AccountInfo.fragments.edit.models.TrustModel;
import ewl.chinmayala.AccountInfo.models.GenericResponseModel;
import ewl.chinmayala.AccountInfo.models.LoginData;
import ewl.chinmayala.AccountInfo.models.TrustRegModel;
import ewl.chinmayala.BaseFragment;
import ewl.chinmayala.HomeActivity;
import ewl.chinmayala.Network.RetrofitInstance;
import ewl.chinmayala.R;
import ewl.chinmayala.UI.CustomAppCompatButton;
import ewl.chinmayala.UI.CustomEditText;
import ewl.chinmayala.Utils.NetworkUtils;
import ewl.chinmayala.constants.Constants;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Anwar .
 */
public class AddEditTrustFragment extends BaseFragment implements View.OnClickListener {

    private EditText mNameEditText ;
    private EditText mPhoneEditText ;
    private EditText mAddressEditText ;
    private EditText mStreetAddEditText ;

    private EditText mCityEditText ;
    private EditText mStateEditText ;
    private EditText mZipEditText ;
    private EditText mCountryEditText ;

    private CustomAppCompatButton mSubmitButton ;
    private HomeActivity activityHandle;
    private String title;

    private TrustModel mTrustDetails = null;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_edit_trust_fragment_layout,container,false);
        mapControls(view);
        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mTrustDetails = null;
        mNameEditText  = null;
        mPhoneEditText  = null;
        mAddressEditText  = null;
        mStreetAddEditText  = null;

        mCityEditText  = null;
        mStateEditText  = null;
        mZipEditText  = null;
        mCountryEditText  = null;

        mSubmitButton  = null;

    }

    public void setTitle(String title) {
        this.title = title;
    }
    @Override
    public void mapControls(View rootView) {
     //   mNameEditText = (Edi)
        mNameEditText = (CustomEditText)rootView.findViewById(R.id.nameEditText);
        mPhoneEditText = (CustomEditText)rootView.findViewById(R.id.phoneEditText);
        mAddressEditText = (CustomEditText)rootView.findViewById(R.id.addressEditText);
        mStreetAddEditText = (CustomEditText)rootView.findViewById(R.id.streetAddressEditText);
        mCityEditText = (CustomEditText)rootView.findViewById(R.id.cityEditText);
        mStateEditText = (CustomEditText)rootView.findViewById(R.id.stateEditText);
        mZipEditText = (CustomEditText)rootView.findViewById(R.id.zipEditText);
        mCountryEditText = (CustomEditText)rootView.findViewById(R.id.countryEditText);
        mSubmitButton = (CustomAppCompatButton)rootView.findViewById(R.id.btnSubmit);
        mSubmitButton.setOnClickListener(this);

        activityHandle.setToolbarInitialization(this, getString(R.string.add_trust));
        if(getArguments() != null) {
            mTrustDetails = (TrustModel) getArguments().getSerializable(Constants.TRUST_DETAILS);
            if(mTrustDetails != null){
                mNameEditText.setText(mTrustDetails.getCompany());
                mPhoneEditText.setText(mTrustDetails.getCompanyPhone());
                mAddressEditText.setText(mTrustDetails.getCompanyAddress());
                mStreetAddEditText.setText(mTrustDetails.getStreetNumber());
                mCityEditText.setText(mTrustDetails.getLocality());
                mStateEditText.setText(mTrustDetails.getState());
                mZipEditText.setText(mTrustDetails.getPostalCode());
                mCountryEditText.setText(mTrustDetails.getCountry());
                activityHandle.setToolbarInitialization(this, getString(R.string.edit_trust));
                mSubmitButton.setText(getString(R.string.update));
            }
        }

    }

    @Override
    public boolean validate() {

        if(TextUtils.isEmpty(String.valueOf(mNameEditText.getText()))){
            mNameEditText.requestFocus();
            mNameEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
        if(TextUtils.isEmpty(String.valueOf(mPhoneEditText.getText()))){
            mPhoneEditText.requestFocus();
            mPhoneEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
        if(TextUtils.isEmpty(String.valueOf(mAddressEditText.getText()))){
            mAddressEditText.requestFocus();
            mAddressEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
       /* if(TextUtils.isEmpty(String.valueOf(mStreetAddEditText.getText()))){
            mStreetAddEditText.requestFocus();
            mStreetAddEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
        if(TextUtils.isEmpty(String.valueOf(mCityEditText.getText()))){
            mCityEditText.requestFocus();
            mCityEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
        if(TextUtils.isEmpty(String.valueOf(mStateEditText.getText()))){
            mStateEditText.requestFocus();
            mStateEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
        if(TextUtils.isEmpty(String.valueOf(mZipEditText.getText()))){
            mZipEditText.requestFocus();
            mZipEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }
        if(TextUtils.isEmpty(String.valueOf(mCountryEditText.getText()))){
            mCountryEditText.requestFocus();
            mCountryEditText.setError(getString(R.string.error_field_required));
            return  false ;
        }*/
        return true;
    }

    private TrustRegModel getModel() {
        Gson gson = new Gson();
        String member1DetailsString = activityHandle.getSessionManager().getString(Constants.REGISTER_MEMBER1_DETAILS);
        LoginData member1Details = gson.fromJson(member1DetailsString, LoginData.class);

        TrustRegModel trustRegModel = new TrustRegModel();
        trustRegModel.setFamilyId(member1Details.getFamilyId());
        trustRegModel.setCompanyName(String.valueOf(mNameEditText.getText()));
        trustRegModel.setCompanyPhone(String.valueOf(mPhoneEditText.getText()));
        trustRegModel.setCompanyAddress(String.valueOf(mAddressEditText.getText()));
        trustRegModel.setCompanyStreetNumber(String.valueOf(mStreetAddEditText.getText()));
        trustRegModel.setCompanyRoute("");
        trustRegModel.setCompanyLocality(String.valueOf(mCityEditText.getText()));
        trustRegModel.setCompanyState(String.valueOf(mStateEditText.getText()));
        trustRegModel.setCompanyPostelCode(String.valueOf(mZipEditText.getText()));
        trustRegModel.setCompanyCountry(String.valueOf(mCountryEditText.getText()));

        // for edit trust
        if(mTrustDetails != null){
            trustRegModel.setType(Constants.TRUST);
            trustRegModel.setTrustId(mTrustDetails.getTrustId());
        }
        //trustRegModel.set(String.valueOf(mCityEditText.getText()));

        return trustRegModel;
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSubmit :
                if(validate()){
                    if(mTrustDetails == null){
                        registerTrust();
                    }else{
                        editTrust();
                    }

                }
                break;
        }
    }

    private void editTrust() {
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.updating));

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().updateTrust(getModel());
        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel registerMemberResponse = response.body();
                if (registerMemberResponse != null && registerMemberResponse.getStatus() == 1) {
                    //(new TrustAdapter()).insert(getModel());
                    Toast.makeText(activityHandle,registerMemberResponse.getMsg(), Toast.LENGTH_LONG).show();
                    //   activityHandle.getSessionManager().putString(Constants.REGISTER_MEMBER, memberReg);
                    activityHandle.getSupportFragmentManager().popBackStack();
                    //store user response in session
                } else {
                    Toast.makeText(activityHandle,registerMemberResponse.getErrorMsg(), Toast.LENGTH_LONG).show();
                }
                activityHandle.hideProgress();
            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            activityHandle = (HomeActivity) context;
        }
    }
    private void registerTrust(){
        if (!NetworkUtils.isConnectedToInternet(activityHandle)) {
            activityHandle.showNetworkErrorToast();
            return;
        }
        activityHandle.showProgress(getString(R.string.register_msg));

        Call<GenericResponseModel> call = RetrofitInstance.getInstance().registerTrust(getModel());
        call.enqueue(new Callback<GenericResponseModel>() {
            @Override
            public void onResponse(Call<GenericResponseModel> call, Response<GenericResponseModel> response) {
                GenericResponseModel registerMemberResponse = response.body();
                if (registerMemberResponse != null && registerMemberResponse.getStatus() == 1) {
                    //(new TrustAdapter()).insert(getModel());
                    Toast.makeText(activityHandle,registerMemberResponse.getMsg(), Toast.LENGTH_LONG).show();
                 //   activityHandle.getSessionManager().putString(Constants.REGISTER_MEMBER, memberReg);
                    activityHandle.getSupportFragmentManager().popBackStack();
                    //store user response in session
                } else {
                    Toast.makeText(activityHandle,registerMemberResponse.getErrorMsg(), Toast.LENGTH_LONG).show();
                }
                activityHandle.hideProgress();
            }

            @Override
            public void onFailure(Call<GenericResponseModel> call, Throwable t) {
                Toast.makeText(activityHandle, getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                activityHandle.hideProgress();
            }
        });
    }


}
