package ewl.chinmayala.AccountInfo.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 7/24/2016.
 */

public class SessionData {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("center_id")
    @Expose
    private String centerId;
    @SerializedName("session_name")
    @Expose
    private String sessionName;
    @SerializedName("session_start")
    @Expose
    private String sessionStart;
    @SerializedName("session_end")
    @Expose
    private String sessionEnd;
    @SerializedName("is_active")
    @Expose
    private String isActive;

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The centerId
     */
    public String getCenterId() {
        return centerId;
    }

    /**
     *
     * @param centerId
     * The center_id
     */
    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    /**
     *
     * @return
     * The sessionName
     */
    public String getSessionName() {
        return sessionName;
    }

    /**
     *
     * @param sessionName
     * The session_name
     */
    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

    /**
     *
     * @return
     * The sessionStart
     */
    public String getSessionStart() {
        return sessionStart;
    }

    /**
     *
     * @param sessionStart
     * The session_start
     */
    public void setSessionStart(String sessionStart) {
        this.sessionStart = sessionStart;
    }

    /**
     *
     * @return
     * The sessionEnd
     */
    public String getSessionEnd() {
        return sessionEnd;
    }

    /**
     *
     * @param sessionEnd
     * The session_end
     */
    public void setSessionEnd(String sessionEnd) {
        this.sessionEnd = sessionEnd;
    }

    /**
     *
     * @return
     * The isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     *
     * @param isActive
     * The is_active
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

}