package com.bplusapp.imageLoader;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.media.ExifInterface;
import android.widget.ImageView;

import com.bplusapp.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class ImageLoaderNeww {
	private MemoryCache memoryCache;
	private FileCache fileCache;
//	private int REQUIRED_SIZE=100;
	private Map<ImageView, String> imageViews= Collections.synchronizedMap(new WeakHashMap<ImageView, String>());
	private ExecutorService executorService;
	private final int stub_id= R.drawable.ic_face_white_48dp;
	private static ImageLoaderNeww myImageLoader;
	private int REQUIRED_HEIGHT=100;
	private int REQUIRED_WIDTH=100;
	
	private ImageLoaderNeww(Context context){
		fileCache=new FileCache(context);
		executorService= Executors.newFixedThreadPool(5);
		memoryCache=new MemoryCache();
	}
	
	public static ImageLoaderNeww getMyImageLoaderInstance(Context con){
		if(myImageLoader==null)
			myImageLoader=new ImageLoaderNeww(con);
		return myImageLoader;
	}

	public void DisplayImage(String url, ImageView imageView,int requiredsize)
	{
		REQUIRED_HEIGHT=requiredsize;
		REQUIRED_WIDTH=requiredsize;
		/*if(url.startsWith("http")||(url.startsWith("https")))
		{
			//			Log.v("Url",url);
		}
		else if(url.contains("/mnt"))
		{
		}
		else if(url.contains("/storage"))
		{
		}
		else
		{
			url="http://"+url;
		}*/

		imageViews.put(imageView, url);
		Bitmap bitmap=memoryCache.get(url);

		if(bitmap!=null)
		{
			//			MyImageView.imageHeight=bitmap.getHeight();
			//			MyImageView.imageWidth=bitmap.getHeight();

            bitmap = bitmap.createScaledBitmap(bitmap,180,180,true);
			imageView.setImageBitmap(bitmap);
		}
		else
		{
			if(url != null && url.trim().length() > 0)
			queuePhoto(url, imageView);
			imageView.setImageResource(stub_id);                         
		}
	}


    public Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);

        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(
				bm, 0, 0, width, height, matrix, false);
        bm.recycle();
        return resizedBitmap;
    }


	public void DisplayImage(String url, ImageView imageView,int requiredHeight, int requiredWidth)
	{
		REQUIRED_HEIGHT=requiredHeight;
		REQUIRED_HEIGHT=requiredWidth;
		imageViews.put(imageView, url);
		Bitmap bitmap=memoryCache.get(url);

		if(bitmap!=null)
		{
			//			MyImageView.imageHeight=bitmap.getHeight();
			//			MyImageView.imageWidth=bitmap.getHeight();
			
			
			if(imageView.getId() == R.id.profile_img){
//				imageView.setImageBitmap(bitmap);
				imageView.setImageResource(android.R.color.transparent);
				imageView.setBackground(new BitmapDrawable(bitmap));
				
			}else {
				imageView.setImageBitmap(bitmap);
			}
			
		}
		else
		{  if(url != null && url.trim().length() > 0)
			queuePhoto(url, imageView);
			     
			if(imageView.getId() == R.id.profile_img){
				    
				imageView.setImageResource(android.R.color.transparent);
				imageView.setImageResource(stub_id);
//				imageView.setBackgroundResource(stub_id);
			}else {
				imageView.setImageResource(stub_id);    
			}
		}
	}

	private void queuePhoto(String url, ImageView imageView)
	{      	
		PhotoToLoad p=new PhotoToLoad(url, imageView);
		executorService.submit(new PhotosLoader(p));
	}    
	public Bitmap getBitmap(String url)
	{
		if(url==null){
			return null;
		}
		
		if(url.contains("http://") || url.contains("https://")){
			try 
			{
				Bitmap bitmap=null;
				URL imageUrl = new URL(url);
				File f=fileCache.getFile(url);
				HttpURLConnection conn = (HttpURLConnection)imageUrl.openConnection();
				conn.setConnectTimeout(30000);
				conn.setReadTimeout(30000);
				conn.setInstanceFollowRedirects(true);
				InputStream is=conn.getInputStream();
				OutputStream os = new FileOutputStream(f);
				Utils.CopyStream(is, os);
				os.close();
				bitmap = decodeFile(f);
			//	bitmap =  decodeSampledBitmapFromResource(f.getAbsolutePath(),REQUIRED_HEIGHT, REQUIRED_WIDTH);
				return bitmap;
			} catch (Exception ex){
				ex.printStackTrace();
				return null;
			}
		}else{
			Bitmap b = decodeFile(new File(url));
		//	Bitmap b = decodeSampledBitmapFromResource(url,REQUIRED_HEIGHT, REQUIRED_WIDTH);
	//		Bitmap  bitmap = myImageLoader.getBitmap(imagePath);
			Matrix matrix = getRotationMatrix(getOrientation(url));
			b = getRotatedBitmap(b, matrix);
			return b;			
		}
		//		}

		//		return null;
	}
	public Bitmap getBitmapWithoutScaling(String url, int height, int width)
	{
		if(url==null){
			return null;
		}
		
		if(url.contains("http://") || url.contains("https://")){
			try 
			{
				Bitmap bitmap=null;
				URL imageUrl = new URL(url);
				File f=fileCache.getFile(url);
				HttpURLConnection conn = (HttpURLConnection)imageUrl.openConnection();
				conn.setConnectTimeout(30000);
				conn.setReadTimeout(30000);
				conn.setInstanceFollowRedirects(true);
				InputStream is=conn.getInputStream();
				OutputStream os = new FileOutputStream(f);
				Utils.CopyStream(is, os);
				os.close();
	//			bitmap = decodeFile(f);
				bitmap =  decodeSampledBitmapFromResource(f.getAbsolutePath(),height, width);
				return bitmap;
			} catch (Exception ex){
				ex.printStackTrace();
				return null;
			}
		}else{
	//		Bitmap b = decodeFile(new File(url));
			Bitmap b = decodeSampledBitmapFromResource(url,height, height);
			return b;			
		}
		//		}

		//		return null;
	}
	
	public int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			// Calculate ratios of height and width to requested height and
			// width
			final int heightRatio = Math.round((float) height
					/ (float) reqHeight);
			final int widthRatio = Math.round((float) width / (float) reqWidth);

			// Choose the smallest ratio as inSampleSize value, this will
			// guarantee
			// a final image with both dimensions larger than or equal to the
			// requested height and width.
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
		}

		return inSampleSize;
	}

	public Bitmap decodeSampledBitmapFromResource(String fileName,int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(fileName, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,reqHeight);
        options.inDensity = 5;
        options.inTargetDensity =2;
		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeFile(fileName);
	}
	


	//decodes image and scales it to reduce memory consumption
	private Bitmap decodeFile(File f){
		try {
			//decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			o.inPurgeable=true;
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);
			int width_tmp=o.outWidth, height_tmp=o.outHeight;
			int scale=1;
			while(true)
			{
				if(width_tmp/2<REQUIRED_WIDTH || height_tmp/2<REQUIRED_HEIGHT)
					break;
				width_tmp/=2;
				height_tmp/=2;
				scale= scale*2;// //scale*2
			}      

//			 System.gc();
			//decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize=scale;
			o2.inPurgeable=true;
		
			return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		} 
		catch(OutOfMemoryError error){
			 System.gc();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	//Task for the queue
	private class PhotoToLoad
	{
		public String url;
		public ImageView imageView;
		public PhotoToLoad(String u, ImageView i){
			url=u; 
			imageView=i;
		}
	}

	private class PhotosLoader implements Runnable
	{
		PhotoToLoad photoToLoad;
		PhotosLoader(PhotoToLoad photoToLoad)
		{
			this.photoToLoad=photoToLoad;
		}        
		public void run() 
		{
			if(imageViewReused(photoToLoad))
				return;
			Bitmap bmp=getBitmap(photoToLoad.url);
            bmp = bmp.createScaledBitmap(bmp,180,180,true);
			memoryCache.put(photoToLoad.url, bmp);
			if(imageViewReused(photoToLoad))
				return;
			BitmapDisplayer bd=new BitmapDisplayer(bmp, photoToLoad);
			Activity a=(Activity)photoToLoad.imageView.getContext();
			a.runOnUiThread(bd);
		}
	}

	private boolean imageViewReused(PhotoToLoad photoToLoad){
		String tag=imageViews.get(photoToLoad.imageView);
		if(tag==null || !tag.equals(photoToLoad.url))
			return true;
		return false;
	}

	//Used to display bitmap in the UI thread
	private class BitmapDisplayer implements Runnable
	{
		Bitmap bitmap;
		PhotoToLoad photoToLoad;
		public BitmapDisplayer(Bitmap b, PhotoToLoad p){bitmap=b;photoToLoad=p;}
		public void run()
		{
			if(imageViewReused(photoToLoad))
				return;
			if(bitmap!=null)
			{   
				//				MyImageView.imageHeight=bitmap.getHeight();
				//				MyImageView.imageWidth=bitmap.getWidth();
				photoToLoad.imageView.setImageBitmap(bitmap);
			}    
			else            	
			{
				//				photoToLoad.imageView.setImageResource(stub_id);
			}   
		}
	}

	public void clearCache(){
		memoryCache.clear();
		fileCache.clear();
	}
	
	/**
	 * This method is used to get the rotaion matrix
	 * @param  orientation
	 * @return Matrix
	 */
	private Matrix getRotationMatrix(int orientation)
	{
		Matrix mat = new Matrix();
		if(orientation==1)
		{
			mat.postRotate(0);
		}
		else if(orientation==6)
		{
			mat.postRotate(90);
		}
		else if(orientation==8)
		{
			mat.postRotate(270);
		}
		else if(orientation==3)
		{
			mat.postRotate(180); 
		}

		return mat;
	}


	private Bitmap getRotatedBitmap (Bitmap bitmap,Matrix matrix)
	{
		Bitmap bm = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
		//		matrix = null;
		//		bitmap.recycle();
		//		bitmap = null;
		//		System.gc();
		return bm;
	}


	/**
	 * This method is used to get the orientation of captured image
	 * @param
	 * @return int
	 */
	private int getOrientation(String path)
	{
		int orientation=0;
		try
		{
			ExifInterface exif = new ExifInterface(path);
			String exifOrientation = exif.getAttribute(ExifInterface.TAG_ORIENTATION);
			orientation= Integer.parseInt(exifOrientation);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return orientation;
	}
	public Bitmap setHomeBackground(String url,int requiredHeight, int requiredWidth)
	{
		Bitmap bitmap=memoryCache.get(url);

		if(bitmap!=null)
		{
		   return bitmap;
		}
		else
		{  
			bitmap= getBitmapWithoutScaling(url, requiredHeight, requiredHeight);
			memoryCache.put(url,bitmap);
			return bitmap;           
		}
	}

}
