package com.bplusapp.Interface;

import com.bplusapp.Entity.Feed;

/**
 * Created by Anwar on 10/5/2016.
 */
public interface IFeedItemListener {

    void feedItemClicked(Feed feed ,String fragmentName);
}
