package com.bplusapp.imageLoader;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

import com.bplusapp.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class MyImageLoader
{
	private MemoryCache memoryCache=new MemoryCache();
	private FileCache fileCache;
	private int REQUIRED_SIZE=200;
	//  private int Image_Width,Image_Height;
	private Map<ImageView, String> imageViews= Collections.synchronizedMap(new WeakHashMap<ImageView, String>());
	private ExecutorService executorService;
	private final int stub_id= R.drawable.logo;
	private String isVideo="";
	private Bitmap videoBitmap;
	private Matrix matrix;
	private Context context;
	public MyImageLoader(Context context)
	{
		this.context = context;
		fileCache=new FileCache(context);
		executorService= Executors.newFixedThreadPool(5);
	}

	public void DisplayImage(String url, ImageView imageView,int requiredsize,String from)
	{
		int orientation = getOrientation(url);
		Log.e("image url and orientation" + url, "" + orientation);
		matrix = getRotationMatrix(orientation);
		REQUIRED_SIZE=requiredsize;
		/*if(url.startsWith("http")||(url.startsWith("https")))
		{
			//			Log.v("Url",url);
		}
		else if(url.contains("/mnt"))
		{
		}
		else if(url.contains("/storage"))
		{
		}
		else
		{
			url="http://"+url;
		}*/

		imageViews.put(imageView, url);
		Bitmap bitmap=memoryCache.get(url);

		if(bitmap!=null)
		{
			imageView.setImageBitmap(bitmap);
		}
		else
		{  
			queuePhoto(url, imageView);
			imageView.setImageResource(stub_id);                         
		}
	}

	public void DisplayVideoThumbnail(String url, ImageView imageView,int requiredsize,String from, Bitmap imgbitmap,String isVideo)
	{
		REQUIRED_SIZE=requiredsize;
		this.isVideo=isVideo;
		/*if(url.startsWith("http")||(url.startsWith("https")))
		{
			//			Log.v("Url",url);
		}
		else if(url.contains("/mnt"))
		{
		}
		else if(url.contains("/storage"))
		{
		}
		else
		{
			url="http://"+url;
		}*/

		imageViews.put(imageView, url);
		Bitmap bitmap=memoryCache.get(url);
		videoBitmap=imgbitmap;
		if(bitmap!=null)
		{
			//			MyImageView.imageHeight=bitmap.getHeight();
			//			MyImageView.imageWidth=bitmap.getHeight();
			imageView.setImageBitmap(bitmap);
		}
		else
		{  
			queuePhoto(url, imageView);
			imageView.setImageResource(stub_id);                         
		}
	}

	private void queuePhoto(String url, ImageView imageView)
	{      	
		PhotoToLoad p=new PhotoToLoad(url, imageView);
		executorService.submit(new PhotosLoader(p));
	}    
	private Bitmap getBitmap(String url)
	{
		if(url==null)
		{
			return null;
		}
		//		if(FROM.equalsIgnoreCase("userselectedphoto"))
		//		{
		//			Bitmap bm=null;
		//			Options options = new Options();
		//			options.inJustDecodeBounds = true;
		//			BitmapFactory.decodeFile(filepath, options);
		//			int REQUIRED_SIZE=this.REQUIRED_SIZE;
		//			int width_tmp=options.outWidth, height_tmp=options.outHeight;
		//			int scale=1;
		//			while(true){if(width_tmp<REQUIRED_SIZE || height_tmp<REQUIRED_SIZE)
		//					break;
		//				width_tmp/=2;
		//				height_tmp/=2;
		//				scale++;
		//			}
		//			options.inSampleSize = scale;
		//			// Do the actual decoding
		//			options.inJustDecodeBounds = false;
		//			options.inTempStorage = new byte[16*1024];
		//			int orientation = 0;
		//			try{
		//				ExifInterface exif = new ExifInterface(filepath); 
		//				String exifOrientation = exif.getAttribute(ExifInterface.TAG_ORIENTATION);
		//				orientation = Integer.valueOf(exifOrientation);
		//			}catch (Exception e) {
		//			}
		//
		//			bm = BitmapFactory.decodeFile(filepath,options);
		//
		//			Matrix mat = new Matrix();
		//			Log.v("","Orientation: "+orientation);
		//			if (orientation == 0) 
		//			{
		////				mat.postRotate(-90);
		//				Log.v("","if 0 ");
		//			}
		//			else if (orientation == 1) 
		//			{
		//				mat.postRotate(0);
		//				Log.v("","if 1 ");
		//			}
		//			else if (orientation == 6) 
		//			{
		//				mat.postRotate(90);
		//				Log.v("","if 6 ");
		//			}
		//			else if (orientation == 8) 
		//			{
		//				mat.postRotate(270);
		//				Log.v("","if 8 ");
		//			}
		//			else if (orientation == 3) 
		//			{
		//				mat.postRotate(180);
		//				Log.v("","if 3 ");
		//			}
		//			
		//			if(bm!=null)
		//			{
		//			bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mat, true);			
		//			FileOutputStream _fos;
		//			try {
		//				_fos = new FileOutputStream(filepath);
		//				bm.compress(Bitmap.CompressFormat.JPEG, 100, _fos);
		//		        _fos.flush();
		//		        _fos.close();
		//			} catch (FileNotFoundException e) {
		//				e.printStackTrace();
		//			} catch (IOException e) {
		//				e.printStackTrace();
		//			}
		//			Log.w("bm width",bm.getWidth()+","+bm.getHeight());
		//			return bm;
		//			}			
		//		}else{

		if(url.contains("http://") || url.contains("https://"))
		{
			try 
			{
				Bitmap bitmap=null;
				URL imageUrl = new URL(url);
				File f=fileCache.getFile(url);
				HttpURLConnection conn = (HttpURLConnection)imageUrl.openConnection();
				conn.setConnectTimeout(30000);
				conn.setReadTimeout(30000);
				conn.setInstanceFollowRedirects(true);
				InputStream is=conn.getInputStream();
				OutputStream os = new FileOutputStream(f);
				Utils.CopyStream(is, os);
				os.close();
				bitmap = decodeFile(f);
				return bitmap;
			} 
			catch (Exception ex)
			{
				ex.printStackTrace();
				return null;
			}
		}
		else
		{
			Bitmap b = null;
			if(isVideo.equalsIgnoreCase("video"))
			{
				b= videoBitmap;
			}
			else
				b = decodeFile(new File(url));
			return b;			
		}
		//		}

		//		return null;
	}

	//decodes image and scales it to reduce memory consumption
	private Bitmap decodeFile(File f)
	{
		//		Options options = new Options();
		//		  options.inJustDecodeBounds = true;
		//		  BitmapFactory.decodeFile(f.getAbsolutePath(), options);
		//		  options.inSampleSize=Math.min(options.outWidth/50, options.outHeight/50);
		//
		//		  options.inJustDecodeBounds = false;
		//		  options.inTempStorage = new byte[16*1024];
		//		  Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath(),options);

		//			  Matrix mat = new Matrix();
		//			  if(orientation==1){
		//			   mat.postRotate(0);
		//			  }else if(orientation==6){
		//			   mat.postRotate(90);
		//			  }else if(orientation==8){
		//			   mat.postRotate(270);
		//			  }else if(orientation==3){
		//			   mat.postRotate(180); 
		//			  }
		//		  ByteArrayOutputStream baos = new ByteArrayOutputStream();
		//		  return Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), matrix, true);
		//decode image size
		BitmapFactory.Options o = new BitmapFactory.Options();
		o.inJustDecodeBounds = true;
		o.inPurgeable=true;
		try {
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);

			int width_tmp=o.outWidth, height_tmp=o.outHeight;
			int scale=1;
			while(true)
			{
				if(width_tmp/2<REQUIRED_SIZE || height_tmp/2<REQUIRED_SIZE)
					break;
				width_tmp/=2;
				height_tmp/=2;
				scale=scale*2; //scale++
			}      

			//decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize=scale;
			o2.inPurgeable=true;
			//			if (matrix == null)
			//			{
			return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}  
		return null;
		//			}
		//			else
		//			{
		//				return getRotatedBitmap(BitmapFactory.decodeStream(new FileInputStream(f), null, o2));
		//			}
	}

	//	private Bitmap getRotatedBitmap (Bitmap bitmap)
	//	{
	//		Bitmap bm = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
	//		//		matrix = null;
	//		//		bitmap.recycle();
	//		//		bitmap = null;
	//		//		System.gc();
	//		return bm;
	//	}

	//Task for the queue
	private class PhotoToLoad
	{
		public String url;
		public ImageView imageView;
		public PhotoToLoad(String u, ImageView i){
			url=u; 
			imageView=i;
		}
	}

	private class PhotosLoader implements Runnable
	{
		PhotoToLoad photoToLoad;
		PhotosLoader(PhotoToLoad photoToLoad)
		{
			this.photoToLoad=photoToLoad;
		}        
		public void run() 
		{
			if(imageViewReused(photoToLoad))
				return;
			Bitmap bmp = getBitmap(photoToLoad.url);
//			try {
//				bmp = getCorrectlyOrientedImage(context, photoToLoad.url);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			//		
			memoryCache.put(photoToLoad.url, bmp);
			if(imageViewReused(photoToLoad))
				return;
			BitmapDisplayer bd=new BitmapDisplayer(bmp, photoToLoad);
			Activity a=(Activity)photoToLoad.imageView.getContext();
			a.runOnUiThread(bd);
		}
	}

	private boolean imageViewReused(PhotoToLoad photoToLoad){
		String tag=imageViews.get(photoToLoad.imageView);
		if(tag==null || !tag.equals(photoToLoad.url))
			return true;
		return false;
	}

	//Used to display bitmap in the UI thread
	private class BitmapDisplayer implements Runnable
	{
		Bitmap bitmap;
		PhotoToLoad photoToLoad;
		public BitmapDisplayer(Bitmap b, PhotoToLoad p){bitmap=b;photoToLoad=p;}
		public void run()
		{
			if(imageViewReused(photoToLoad))
				return;
			if(bitmap!=null)
			{   
				//				MyImageView.imageHeight=bitmap.getHeight();
				//				MyImageView.imageWidth=bitmap.getWidth();
				//				setImageCrop(photoToLoad.url, photoToLoad.imageView);

				//				Log.e("position & url and image", +memoryCache.getphotoToLoad.url)
				photoToLoad.imageView.setImageBitmap(bitmap);
				photoToLoad.imageView.setScaleType(ScaleType.FIT_XY);
			}    
			else            	
			{
				//				photoToLoad.imageView.setImageResource(stub_id);
			}   
		}
	}

	public void clearCache() 
	{
		memoryCache.clear();
		fileCache.clear();
	}


	/**
	 * This method is used to get the orientation of captured image
	 * @param
	 * @return int
	 */
	private int getOrientation(String path)
	{
		int orientation=0;
		try
		{
			ExifInterface exif = new ExifInterface(path);
			String exifOrientation = exif.getAttribute(ExifInterface.TAG_ORIENTATION);
			orientation= Integer.parseInt(exifOrientation);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return orientation;
	}

	/**
	 * This method is used to get the rotation matrix
	 * @param  orientation
	 * @return Matrix
	 */
	private Matrix getRotationMatrix(int orientation)
	{
		Matrix mat = new Matrix();
		if(orientation==1)
		{
			mat.postRotate(0);
		}
		else if(orientation==6)
		{
			mat.postRotate(90);
		}
		else if(orientation==8)
		{
			mat.postRotate(270);
		}
		else if(orientation==3)
		{
			mat.postRotate(180); 
		}
		return mat;
	}


	public Bitmap getCorrectlyOrientedImage(Context context, String photoUri) throws IOException {
	    InputStream is = context.getContentResolver().openInputStream(Uri.fromFile(new File(photoUri)));
	    BitmapFactory.Options dbo = new BitmapFactory.Options();
	    dbo.inJustDecodeBounds = true;
	    BitmapFactory.decodeStream(is, null, dbo);
	    is.close();

	    int rotatedWidth, rotatedHeight;
	    int orientation = getOrientation(photoUri);

	    if (orientation == 90 || orientation == 270) {
	        rotatedWidth = dbo.outHeight;
	        rotatedHeight = dbo.outWidth;
	    } else {
	        rotatedWidth = dbo.outWidth;
	        rotatedHeight = dbo.outHeight;
	    }

	    Bitmap srcBitmap;
	    is = context.getContentResolver().openInputStream(Uri.fromFile(new File(photoUri)));
	    if (rotatedWidth > REQUIRED_SIZE || rotatedHeight > REQUIRED_SIZE) {
	        float widthRatio = ((float) rotatedWidth) / ((float) REQUIRED_SIZE);
	        float heightRatio = ((float) rotatedHeight) / ((float) REQUIRED_SIZE);
	        float maxRatio = Math.max(widthRatio, heightRatio);

	        // Create the bitmap from file
	        BitmapFactory.Options options = new BitmapFactory.Options();
	        options.inSampleSize = (int) maxRatio;
	        srcBitmap = BitmapFactory.decodeStream(is, null, options);
	    } else {
	        srcBitmap = BitmapFactory.decodeStream(is);
	    }
	    is.close();


/*	 * if the orientation is not 0 (or -1, which means we don't know), we
	 * have to do a rotation.
*/
	    if (orientation > 0) {
	        Matrix matrix = new Matrix();
	        matrix.postRotate(orientation);

	        srcBitmap = Bitmap.createBitmap(srcBitmap, 0, 0, srcBitmap.getWidth(),
					srcBitmap.getHeight(), matrix, true);
	    }

	    return srcBitmap;
	}

	/**
	 * method for croping the image bitmap and setting image to imageview
	 * @param path
	 * @param imageView
	 */

	//	private void setImageCrop(final String path,ImageView imageView)
	//	{
	//		final Options options = new Options();
	//		options.inJustDecodeBounds = true;
	//		BitmapFactory.decodeFile(path, options);
	//		final int sample = Math.min(options.outWidth / 720, options.outHeight / 960);
	//		options.inSampleSize = sample;
	//		options.inJustDecodeBounds = false;
	//		options.inTempStorage = new byte[16 * 1024];
	//		Bitmap bm = BitmapFactory.decodeFile(path, options);
	//		int orientation = 0;
	//		try {
	//			final ExifInterface exif = new ExifInterface(path);
	//			final String exifOrientation = exif.getAttribute(ExifInterface.TAG_ORIENTATION);
	//			orientation = Integer.valueOf(exifOrientation);
	//		} catch (final Exception e) {
	//			e.printStackTrace();
	//		}
	//		final Matrix mat = new Matrix();
	//		if (orientation == 1) {
	//			mat.postRotate(0);
	//		} else if (orientation == 6) {
	//			mat.postRotate(90);
	//		} else if (orientation == 8) {
	//			mat.postRotate(270);
	//		} else if (orientation == 3) {
	//			mat.postRotate(180);
	//		}
	//
	//		//		Bitmap bmp = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mat, true);
	////		bm.recycle();
	//		//		savebitmap(bmp, path);
	//		final int sample1 = Math.min(options.outWidth /100, options.outHeight /100);
	//		options.inSampleSize = sample1;
	//		options.inJustDecodeBounds = false;
	//		options.inTempStorage = new byte[16 * 1024];
	//		Bitmap bitmap = BitmapFactory.decodeFile(path, options);
	//
	//		imageView.setImageBitmap(bitmap);
	//	}

}
