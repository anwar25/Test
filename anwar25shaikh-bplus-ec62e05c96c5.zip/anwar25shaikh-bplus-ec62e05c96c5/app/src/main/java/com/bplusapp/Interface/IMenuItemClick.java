package com.bplusapp.Interface;

/**
 * Created by Akash.Singh on 1/20/2016.
 */
public interface IMenuItemClick {
    void onMenuClick();
}
