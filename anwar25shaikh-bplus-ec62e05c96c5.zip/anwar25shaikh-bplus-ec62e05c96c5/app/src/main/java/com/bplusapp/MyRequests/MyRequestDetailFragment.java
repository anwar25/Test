package com.bplusapp.MyRequests;

import android.content.DialogInterface;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.bplusapp.Adapter.RecieverInfoAdapter;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.MyRequestDescriptionDataClass;
import com.bplusapp.Entity.ReceiverInfo;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.Utils.Logger;
import com.bplusapp.Utils.Utils;
import com.bplusapp.dialog.RequestConfirmationsDialog;
import com.bplusapp.map.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Akash.Singh on 1/20/2016.
 */
public class MyRequestDetailFragment extends Fragment implements IAsyncTaskRunner, IDialogClick {
    private CustomTextView text_blood_group, text_hospital_name, requester_name, requester_date_time, requester_phone, text_hospitalAddress, text_no_of_confirmation;
    //  private ImageView img_map;
    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;
    private List<MyRequestDescriptionDataClass> myRequestDescriptionDataClasses;
    //   private ListView list_recievers ;
    private RecieverInfoAdapter recieverInfoAdapter;
    private Button btn_view_confirmations;
    private AppCompatButton btn_close_request;
    private MapFragment mMapFragment;

    public MyRequestDetailFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        performRequestDetailProcess();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_my_request_detail_screen, container, false);
        WidgetMapping(view);
        return view;
    }

    private void performRequestDetailProcess() {
        loadingDialog = new CustomLoadingDialog(getActivity());
        authCommonTask = new AuthCommonTask(getActivity(), BaseNetwork.VIEW_MY_REQUEST_DETAIL, this, loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        String id = getArguments().getString("requestId");
        hashMap.put("requestId", id);
        authCommonTask.execute(hashMap);
    }


    public void performCloseRequestProcess() {
        loadingDialog = new CustomLoadingDialog(getActivity());
        authCommonTask = new AuthCommonTask(getActivity(), BaseNetwork.CLOSE_REQUEST, this, loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("requestId", getArguments().getString("requestId"));
        authCommonTask.execute(hashMap);
    }

    public void sendDonorDetails(Object item) {
        // loadingDialog =  new CustomLoadingDialog(getActivity());
        authCommonTask =  new AuthCommonTask(getActivity(), BaseNetwork.CONFIRM_DONOR,this,loadingDialog);
        String userId = ((ReceiverInfo)item).getUser_id();
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("requestId", getArguments().getString("requestId"));
        hashMap.put(StaticConstant.USER_ID, userId);
        //  mViewHolder.tv_reciever.setText(myRequestDescriptionDataClasses.get(0).getmReceiverInfos().get(position).getUser_name());
        authCommonTask.execute(hashMap);

    }

    private void WidgetMapping(View view) {
        FragmentManager fm = getChildFragmentManager();
        mMapFragment = (MapFragment) fm.findFragmentById(R.id.map);
        if (mMapFragment == null) {
            mMapFragment = (MapFragment) SupportMapFragment.newInstance();
            fm.beginTransaction().replace(R.id.map, mMapFragment).commit();
        }

        text_blood_group = (CustomTextView) view.findViewById(R.id.text_blood_group);
        text_hospital_name = (CustomTextView) view.findViewById(R.id.text_hospital_name);
        requester_name = (CustomTextView) view.findViewById(R.id.requester_name);
        requester_date_time = (CustomTextView) view.findViewById(R.id.requester_date_time);
        requester_phone = (CustomTextView) view.findViewById(R.id.requester_phone);
        text_hospitalAddress = (CustomTextView) view.findViewById(R.id.text_hospitalAddress);
        // text_no_of_confirmation = (CustomTextView) view.findViewById(R.id.text_no_of_confirmation);
        // img_map = (ImageView) view.findViewById(R.id.img_map);

        btn_view_confirmations = (Button) view.findViewById(R.id.btn_view_confirmations);

        btn_close_request = (AppCompatButton) view.findViewById(R.id.btn_close_request);

        btn_close_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //showCloseRequestDialog();
                if (myRequestDescriptionDataClasses != null && myRequestDescriptionDataClasses.size() > 0) {
                    String requstedDate = myRequestDescriptionDataClasses.get(0).getRequestedDate();
                    try {
                        Date requestDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(requstedDate);
                        Date currentDate = new Date();
                        if (requestDate.before(currentDate)) {

                            ArrayList<ReceiverInfo> receiversList = myRequestDescriptionDataClasses.get(0).getmReceiverInfos() ;
                            if(receiversList != null && receiversList.size() > 0){
                                showExpiredCloseRequestDialog();
                            }else{
                                showCloseRequestDialog();
                            }
                            // Toast.makeText(getContext(),"Request is expired", Toast.LENGTH_SHORT).show();
                        } else {
                            showCloseRequestDialog();
                        }
                    } catch (ParseException e) {
                        Toast.makeText(getContext(), "Date format should be yyyy-MM-dd HH:mm:ss", Toast.LENGTH_SHORT).show();
                        Logger.e("Error", e.getMessage() + "");
                    }
                }
            }
        });

        btn_view_confirmations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new RequestConfirmationsDialog(getActivity(), myRequestDescriptionDataClasses).show();


            }
        });

        //list_recievers = (ListView) view.findViewById(R.id.list_recievers);
    }


    private AlertDialog mAlertDialog;

    private void showCloseRequestDialog() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());

        // setup a dialog window
        alertDialogBuilder
                .setTitle(getString(R.string.close_title))
                .setMessage(getString(R.string.close_req_msg))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), null)
                .setNegativeButton(getString(R.string.no),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an mAlertDialog dialog
        mAlertDialog = alertDialogBuilder.create();
        mAlertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(final DialogInterface dialog) {
                Button b = mAlertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // TODO Do something
                        dialog.dismiss();
                        performCloseRequestProcess();
                    }
                });
            }
        });
        mAlertDialog.show();
    }

    private void showExpiredCloseRequestDialog() {

        // get prompts.xml view
        final LinearLayout promptView = (LinearLayout) getActivity().getLayoutInflater()
                .inflate(R.layout.donor_list_layout, null);
        final ListView donorList = (ListView) promptView.findViewById(R.id.donorList);
        //true parameter is for showing radio button for selection
        recieverInfoAdapter = new RecieverInfoAdapter(getContext(), myRequestDescriptionDataClasses, true);
        donorList.setAdapter(recieverInfoAdapter);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        alertDialogBuilder.setView(promptView);

        // setup a dialog window
        alertDialogBuilder
                .setTitle(getString(R.string.close_title))
                .setMessage(getString(R.string.select_donor))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), null)
                .setNegativeButton(getString(R.string.no),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an mAlertDialog dialog
        mAlertDialog = alertDialogBuilder.create();
        mAlertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(final DialogInterface dialog) {
                Button b = mAlertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // TODO Do something
                        if (donorList.getCheckedItemPosition() != -1) {
                            dialog.dismiss();
                            performCloseRequestProcess();
                            sendDonorDetails(recieverInfoAdapter.getItem(donorList.getCheckedItemPosition()));
                        } else {
                            Toast.makeText(getContext(), getString(R.string.please_select_donor), Toast.LENGTH_SHORT).show();
                        }
                        //performCloseRequestProcess();
                    }
                });
            }
        });
        mAlertDialog.show();
    }

    private void SetRequestDetailValue(List<MyRequestDescriptionDataClass> feed) {
        try {
            text_blood_group.setBackground(getActivity().getResources().getDrawable(Utils.UseBloodGroupCode(feed.get(0).getBloodGroup())));
        } catch (Exception e) {

        }

        text_blood_group.setText(feed.get(0).getBloodGroup());
        requester_name.setText(feed.get(0).getRequesterName());
        text_hospital_name.setText("Urgent Requirement at " + feed.get(0).getHospitalName());
        // requester_date_time.setText(Utils.ConvertDateFormat(feed.get(0).getDate()));
        requester_date_time.setText(feed.get(0).getRequestedDate());
        text_hospitalAddress.setText(feed.get(0).getHospitalAddr());
        requester_phone.setText(feed.get(0).getPhone());
        //text_no_of_confirmation.setText(feed.get(0).getNumberOfConfirmation());

        //ImageLoaderRect imageLoader =  new ImageLoaderRect(getActivity());
        //String URL = "https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=600x250&" +
        //        "sensor=false&maptype=roadmap&markers=color:0xff6600%7C"+Double.parseDouble(feed.get(0).getLattitude()) +","+Double.parseDouble(feed.get(0).getLongitude()) + "&key=" + getString(R.string.google_maps_key);
        //imageLoader.DisplayImage(URL, img_map);


        recieverInfoAdapter = new RecieverInfoAdapter(getActivity(), myRequestDescriptionDataClasses, false);
        //list_recievers.setAdapter(recieverInfoAdapter);

        ((BaseActivityScreen) getActivity()).SetToolbarInitialization(this, "My Request | " + feed.get(0).getBloodGroup());
        Location location = new Location("");
        location.setLatitude(Double.parseDouble(feed.get(0).getLattitude()));
        location.setLongitude(Double.parseDouble(feed.get(0).getLongitude()));
        mMapFragment.setmCurrentLocation(location);
    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }

    @Override
    public void taskCompleted(Object obj) {
        if (obj != null) {
            ResultMessage resultMessage = (ResultMessage) obj;
            if (resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.VIEW_MY_REQUEST_DETAIL)) {
                myRequestDescriptionDataClasses = (ArrayList<MyRequestDescriptionDataClass>) resultMessage.RESULT_OBJECT;
                if (myRequestDescriptionDataClasses != null && myRequestDescriptionDataClasses.size() > 0)
                    SetRequestDetailValue(myRequestDescriptionDataClasses);
            } else if (resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.CLOSE_REQUEST)) {

                UserInfo userInfo = (UserInfo) resultMessage.RESULT_OBJECT;
                Toast.makeText(getActivity(), userInfo.getMessage(), Toast.LENGTH_SHORT).show();

                if (userInfo.getMessage().equalsIgnoreCase(getString(R.string.request_closed))) {
                    getActivity().getSupportFragmentManager().popBackStack();
                }
            }
        }
    }

    @Override
    public void taskErrorMessage(Object obj) {

        if (loadingDialog != null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if (resultMessage != null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }
}
