package com.bplusapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.StaticData.DbConstraints;
import com.bplusapp.Utils.Logger;

import java.util.ArrayList;


/**
 * Created by Akash.Singh on 7/30/2015.
 */
public class BPlusSavedDBData extends DbConstraints {


    private static final String TAG = BPlusSavedDBData.class.getSimpleName();
    DatabaseManager databaseManager;
    SQLiteDatabase database;


    public BPlusSavedDBData(Context context) {
        databaseManager = new DatabaseManager(context);

    }

    public void closeDB() {
        database.close();
    }


    public void openDB() {
        database = databaseManager.getReadableDatabase();
    }

    public void InsertUserInfoID(UserInfo userInfo){
        openDB();
        database.beginTransaction();
        try {
            ContentValues contentvalues = new ContentValues();
            contentvalues.put(UR_USER_ID, userInfo.getUserId());
            contentvalues.put(UR_USER_EMAIL,userInfo.getUserEmail());
            contentvalues.put(UR_USER_F_NAME,userInfo.getUserFName());
            contentvalues.put(UR_USER_MOBILE,userInfo.getUserMobile());
            contentvalues.put(UR_USER_L_NAME, userInfo.getUserLName());
            contentvalues.put(UR_USER_ADDRESS, userInfo.getUserAddress());
            contentvalues.put(UR_USER_BLOOD_GROUP, userInfo.getUserBloodGroup());
            contentvalues.put(UR_USER_COUNTRY, userInfo.getUserCountry());
            contentvalues.put(UR_USER_STATE, userInfo.getUserState());
            contentvalues.put(UR_USER_CITY, userInfo.getUserCity());
            contentvalues.put(UR_USER_ZIP_CODE, userInfo.getUserZipCode());
            contentvalues.put(UR_USER_PROFILE_PIC, userInfo.getProfilePic());
            contentvalues.put(UR_USER_AUTH_BY, userInfo.getAuthBy());

            contentvalues.put(UR_USER_FILTER_DISTANCE, userInfo.getFilterDistance());
            contentvalues.put(UR_USER_FILTER_BG, userInfo.getFilterBloodGroup());


            String Query = "Select * From "+USER_RECORD_TABLE_NAME+" Where "+UR_USER_ID+"="+"'"+userInfo.getUserId()+"'";
            Cursor cursor = database.rawQuery(Query, null);
            if (cursor != null && cursor.moveToFirst())
                database.update(USER_RECORD_TABLE_NAME, contentvalues, UR_USER_ID + "='" + userInfo.getUserId()+"'", null);
            else
                database.insert(USER_RECORD_TABLE_NAME, null, contentvalues);
            database.setTransactionSuccessful();
        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
            // closeDB();
        }
    }

    public void InsertFeedsID(Feed feed){
        openDB();
        database.beginTransaction();
        try {
            ContentValues contentvalues = new ContentValues();
            contentvalues.put(FED_ID, feed.getId());
            contentvalues.put(FED_P_NAME,feed.getpName());
            contentvalues.put(FED_USER_ID,feed.getUserId());
            contentvalues.put(FED_BLOOD_GROUP,feed.getBloodGroup());
            contentvalues.put(FED_REQUEST_DATE, feed.getRequestedDate());
            contentvalues.put(FED_HOSPITAL_NAME, feed.getHospitalName());
            contentvalues.put(FED_HOSPITAL_ADDRESS, feed.getHospitalAddr());
            contentvalues.put(FED_HOSPITAL_COUNTRY, feed.getCountry());
            contentvalues.put(FED_HOSPITAL_STATE, feed.getState());
            contentvalues.put(FED_HOSPITAL_CITY, feed.getCity());
            contentvalues.put(FED_HOSPITAL_ZIP_CODE, feed.getZipCode());
            contentvalues.put(FED_HOSPITAL_DESCRIPTION, feed.getDescription());
            contentvalues.put(FED_HOSPITAL_PHONE, feed.getPhone());
            contentvalues.put(FED_HOSPITAL_LATTITUDE, feed.getLattitude());
            contentvalues.put(FED_HOSPITAL_LONGITUDE, feed.getLongitude());
            contentvalues.put(FED_HOSPITAL_DISTANCE, feed.getDistance());

            String Query = "Select * From "+FEEDS_TABLE_NAME+" Where "+FED_ID+"="+"'"+feed.getId()+"'";
            Cursor cursor = database.rawQuery(Query, null);
            if (cursor != null && cursor.moveToFirst())
                database.update(FEEDS_TABLE_NAME, contentvalues, FED_ID + "='" + feed.getId()+"'", null);
            else
                database.insert(FEEDS_TABLE_NAME, null, contentvalues);
            database.setTransactionSuccessful();
        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
            // closeDB();
        }
    }


    public void InsertAcceptRequestFeedsID(Feed feed){
        openDB();
        database.beginTransaction();
        try {
            ContentValues contentvalues = new ContentValues();
            contentvalues.put(FED_ID, feed.getId());
            contentvalues.put(FED_P_NAME,feed.getpName());
            contentvalues.put(FED_USER_ID,feed.getUserId());
            contentvalues.put(FED_BLOOD_GROUP,feed.getBloodGroup());
            contentvalues.put(FED_REQUEST_DATE, feed.getRequestedDate());
            contentvalues.put(FED_HOSPITAL_NAME, feed.getHospitalName());
            contentvalues.put(FED_HOSPITAL_ADDRESS, feed.getHospitalAddr());
            contentvalues.put(FED_HOSPITAL_COUNTRY, feed.getCountry());
            contentvalues.put(FED_HOSPITAL_STATE, feed.getState());
            contentvalues.put(FED_HOSPITAL_CITY, feed.getCity());
            contentvalues.put(FED_HOSPITAL_ZIP_CODE, feed.getZipCode());
            contentvalues.put(FED_HOSPITAL_DESCRIPTION, feed.getDescription());
            contentvalues.put(FED_HOSPITAL_PHONE, feed.getPhone());
            contentvalues.put(FED_HOSPITAL_LATTITUDE, feed.getLattitude());
            contentvalues.put(FED_HOSPITAL_LONGITUDE, feed.getLongitude());
            contentvalues.put(FED_HOSPITAL_DISTANCE, feed.getDistance());

            String Query = "Select * From "+ACCEPT_REQUEST_FEEDS_TABLE_NAME+" Where "+FED_ID+"="+"'"+feed.getId()+"'";
            Cursor cursor = database.rawQuery(Query, null);
            if (cursor != null && cursor.moveToFirst())
                database.update(ACCEPT_REQUEST_FEEDS_TABLE_NAME, contentvalues, FED_ID + "='" + feed.getId()+"'", null);
            else
                database.insert(ACCEPT_REQUEST_FEEDS_TABLE_NAME, null, contentvalues);
            database.setTransactionSuccessful();
        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
            // closeDB();
        }
    }

    public UserInfo getUserInfo(){
        UserInfo userInfo =  new UserInfo();
        openDB();
        database.beginTransaction();
        try {
            String Query = "Select * From " + USER_RECORD_TABLE_NAME ;
            Cursor cursor = database.rawQuery(Query, null);
            if (cursor != null && cursor.moveToFirst()){

                cursor.moveToFirst();
                userInfo.setUserId(cursor.getString(cursor.getColumnIndex(UR_USER_ID)));
                userInfo.setUserEmail(cursor.getString(cursor.getColumnIndex(UR_USER_EMAIL)));
                userInfo.setUserFName(cursor.getString(cursor.getColumnIndex(UR_USER_F_NAME)));
                userInfo.setUserLName(cursor.getString(cursor.getColumnIndex(UR_USER_L_NAME)));
                userInfo.setUserMobile(cursor.getString(cursor.getColumnIndex(UR_USER_MOBILE)));
                userInfo.setUserAddress(cursor.getString(cursor.getColumnIndex(UR_USER_ADDRESS)));
                userInfo.setUserBloodGroup(cursor.getString(cursor.getColumnIndex(UR_USER_BLOOD_GROUP)));
                userInfo.setUserCountry(cursor.getString(cursor.getColumnIndex(UR_USER_COUNTRY)));
                userInfo.setUserState(cursor.getString(cursor.getColumnIndex(UR_USER_STATE)));
                userInfo.setUserCity(cursor.getString(cursor.getColumnIndex(UR_USER_CITY)));
                userInfo.setUserZipCode(cursor.getString(cursor.getColumnIndex(UR_USER_ZIP_CODE)));
                userInfo.setProfilePic(cursor.getString(cursor.getColumnIndex(UR_USER_PROFILE_PIC)));
                userInfo.setAuthBy(cursor.getString(cursor.getColumnIndex(UR_USER_AUTH_BY)));

                userInfo.setFilterDistance(cursor.getString(cursor.getColumnIndex(UR_USER_FILTER_DISTANCE)));
                userInfo.setFilterBloodGroup(cursor.getString(cursor.getColumnIndex(UR_USER_FILTER_BG)));

            }
                database.setTransactionSuccessful();
        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
            // closeDB();
        }
    return userInfo;
    }

    public ArrayList<Feed> getFeeds(){
        ArrayList<Feed> feedArrayList =  new ArrayList<>();
        openDB();
        database.beginTransaction();
        try {
            String Query = "Select * From " + FEEDS_TABLE_NAME ;
            Cursor cursor = database.rawQuery(Query, null);
            if (cursor != null && cursor.moveToFirst()){

                cursor.moveToFirst();
                while (!cursor.isAfterLast()) {
                    Feed feed =  new Feed();
                    feed.setId(cursor.getInt(cursor.getColumnIndex(FED_ID)));
                    feed.setpName(cursor.getString(cursor.getColumnIndex(FED_P_NAME)));
                    feed.setUserId(cursor.getString(cursor.getColumnIndex(FED_USER_ID)));
                    feed.setBloodGroup(cursor.getString(cursor.getColumnIndex(FED_BLOOD_GROUP)));
                    feed.setRequestedDate(cursor.getString(cursor.getColumnIndex(FED_REQUEST_DATE)));
                    feed.setHospitalName(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_NAME)));
                    feed.setHospitalAddr(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_ADDRESS)));
                    feed.setCountry(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_COUNTRY)));
                    feed.setState(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_STATE)));
                    feed.setCity(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_CITY)));
                    feed.setZipCode(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_ZIP_CODE)));
                    feed.setDescription(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_DESCRIPTION)));
                    feed.setPhone(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_PHONE)));
                    feed.setLattitude(cursor.getDouble(cursor.getColumnIndex(FED_HOSPITAL_LATTITUDE)));
                    feed.setLattitude(cursor.getDouble(cursor.getColumnIndex(FED_HOSPITAL_LONGITUDE)));
                    feed.setDate(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_DATE)));
                    feed.setDistance(cursor.getInt(cursor.getColumnIndex(FED_HOSPITAL_DISTANCE)));
                    feedArrayList.add(feed);
                    cursor.moveToNext();
                }

            }
            database.setTransactionSuccessful();
        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
            // closeDB();
        }
        return feedArrayList;
    }


    public ArrayList<Feed> getAcceptRequestFeeds(){
        ArrayList<Feed> feedArrayList =  new ArrayList<>();
        openDB();
        database.beginTransaction();
        try {
            String Query = "Select * From " + ACCEPT_REQUEST_FEEDS_TABLE_NAME ;
            Cursor cursor = database.rawQuery(Query, null);
            if (cursor != null && cursor.moveToFirst()){

                cursor.moveToFirst();
                while (!cursor.isAfterLast()) {
                    Feed feed =  new Feed();
                    feed.setId(cursor.getInt(cursor.getColumnIndex(FED_ID)));
                    feed.setpName(cursor.getString(cursor.getColumnIndex(FED_P_NAME)));
                    feed.setUserId(cursor.getString(cursor.getColumnIndex(FED_USER_ID)));
                    feed.setBloodGroup(cursor.getString(cursor.getColumnIndex(FED_BLOOD_GROUP)));
                    feed.setRequestedDate(cursor.getString(cursor.getColumnIndex(FED_REQUEST_DATE)));
                    feed.setHospitalName(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_NAME)));
                    feed.setHospitalAddr(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_ADDRESS)));
                    feed.setCountry(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_COUNTRY)));
                    feed.setState(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_STATE)));
                    feed.setCity(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_CITY)));
                    feed.setZipCode(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_ZIP_CODE)));
                    feed.setDescription(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_DESCRIPTION)));
                    feed.setPhone(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_PHONE)));
                    feed.setLattitude(cursor.getDouble(cursor.getColumnIndex(FED_HOSPITAL_LATTITUDE)));
                    feed.setLattitude(cursor.getDouble(cursor.getColumnIndex(FED_HOSPITAL_LONGITUDE)));
                    feed.setDate(cursor.getString(cursor.getColumnIndex(FED_HOSPITAL_DATE)));
                    feed.setDistance(cursor.getInt(cursor.getColumnIndex(FED_HOSPITAL_DISTANCE)));
                    feedArrayList.add(feed);
                    cursor.moveToNext();
                }

            }
            database.setTransactionSuccessful();
        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
            // closeDB();
        }
        return feedArrayList;
    }


    public void UpdateFeedDistance(Feed feed) {

        // TODO Auto-generated method stub
        openDB();
        database.beginTransaction();
        try {
            ContentValues cv = new ContentValues();
            cv.put(FED_HOSPITAL_DISTANCE,feed.getDistance());
            database.update(FEEDS_TABLE_NAME, cv, FED_ID + "='" + feed.getId() + "'", null);
            database.setTransactionSuccessful();
        }catch (Exception e){
           // e.printStackTrace();
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
        }

    }
    public void resetUserTable() {
        // TODO Auto-generated method stub
        openDB();
        database.beginTransaction();
        try {
            database.delete(USER_RECORD_TABLE_NAME, null, null);
            database.setTransactionSuccessful();

        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
        }
    }
    public void resetFeedsDetail() {
        // TODO Auto-generated method stub
        openDB();
        database.beginTransaction();
        try {
            database.delete(FEEDS_TABLE_NAME,null,null);
            database.setTransactionSuccessful();

        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
        }
    }

    public void resetAcceptRequestDetail() {
        // TODO Auto-generated method stub
        openDB();
        database.beginTransaction();
        try {
            database.delete(ACCEPT_REQUEST_FEEDS_TABLE_NAME,null,null);
            database.setTransactionSuccessful();

        }catch (Exception e){
            Logger.e(TAG,""+e.getMessage());
        } finally {
            database.endTransaction();
        }
    }

}
