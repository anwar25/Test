package com.bplusapp.AccountInfo;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.bplusapp.Adapter.CountryAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.Country;
import com.bplusapp.R;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.Sort.CountryComparator;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.Utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Akash.Singh on 11/18/2015.
 */
public class ChangeCountry extends Fragment {
    ListView lv_country;
    ArrayList<Object>  nationalityArray =  new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_country_screen,container,false);
        ((AccountActivityScreen)getActivity()).SetToolbarInitialization(this,getString(R.string.Country));
        WidgetMapping(view);
        return view;
    }

    private void WidgetMapping(View view) {
        lv_country = (ListView) view.findViewById(R.id.lv_country);
        ShowCountryChangeView();

    }

    public void ShowCountryChangeView() {
        CountryChangeView();
        final CountryAdapter countryAdapter =  new CountryAdapter(getActivity(),nationalityArray);
        lv_country.setAdapter(countryAdapter);
        countryAdapter.notifyDataSetChanged();
        lv_country.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Utils.hideSoftKeyboard(getActivity(), view);
                Country country = (Country) nationalityArray.get(position);
                PreHelper.storeString(getActivity(), StaticConstant.COUNTRY_CODE, country.getCountryCode());
                countryAdapter.notifyDataSetChanged();
                ((AccountActivityScreen) getActivity()).onBackPressed();

            }
        });

        ((AccountActivityScreen)getActivity()).edit_search_country.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    ArrayList<Object> temporaryArray = new ArrayList<>();
                    for (Object curVal : nationalityArray) {
                        Country country = (Country) curVal;
                        if (country.getCountryName().toLowerCase().startsWith(s.toString().toLowerCase())) {
                            temporaryArray.add(curVal);
                        }
                    }
                    nationalityArray.clear();
                    for (Object object : temporaryArray) {
                        Country nationality = (Country) object;
                        nationalityArray.add(nationality);
                    }
                    CountryComparator comparator = new CountryComparator();
                    comparator.sort(CountryComparator.NAME_ATOZ, nationalityArray);
                    countryAdapter.notifyDataSetChanged();
                } else {
                    CountryChangeView();
                    countryAdapter.notifyDataSetChanged();
                }
            }
        });

    }

    private void CountryChangeView() {
        nationalityArray.clear();
        HashMap<Object,Object> objectArrayList = ApplicationContainer.getInstance().getDataModel().GetCountryList();
        for(HashMap.Entry entry:objectArrayList.entrySet()){
            Country nationality = (Country) entry.getValue();
            nationalityArray.add(nationality);
        }
        CountryComparator comparator =  new CountryComparator();
        comparator.sort(CountryComparator.NAME_ATOZ, nationalityArray);

    }


}
