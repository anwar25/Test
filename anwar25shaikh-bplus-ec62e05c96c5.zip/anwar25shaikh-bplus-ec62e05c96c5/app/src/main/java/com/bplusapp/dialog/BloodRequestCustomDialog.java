package com.bplusapp.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.bplusapp.R;
import com.bplusapp.UI.CustomEditView;

/**
 * Created by DEEPAK on 5/9/2016.
 */
public class BloodRequestCustomDialog extends Dialog{

    private ListView lv_custom_blood_request;
    private String items_blood_group[] = {"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"};

    public BloodRequestCustomDialog(Context context, final CustomEditView edit_blood_group) {
        super(context);
        setContentView(R.layout.blood_request_dialog);
        lv_custom_blood_request = (ListView) findViewById(R.id.lv_custom_blood_request);
        lv_custom_blood_request.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1,items_blood_group));

        lv_custom_blood_request.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                edit_blood_group.setText(items_blood_group[position]);

                cancel();
            }
        });

    }


}
