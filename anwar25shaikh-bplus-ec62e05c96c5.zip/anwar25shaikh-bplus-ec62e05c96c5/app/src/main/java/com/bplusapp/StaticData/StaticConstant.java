package com.bplusapp.StaticData;

/**
 * Created by Akash.Singh on 6/2/2015.
 * This class use for global declare variable.
 */
public class StaticConstant {


    public static final String APP_LATITUDE = "appLatitude";
    public static final String APP_LONGITUDE = "appLongitude";
    public static final String BLOOD_REQUEST_ID = "blood_request_id";
    public static final String DONOR_USER_ID = "user_id";
    public static final String TITLE = "title";
    public static final String BODY = "body";
    public static final String BLOOD_GROUP_NON_EDITABLE = "editable";
    public static final String FILTER_DISTANCE = "filter_distance";
    public static final String FILTER_BLOOD_GROUP = "filter_bood_group";

    public static String GCM_APP_ID = "164477444405";
    public static final String FB_ID = "id";
    public static final String FB_NAME = "name";
    public static final String FB_EMAIL = "email";
    public static final String FB_GENDER = "gender";
    public static final String FB_PROFILE_IMAGE = "link";

    public static String DISTANCE = "distance";


    public static final int PAGING_ITEM_SIZE = 20;
    public static final int NULL_POINTER_EXCEPTION = 0;
    public static final int HTTP_RESPONSE_NETWORK_FAIL = 1;
    public static final int HTTP_RESPONSE_SUCCESS = 2;
    public static final String FIRSTTIMECOMPILECOUNTRYLIST = "FirstTimeCompileCountrylist";
    public static final String FIRSTTIMECOMPILECITYLIST = "FirstTimeCompileCitylist";
    public static final String FIRSTTIMECOMPILEBLOODGROUPLIST = "FirstTimeCompileBloodGrouplist";
    public static String GCM_REG_KEY = "gmcRegKey";

    public static final String COUNTRY_CODE = "countryCode";
    public static final String NATIONALITY = "nationality";
    public static final String COUNTRYNAME = "countryName";

    public static final String CITY_CODE = "cityCode";
    public static final String CITY_NAME = "cityName";

    public static final String SALARY_CODE= "salaryCode";
    public static final String SALARY_NAME= "salaryName";

    public static final String CURRENCY_CODE="currencyCode";
    public static final String CURRENCY_NAME="currencyName";
    public static final String CURRENCY_USE = "$";

    public static final String BLOOD_GROUP_CODE="bloodGroupCode";
    public static final String BLOOD_GROUP_NAME="bloodGroupName";
    public static final String BLOOD_GROUP_COLOR="bloodGroupColor";



    public static String BUSINESSCOUNTYCODE = "IN";

    public static String DEVICEID = "deviceId";
    public static String DEVICETOKEN = "deviceToken";
    public static String DEVICETYPE = "deviceType";
    public static String LATTITUDE = "lattitude";
    public static String LONGITUDE = "longitude";
    public static String USERID = "userId";


    public static String FNAME = "fName";
    public static String LNAME = "lName";
    public static String SUCCESS="Success";
    public static String MESSAGE = "message";
    public static String TOTAL_NOTIFICATIONS = "totalNotifications";
    public static String USER_ID="userId";
    public static String BLOOD_GROUP = "bloodGroup";
    public static String ADDRESS = "address";
    public static String COUNTRY = "country";
    public static String CITY = "city";
    public static String STATE = "state";
    public static String ZIPCODE ="zipCode";
    public static String PHONE ="phone";
    public static String USER_EMAIL="userEmail";
    public static String USER_PASSWORD="userPassword";
    public static String USER_FIRST_NAME = "userFirstName";
    public static String USER_LAST_NAME = "userLastName";
    public static String USER_MOBILE="userMobile";
    public static String USER_ADDRESS="userAddress";
    public static String USER_BLOOD_GROUP="userBloodGroup";
    public static String USER_COUNTRY="userCountry";
    public static String USER_CITY="userCity";
    public static String USER_STATE="userState";
    public static String USER_ZIP_CODE="userZipCode";
    public static String USER_PROFILE_PIC="profilePic";
    public static String USER_AUTH_ID="authId";
    public static String USER_AUTH_BY="authBy";
    public static String DEVICE_ID ="deviceId";

    public static String FEED_ID = "id";
    public static String FEED_P_NAME = "requesterName";
    public static String FEED_USER_ID = "userId";
    public static String FEED_BLOOD_GROUP = "bloodGroup";
    public static String FEED_REQUEST_DATE = "requestedDate";
    public static String FEED_HOSPITAL_NAME = "hospitalName";
    public static String FEED_HOSPITAL_ADDRESS = "hospitalAddr";
    public static String FEED_COUNTY = "country";
    public static String FEED_STATE = "state";
    public static String FEED_CITY = "city";
    public static String FEED_ZIP_CODE = "zipCode";
    public static String FEED_DESCRIPTION = "description";
    public static String FEED_PHONE = "phone";
    public static String FEED_LATTITUDE = "lattitude";
    public static String FEED_LONGITUDE = "longitude";
    public static String REQUESTED_DATE="requestedDate";
    public static String FEED_DATE = "date";
    public static String NUMBER_OF_CONFIRMATION = "numberOfConfirmation";
    public static final String DONATED = "donated";
    public static final String USER_DETAIL = "userDetail";



    public static String PACKAGE_NAME ="in.eweblabs.careeradvance";
    public static String Regular_Expression_LOCATION= ", ";
    public static String TERM_AND_CONDITIONS = "term_and_condition.html";
    public static String FRAGMENT_TYPE = "fragmentType";
}
