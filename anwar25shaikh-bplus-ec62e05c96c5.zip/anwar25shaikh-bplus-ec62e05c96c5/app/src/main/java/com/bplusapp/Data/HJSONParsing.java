package com.bplusapp.Data;

import android.content.Context;
import android.text.TextUtils;

import com.bplusapp.ApplicationContainer;
import com.bplusapp.Entity.AllNotificationDataClass;
import com.bplusapp.Entity.BloodGroup;
import com.bplusapp.Entity.Country;
import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.MyRequestDescriptionDataClass;
import com.bplusapp.Entity.NotificationDescriptionDataClass;
import com.bplusapp.Entity.ReceiverInfo;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.Utils.TextUtility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Akash.Singh on 6/4/2015.
 * There has parse xml string.
 */
public class HJSONParsing {

    public Object ParseRegisterMethod(Context context, String Response) {
        ResponseMessage responseMessage = new ResponseMessage();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            responseMessage.setStatus(jsonObject.getInt(StaticConstant.SUCCESS));
            if (jsonObject.has(StaticConstant.MESSAGE)) ;
            responseMessage.setMessage(jsonObject.getString(StaticConstant.MESSAGE));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }

    public Object ParseLoginMethod(Context context, String Response) {
        UserInfo userInfo = new UserInfo();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            userInfo.setSuccess(jsonObject.getInt(StaticConstant.SUCCESS));
            if (jsonObject.has(StaticConstant.MESSAGE)) ;
            userInfo.setMessage(jsonObject.getString(StaticConstant.MESSAGE));
            if (jsonObject.has(StaticConstant.TOTAL_NOTIFICATIONS)) ;
            userInfo.setTotalNotifications(jsonObject.getString(StaticConstant.TOTAL_NOTIFICATIONS));

            if (jsonObject.has(StaticConstant.FILTER_DISTANCE)) ;
            userInfo.setFilterDistance(jsonObject.getString(StaticConstant.FILTER_DISTANCE));

            if (jsonObject.has(StaticConstant.FILTER_BLOOD_GROUP)) ;
            userInfo.setFilterBloodGroup(jsonObject.getString(StaticConstant.FILTER_BLOOD_GROUP));

            ParseLoginMethod(jsonObject, userInfo);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return userInfo;
    }


    public Object ParseDeviceIdMethod(Context context, String Response) {
        UserInfo userInfo = new UserInfo();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            userInfo.setSuccess(jsonObject.getInt(StaticConstant.SUCCESS));
            if (jsonObject.has(StaticConstant.MESSAGE)) ;
            userInfo.setMessage(jsonObject.getString(StaticConstant.MESSAGE));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return userInfo;
    }


    public Object ParseUserProfileMethod(Context context, String Response) {
        UserInfo userInfo = new UserInfo();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            userInfo.setSuccess(jsonObject.getInt(StaticConstant.SUCCESS));
            if (jsonObject.has(StaticConstant.MESSAGE)) ;
            userInfo.setMessage(jsonObject.getString(StaticConstant.MESSAGE));

            if (userInfo.getSuccess() == 1) {
                ParseLoginMethod(jsonObject, userInfo);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return userInfo;
    }

    private void ParseLoginMethod(JSONObject jsonObject, UserInfo userInfo) throws JSONException {
        if (jsonObject.has(StaticConstant.USER_ID)) ;
        userInfo.setUserId(jsonObject.getString(StaticConstant.USER_ID));
        if (jsonObject.has(StaticConstant.USER_EMAIL)) ;
        userInfo.setUserEmail(jsonObject.getString(StaticConstant.USER_EMAIL));
        if (jsonObject.has(StaticConstant.USER_FIRST_NAME)) ;
        userInfo.setUserFName(jsonObject.getString(StaticConstant.USER_FIRST_NAME));
        if (jsonObject.has(StaticConstant.USER_LAST_NAME)) ;
        userInfo.setUserLName(jsonObject.getString(StaticConstant.USER_LAST_NAME));
        if (jsonObject.has(StaticConstant.USER_MOBILE)) ;
        userInfo.setUserMobile(jsonObject.getString(StaticConstant.USER_MOBILE));
        if (jsonObject.has(StaticConstant.USER_ADDRESS)) ;
        userInfo.setUserAddress(jsonObject.getString(StaticConstant.USER_ADDRESS));
        if (jsonObject.has(StaticConstant.USER_BLOOD_GROUP)) ;
        userInfo.setUserBloodGroup(jsonObject.getString(StaticConstant.USER_BLOOD_GROUP));
        if (jsonObject.has(StaticConstant.USER_COUNTRY)) ;
        userInfo.setUserCountry(jsonObject.getString(StaticConstant.USER_COUNTRY));
        if (jsonObject.has(StaticConstant.USER_STATE)) ;
        userInfo.setUserState(jsonObject.getString(StaticConstant.USER_STATE));
        if (jsonObject.has(StaticConstant.USER_CITY)) ;
        userInfo.setUserCity(jsonObject.getString(StaticConstant.USER_CITY));
        if (jsonObject.has(StaticConstant.USER_ZIP_CODE)) ;
        userInfo.setUserZipCode(jsonObject.getString(StaticConstant.USER_ZIP_CODE));
        if (jsonObject.has(StaticConstant.USER_PROFILE_PIC)) ;
        userInfo.setProfilePic(jsonObject.getString(StaticConstant.USER_PROFILE_PIC));
        if (jsonObject.has(StaticConstant.USER_AUTH_ID)) ;
        userInfo.setAuthId(jsonObject.getString(StaticConstant.USER_AUTH_ID));
        if (jsonObject.has(StaticConstant.USER_AUTH_BY)) ;
        userInfo.setAuthBy(jsonObject.getString(StaticConstant.USER_AUTH_BY));
        if (!TextUtils.isEmpty(userInfo.getUserId()))
            ApplicationContainer.getInstance().getBPlusSavedDBData().InsertUserInfoID(userInfo);

    }

    public Object ParseChangePasswordMethod(Context context, String Response) {
        ResponseMessage responseMessage = new ResponseMessage();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            responseMessage.setStatus(jsonObject.getInt(StaticConstant.SUCCESS));
            if (jsonObject.has(StaticConstant.MESSAGE)) ;
            responseMessage.setMessage(jsonObject.getString(StaticConstant.MESSAGE));


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }

    public Object ParseForgotPasswordMethod(Context context, String Response) {
        ResponseMessage responseMessage = new ResponseMessage();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            responseMessage.setStatus(jsonObject.getInt(StaticConstant.SUCCESS));
            if (jsonObject.has(StaticConstant.MESSAGE)) ;
            responseMessage.setMessage(jsonObject.getString(StaticConstant.MESSAGE));


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }

    public Object ParseFeedsMethod(Context context, String Response, String TYPE) {
        ResponseMessage responseMessage = new ResponseMessage();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            if (jsonObject.has(StaticConstant.SUCCESS)) ;
            responseMessage.setStatus(jsonObject.getInt(StaticConstant.SUCCESS));

            ArrayList<Object> feedArrayList = new ArrayList<>();
            if (jsonObject.has(StaticConstant.USER_DETAIL)) {
                Object object = jsonObject.get(StaticConstant.USER_DETAIL);
                if (object instanceof JSONArray) {
                    JSONArray jsonArray = jsonObject.getJSONArray(StaticConstant.USER_DETAIL);
                    if (TYPE.equalsIgnoreCase(BaseNetwork.FEEDS_METHOD) || TYPE.equalsIgnoreCase(BaseNetwork.FILTER_REQUESETS))
                        ApplicationContainer.getInstance().getBPlusSavedDBData().resetFeedsDetail();
                    else
                        ApplicationContainer.getInstance().getBPlusSavedDBData().resetAcceptRequestDetail();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        Feed feed = new Feed();
                        JSONObject jsonUserDetail = jsonArray.getJSONObject(i);
                        ParseFeedsMethod(jsonUserDetail, feed, PreHelper.getStoredDouble(context, StaticConstant.APP_LATITUDE), PreHelper.getStoredDouble(context, StaticConstant.APP_LONGITUDE), TYPE);
                        feedArrayList.add(feed);
                    }
                } else if (object instanceof JSONObject) {
                    if (TYPE.equalsIgnoreCase(BaseNetwork.FEEDS_METHOD) || TYPE.equalsIgnoreCase(BaseNetwork.FILTER_REQUESETS))
                        ApplicationContainer.getInstance().getBPlusSavedDBData().resetFeedsDetail();
                    else
                        ApplicationContainer.getInstance().getBPlusSavedDBData().resetAcceptRequestDetail();

                    Feed feed = new Feed();
                    ParseFeedsMethod(jsonObject.getJSONObject(StaticConstant.USER_DETAIL), feed, PreHelper.getStoredDouble(context, StaticConstant.APP_LATITUDE), PreHelper.getStoredDouble(context, StaticConstant.APP_LONGITUDE), TYPE);
                    feedArrayList.add(feed);
                }
                responseMessage.setObjectArrayList(feedArrayList);
           /* if(jsonObject.has(StaticConstant.MESSAGE));
            responseMessage.setMessage(jsonObject.getString(StaticConstant.MESSAGE));*/
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }

    private void ParseFeedsMethod(JSONObject jsonUserDetail, Feed feed, Double CurrentLatitude, Double CurrentLongitude, String TYPE) throws JSONException {
        if (jsonUserDetail.has(StaticConstant.FEED_ID))
            feed.setId(jsonUserDetail.getInt(StaticConstant.FEED_ID));
        if (jsonUserDetail.has(StaticConstant.FEED_P_NAME))
            feed.setpName(jsonUserDetail.getString(StaticConstant.FEED_P_NAME));
        if (jsonUserDetail.has(StaticConstant.FEED_USER_ID))
            feed.setUserId(jsonUserDetail.getString(StaticConstant.FEED_USER_ID));
        if (jsonUserDetail.has(StaticConstant.FEED_BLOOD_GROUP))
            feed.setBloodGroup(jsonUserDetail.getString(StaticConstant.FEED_BLOOD_GROUP));
        if (jsonUserDetail.has(StaticConstant.FEED_REQUEST_DATE))
            feed.setRequestedDate(jsonUserDetail.getString(StaticConstant.FEED_REQUEST_DATE));
        if (jsonUserDetail.has(StaticConstant.FEED_HOSPITAL_NAME))
            feed.setHospitalName(jsonUserDetail.getString(StaticConstant.FEED_HOSPITAL_NAME));
        if (jsonUserDetail.has(StaticConstant.FEED_HOSPITAL_ADDRESS))
            feed.setHospitalAddr(jsonUserDetail.getString(StaticConstant.FEED_HOSPITAL_ADDRESS));
        if (jsonUserDetail.has(StaticConstant.FEED_COUNTY))
            feed.setCountry(jsonUserDetail.getString(StaticConstant.FEED_COUNTY));
        if (jsonUserDetail.has(StaticConstant.FEED_STATE))
            feed.setState(jsonUserDetail.getString(StaticConstant.FEED_STATE));
        if (jsonUserDetail.has(StaticConstant.FEED_CITY))
            feed.setCity(jsonUserDetail.getString(StaticConstant.FEED_CITY));
        if (jsonUserDetail.has(StaticConstant.FEED_ZIP_CODE))
            feed.setZipCode(jsonUserDetail.getString(StaticConstant.FEED_ZIP_CODE));
        if (jsonUserDetail.has(StaticConstant.FEED_DESCRIPTION))
            feed.setDescription(jsonUserDetail.getString(StaticConstant.FEED_DESCRIPTION));
        if (jsonUserDetail.has(StaticConstant.FEED_PHONE))
            feed.setPhone(jsonUserDetail.getString(StaticConstant.FEED_PHONE));
        if (jsonUserDetail.has(StaticConstant.NUMBER_OF_CONFIRMATION))
            feed.setNumberOfConfirmation(jsonUserDetail.getString(StaticConstant.NUMBER_OF_CONFIRMATION));
        if (jsonUserDetail.has(StaticConstant.FEED_LATTITUDE)) {
            String lattitude = jsonUserDetail.getString(StaticConstant.FEED_LATTITUDE);
            feed.setLattitude(Double.valueOf(TextUtility.checkIsStringDoubleEmpty(lattitude)));

        }
        if (jsonUserDetail.has(StaticConstant.FEED_LONGITUDE)) {
            String lattitude = jsonUserDetail.getString(StaticConstant.FEED_LONGITUDE);
            feed.setLongitude(Double.valueOf(TextUtility.checkIsStringDoubleEmpty(lattitude)));
        }
        if (jsonUserDetail.has(StaticConstant.REQUESTED_DATE))
            feed.setDate(jsonUserDetail.getString(StaticConstant.REQUESTED_DATE));

        if (jsonUserDetail.has(StaticConstant.DONATED))
            feed.setDonated(jsonUserDetail.getInt(StaticConstant.DONATED));

        android.location.Location CurrentLocation = new android.location.Location("");
        CurrentLocation.setLatitude(CurrentLatitude);
        CurrentLocation.setLongitude(CurrentLongitude);
        android.location.Location feedLocation = new android.location.Location("");
        feedLocation.setLatitude(feed.getLattitude());
        feedLocation.setLongitude(feed.getLongitude());

        double distanceInMeters = feedLocation.distanceTo(CurrentLocation);
        feed.setDistance(distanceInMeters / 1000);

        //Deepak <code></code>
        if (TYPE.equalsIgnoreCase("Feeds"))
            feed.setDistance(Double.parseDouble(jsonUserDetail.getString(StaticConstant.DISTANCE)));

        if (feed.getId() != 0) {
            if (TYPE.equalsIgnoreCase(BaseNetwork.FEEDS_METHOD) || TYPE.equalsIgnoreCase(BaseNetwork.FILTER_REQUESETS))
                ApplicationContainer.getInstance().getBPlusSavedDBData().InsertFeedsID(feed);
            else if (TYPE.equalsIgnoreCase(BaseNetwork.REQUESTS_BY_USER_ID_METHOD))
                ApplicationContainer.getInstance().getBPlusSavedDBData().InsertAcceptRequestFeedsID(feed);

        }

    }

    public HashMap<Object, Object> parseCountryData(String JSONResponse) {
        HashMap<Object, Object> countryList = new HashMap<Object, Object>();
        try {
            JSONArray jsonArray = new JSONArray(JSONResponse);
            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String countryCode = jsonObject.getString(StaticConstant.COUNTRY_CODE);
                String countryName = jsonObject.getString(StaticConstant.COUNTRYNAME);
                Country country = new Country(countryCode, countryName);
                countryList.put(country.getCountryCode(), country);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return countryList;
    }


    public HashMap<Object, Object> parseCurrencyData(String JSONResponse) {
        HashMap<Object, Object> annualSalaryList = new HashMap<Object, Object>();
        try {
            JSONArray jsonArray = new JSONArray(JSONResponse);
            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject jsonObject = jsonArray.getJSONObject(i);
                int bloodGroupCode = jsonObject.getInt(StaticConstant.BLOOD_GROUP_CODE);
                String bloodGroupName = jsonObject.getString(StaticConstant.BLOOD_GROUP_NAME);
                String bloodGroupColor = jsonObject.getString(StaticConstant.BLOOD_GROUP_COLOR);
                BloodGroup bloodGroup = new BloodGroup(bloodGroupCode, bloodGroupName, bloodGroupColor);
                annualSalaryList.put(bloodGroup.getBloodGroupCode(), bloodGroup);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return annualSalaryList;
    }


    public Object ParseAllNotificationMethod(Context context, String Response) {
        AllNotificationDataClass allNotificationDataClass;
        List<AllNotificationDataClass> allNotificationDataClassList = new ArrayList<AllNotificationDataClass>();
        try {
            JSONObject jsonObject = new JSONObject(Response);
            JSONArray jsonArray = jsonObject.getJSONArray("allNotification");
            JSONObject object;
            for (int i = 0; i < jsonArray.length(); i++) {

                object = jsonArray.getJSONObject(i);
                allNotificationDataClass = new AllNotificationDataClass();
                allNotificationDataClass.setId(object.getString("id"));
                allNotificationDataClass.setRequestId(object.getString("requestId"));
                allNotificationDataClass.setBloodGroup(object.getString("bloodGroup"));
                //allNotificationDataClass.setDeviceId(object.getString("deviceId"));
                allNotificationDataClass.setDateTime(object.getString("dateTime"));
                allNotificationDataClass.setMessage(object.getString("message"));

                allNotificationDataClassList.add(allNotificationDataClass);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return allNotificationDataClassList;
    }

    public Object ParseNotificationDesriptionMethod(Context context, String Response) {
        NotificationDescriptionDataClass feed;
        List<NotificationDescriptionDataClass> feedList = new ArrayList<NotificationDescriptionDataClass>();

        try {
            JSONObject jsonObject = new JSONObject(Response);
            JSONArray jsonArray = jsonObject.getJSONArray("userDetail");
            JSONObject object;
            for (int i = 0; i < jsonArray.length(); i++) {

                object = jsonArray.getJSONObject(i);
                feed = new NotificationDescriptionDataClass();
                feed.setId(Integer.parseInt(object.getString("id")));
                feed.setRequesterName(object.getString("requesterName"));
                feed.setUserId(object.getString("userId"));
                feed.setBloodGroup(object.getString("bloodGroup"));
                feed.setRequestedDate(object.getString("requestedDate"));
                feed.setHospitalName(object.getString("hospitalName"));
                feed.setHospitalAddr(object.getString("hospitalAddr"));
                feed.setCountry(object.getString("country"));
                feed.setCity(object.getString("city"));
                feed.setZipCode(object.getString("zipCode"));
                feed.setDescription(object.getString("description"));
                feed.setPhone(object.getString("phone"));
                feed.setLattitude(object.getString("lattitude"));
                feed.setLongitude(object.getString("longitude"));
                feed.setDate(object.getString("date"));
                if (object.has(StaticConstant.DONATED))
                    feed.setDonated(object.getInt(StaticConstant.DONATED));
                else
                    feed.setDonated(0);
                feedList.add(feed);

                PreHelper.storeLatitude(context, object.getString("lattitude"));
                PreHelper.storeLongitude(context, object.getString("longitude"));


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return feedList;
    }

    public Object ParseMyRequestDesriptionMethod(Context context, String Response) {
        MyRequestDescriptionDataClass requestDescriptionDataClass;
        ReceiverInfo receiverInfo;
        List<MyRequestDescriptionDataClass> myRequestDescriptionDataClasses = new ArrayList<MyRequestDescriptionDataClass>();
        ArrayList<ReceiverInfo> receiverInfos = new ArrayList<ReceiverInfo>();

        try {
            JSONObject jsonObject = new JSONObject(Response);
            JSONArray jsonArray = jsonObject.getJSONArray("userDetail");
            JSONObject object;
            JSONArray jsonArray1;
            JSONObject jsonObject1;
            for (int i = 0; i < jsonArray.length(); i++) {

                object = jsonArray.getJSONObject(i);
                requestDescriptionDataClass = new MyRequestDescriptionDataClass();
                requestDescriptionDataClass.setId(Integer.parseInt(object.getString("id")));
                requestDescriptionDataClass.setRequesterName(object.getString("requesterName"));
                requestDescriptionDataClass.setUserId(object.getString("userId"));
                requestDescriptionDataClass.setBloodGroup(object.getString("bloodGroup"));
                requestDescriptionDataClass.setRequestedDate(object.getString("requestedDate"));
                requestDescriptionDataClass.setHospitalName(object.getString("hospitalName"));
                requestDescriptionDataClass.setHospitalAddr(object.getString("hospitalAddr"));
                requestDescriptionDataClass.setCountry(object.getString("country"));
                requestDescriptionDataClass.setCity(object.getString("city"));
                requestDescriptionDataClass.setZipCode(object.getString("zipCode"));
                requestDescriptionDataClass.setDescription(object.getString("description"));
                requestDescriptionDataClass.setPhone(object.getString("phone"));
                requestDescriptionDataClass.setLattitude(object.getString("lattitude"));
                requestDescriptionDataClass.setLongitude(object.getString("longitude"));
                requestDescriptionDataClass.setDate(object.getString("date"));
                requestDescriptionDataClass.setNumberOfConfirmation(object.getString("numberOfConfirmation"));

                jsonArray1 = object.getJSONArray("receiverInfo");
                for (int j = 0; j < jsonArray1.length(); j++) {

                    jsonObject1 = jsonArray1.getJSONObject(j);
                    receiverInfo = new ReceiverInfo();
                    receiverInfo.setUser_name(jsonObject1.getString("user_name"));
                    receiverInfo.setEmail(jsonObject1.getString("email"));
                    receiverInfo.setMobile(jsonObject1.getString("mobile"));
                    receiverInfo.setBlood_group(jsonObject1.getString("blood_group"));
                    receiverInfo.setUser_image(jsonObject1.getString("user_image"));
                    receiverInfo.setUser_id(jsonObject1.getString("user_id"));
                    receiverInfos.add(receiverInfo);

                }

                requestDescriptionDataClass.setmReceiverInfos(receiverInfos);
                myRequestDescriptionDataClasses.add(requestDescriptionDataClass);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return myRequestDescriptionDataClasses;
    }


    public Object ParseConfirmRequestMethod(Context context, String Response) {
        UserInfo responseMessage = new UserInfo();
        try {
            JSONObject jsonObject = new JSONObject(Response);

            responseMessage.setMessage(jsonObject.getString("message"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }


    public Object ParseCloseRequestMethod(Context context, String Response) {
        UserInfo responseMessage = new UserInfo();
        try {
            JSONObject jsonObject = new JSONObject(Response);

            responseMessage.setMessage(jsonObject.getString("message"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }

    public Object ParseConfirmBloodRequestMethod(Context context, String Response) {
        UserInfo responseMessage = new UserInfo();
        try {
            JSONObject jsonObject = new JSONObject(Response);

            responseMessage.setMessage(jsonObject.getString("message"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return responseMessage;
    }

}
