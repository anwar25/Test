package com.bplusapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.Toast;

import com.bplusapp.AccountInfo.AccountActivityScreen;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.ITimeCount;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.TimeHandler.TimeCount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.iid.FirebaseInstanceId;

/**
 * Created by Akash.Singh on 11/9/2015.
 */
public class SplashScreen extends AppCompatActivity implements ITimeCount, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    TimeCount timeCount;
    long SleepTime = 3000;

    private GoogleApiClient mGoogleApiClient;
    private Location mCurrentLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mGoogleApiClient = new GoogleApiClient.Builder(SplashScreen.this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();


        timeCount = new TimeCount(SleepTime, 1000);
        timeCount.setiTimeCount(this);
        timeCount.start();


      /*PackageInfo info;
      try {
          info = getPackageManager().getPackageInfo("com.bplusapp", PackageManager.GET_SIGNATURES);
          for (Signature signature : info.signatures) {
              MessageDigest md;
              md = MessageDigest.getInstance("SHA");
              md.update(signature.toByteArray());
              String something = new String(Base64.encode(md.digest(), 0));
              //String something = new String(Base64.encodeBytes(md.digest()));
              Logger.d("hash key", ":" + something);
          }
      } catch (PackageManager.NameNotFoundException e1) {
          Log.e("name not found", e1.toString());
      } catch (NoSuchAlgorithmException e) {
          Log.e("no such an algorithm", e.toString());
      } catch (Exception e) {
          Log.e("exception", e.toString());
      }*/
        getSupportActionBar().hide();
    }


    @Override
    public void OnTickListener(long Time_tick) {
    }

    @Override
    public void OnFinish() {
        if(mayRequestLocationPermission()){
            redirect();
        };

    }

    private void redirect() {
        // call firebase to generate token
        FirebaseInstanceId.getInstance().getToken();

        UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
        Intent intent;
        if (TextUtils.isEmpty(userInfo.getUserId())) {
            intent = new Intent(SplashScreen.this, AccountActivityScreen.class);
            intent.putExtra(StaticConstant.FRAGMENT_TYPE, 0);
        } else if (TextUtils.isEmpty(userInfo.getUserBloodGroup())) {
            intent = new Intent(SplashScreen.this, AccountActivityScreen.class);
            intent.putExtra(StaticConstant.FRAGMENT_TYPE, 1);
        } else {
            intent = new Intent(SplashScreen.this, BaseActivityScreen.class);
        }
        startActivity(intent);
        finish();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (timeCount != null)
            timeCount.cancel();
    }

    @Override
    public void onConnected(Bundle bundle) {

        mCurrentLocation = LocationServices
                .FusedLocationApi
                .getLastLocation(mGoogleApiClient);


        if (mCurrentLocation != null) {
            double latitude = mCurrentLocation.getLatitude();
            double longitude = mCurrentLocation.getLongitude();
            PreHelper.storeDouble(getApplicationContext(), StaticConstant.APP_LATITUDE, latitude);
            PreHelper.storeDouble(getApplicationContext(), StaticConstant.APP_LONGITUDE, longitude);

        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }


    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    private final int REQUEST_LOCATION = 3;

    private boolean mayRequestLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
            Toast.makeText(this, getString(R.string.permission_rationale_location)
                    , Toast.LENGTH_LONG).show();
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_LOCATION) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                redirect();
            } else {
                Toast.makeText(this, getString(R.string.permission_required_toast), Toast.LENGTH_LONG).show();
            }
        }
    }
}
