package com.bplusapp.Interface;

/**
 * Created by Akash.Singh on 2/7/2016.
 */
public interface IFragmentLifeCycle {
    public void onPauseFragment();
    public void onResumeFragment();
}
