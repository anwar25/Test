package com.bplusapp.Interface;

/**
 * Created by Akash.Singh on 11/9/2015.
 */
public interface ITimeCount {

    void OnTickListener(long timetick);
    void OnFinish();

}
