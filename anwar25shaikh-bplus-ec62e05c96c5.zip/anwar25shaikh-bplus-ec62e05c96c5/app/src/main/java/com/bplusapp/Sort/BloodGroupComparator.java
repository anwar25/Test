package com.bplusapp.Sort;

import com.bplusapp.Entity.BloodGroup;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


/**
 * Created by Akash.Singh on 9/2/2015.
 */
public class BloodGroupComparator {

    public static final int CODE_ATOZ = 0;
    public static final int CODE_ZTOA = 1;
    public static final int NAME_ATOZ = 2;
    public static final int NAME_ZTOA = 3;

    public void sort(int sortKind, ArrayList<Object> cityList) {
        if (sortKind == CODE_ATOZ)
            Collections.sort(cityList, BloodGroupCodeAtoZ);
        else if (sortKind == CODE_ZTOA)
            Collections.sort(cityList, BloodGroupCodeZtoA);
        else if (sortKind == NAME_ATOZ)
            Collections.sort(cityList, BloodGroupNameAtoZ);
        else if (sortKind == NAME_ZTOA)
            Collections.sort(cityList, BloodGroupNameZtoA);


    }


    public static Comparator<Object> BloodGroupCodeAtoZ = new Comparator<Object>() {
        public int compare(Object BloodGroup1, Object BloodGroup2) {
            String nationalityCode1 = String.valueOf(((BloodGroup) BloodGroup1).getBloodGroupCode()).toUpperCase();
            String nationalityCode2 = String.valueOf((((BloodGroup) BloodGroup2)).getBloodGroupCode()).toUpperCase();
            return nationalityCode1.compareTo(nationalityCode2);
        }
    };

    public static Comparator<Object> BloodGroupCodeZtoA = new Comparator<Object>() {
        public int compare(Object BloodGroup1, Object BloodGroup2) {
            String nationalityCode1 = String.valueOf(((BloodGroup) BloodGroup1).getBloodGroupCode()).toUpperCase();
            String nationalityCode2 = String.valueOf((((BloodGroup) BloodGroup2)).getBloodGroupCode()).toUpperCase();
            return nationalityCode2.compareTo(nationalityCode1);
        }
    };


    public static Comparator<Object> BloodGroupNameAtoZ = new Comparator<Object>() {
        public int compare(Object nationality1, Object nationality2) {
            String cityCode1 = ((BloodGroup) nationality1).getBloodGroupName()
                    .toUpperCase();
            String cityCode2 = ((BloodGroup) nationality2).getBloodGroupName()
                    .toUpperCase();
            return cityCode1.compareTo(cityCode2);
        }
    };

    public static Comparator<Object> BloodGroupNameZtoA = new Comparator<Object>() {
        public int compare(Object nationality1, Object nationality2) {
            String cityCode1 = ((BloodGroup) nationality1).getBloodGroupName()
                    .toUpperCase();
            String cityCode2 = ((BloodGroup) nationality2).getBloodGroupName()
                    .toUpperCase();
            return cityCode2.compareTo(cityCode1);
        }
    };


}
