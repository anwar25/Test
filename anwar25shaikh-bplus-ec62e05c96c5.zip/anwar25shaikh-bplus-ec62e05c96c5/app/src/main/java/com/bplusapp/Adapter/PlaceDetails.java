package com.bplusapp.Adapter;

/**
 * Created by Anwar on 7/3/2016.
 */
public class PlaceDetails {

    private String description ;
    private String placeId ;

    public PlaceDetails(String description, String place_id) {
        this.description = description ;
        this.placeId = place_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }
}
