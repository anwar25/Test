package com.bplusapp;

import android.app.Application;

import com.bplusapp.DB.BPlusSavedDBData;
import com.bplusapp.DB.DatabaseManager;
import com.bplusapp.Data.DataModel;
import com.bplusapp.Utils.AnalyticsTrackers;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.StandardExceptionParser;
import com.google.android.gms.analytics.Tracker;

import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

//import com.google.android.gms.gcm.GoogleCloudMessaging;

/**
 * Created by Akash.Singh on 12/15/2015.
 */


@ReportsCrashes(formKey = "", // will not be used
        mailTo = "deepak87.cs@gmail.com, info@eweblabs.com",
        mode = ReportingInteractionMode.TOAST,
        resToastText = R.string.crash_text)

public class ApplicationContainer extends Application{

    static ApplicationContainer appController;
   // GoogleCloudMessaging gcm;
    BPlusSavedDBData bPlusSavedDBData;
    public static ApplicationContainer getInstance()
    {
        return  appController;
    }
    DataModel dataModel;


    /*private Tracker mTracker;

    *//**
     * Gets the default {@link Tracker} for this {@link Application}.
     * @return tracker
     *//*
    synchronized public Tracker getDefaultTracker() {
        if (mTracker == null) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(this);
            // To enable debug logging use: adb shell setprop log.tag.GAv4 DEBUG
            mTracker = analytics.newTracker(R.xml.app_tracker);
        }
        return mTracker;
    }*/




    public synchronized Tracker getGoogleAnalyticsTracker() {
        AnalyticsTrackers analyticsTrackers = AnalyticsTrackers.getInstance();
        return analyticsTrackers.get(AnalyticsTrackers.Target.APP);
    }

    /***
     * Tracking screen view
     *
     * @param screenName screen name to be displayed on GA dashboard
     */
    public void trackScreenView(String screenName) {
        Tracker t = getGoogleAnalyticsTracker();

        // Set screen name.
        t.setScreenName(screenName);

        // Send a screen view.
        t.send(new HitBuilders.ScreenViewBuilder().build());

        GoogleAnalytics.getInstance(this).dispatchLocalHits();
    }

    /***
     * Tracking exception
     *
     * @param e exception to be tracked
     */
    public void trackException(Exception e) {
        if (e != null) {
            Tracker t = getGoogleAnalyticsTracker();

            t.send(new HitBuilders.ExceptionBuilder()
                    .setDescription(
                            new StandardExceptionParser(this, null)
                                    .getDescription(Thread.currentThread().getName(), e))
                    .setFatal(false)
                    .build()
            );
        }
    }

    /***
     * Tracking event
     *
     * @param category event category
     * @param action   action of the event
     * @param label    label
     */
    public void trackEvent(String category, String action, String label) {
        Tracker t = getGoogleAnalyticsTracker();

        // Build and send an Event.
        t.send(new HitBuilders.EventBuilder().setCategory(category).setAction(action).setLabel(label).build());
    }



    @Override
    public void onCreate() {
        super.onCreate();
       // ACRA.init(this);
        appController = this;
        AnalyticsTrackers.initialize(this);
        AnalyticsTrackers.getInstance().get(AnalyticsTrackers.Target.APP);
       // registerGCMService();
        dataModel =  new DataModel(this);
        DatabaseManager databaseManager = new DatabaseManager(this);
       /* try {
            databaseManager.createDataBase();
        }
        catch (IOException ioexception) {
            throw new RuntimeException(ioexception);
        }*/
        bPlusSavedDBData =  new BPlusSavedDBData(this);
        LocalDataLoad();
    }

    private void LocalDataLoad(){
        dataModel.PopulateCountryList();
        dataModel.PopulateBloodGroupList();
    }

   /* public void registerGCMService()
    {
        try{
            gcm = GoogleCloudMessaging.getInstance(this);
            String regId = getRegistrationId(this);
            Logger.e("anwar","Registeration ID ==  " + regId);


            if (TextUtils.isEmpty(regId)){
                registerInBackground();
            } else{
                storeRegistrationId(this, regId);
            }
            Logger.d("registerGCMService", (new StringBuilder("::")).append(regId).toString());
        }catch (Exception e){

        }

    }

    private void storeRegistrationId(Context context, String regId) {
        HashMap<Object, Object> hashMap = new HashMap<>();
        hashMap.put("deviceId", Utils.DeviceID(context));
        hashMap.put("deviceToken",regId);
        PreHelper.storeRegId(ApplicationContainer.this, regId);
        BaseNetwork.obj().PostMethodWay(context, BaseNetwork.URL_HOST, BaseNetwork.REGISTER_METHOD, hashMap, BaseNetwork.obj().TimeOut);
    }

    private String getRegistrationId(Context context) {
        return PreHelper.getRegId(context);
    }



    private void registerInBackground() {
        (new AsyncTask() {
            @Override
            protected Object doInBackground(Object[] params) {
                try
                {
                   if (gcm == null)
                    {
                        gcm = GoogleCloudMessaging.getInstance(getApplicationContext());
                    }
                    String regId = gcm.register(StaticConstant.GCM_APP_ID);
                    Logger.e("anwar","Registeration ID ==  " + regId);
                    //  System.out.println(regId);


                    if(regId!=null)
                       storeRegistrationId(appController, regId);
                }
                catch (Exception e)
                {
                    String s = (new StringBuilder("Error :")).append(e.getMessage()).toString();
                    Logger.d("GCNException", "::" + s);
                    e.printStackTrace();
                    return s;
                }
                return "";
            }

            protected  void onPostExecute(Object obj)
            {
                onPostExecute((String)obj);
            }

            protected void onPostExecute(String s)
            {
            }

        }).execute();
    }*/

    public BPlusSavedDBData getBPlusSavedDBData() {
        return bPlusSavedDBData;
    }

    public void setBPlusSavedDBData(BPlusSavedDBData bPlusSavedDBData) {
        this.bPlusSavedDBData = bPlusSavedDBData;
    }

    public DataModel getDataModel() {
        return dataModel;
    }

    public void setDataModel(DataModel dataModel) {
        this.dataModel = dataModel;
    }
}
