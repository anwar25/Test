package com.bplusapp.Utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Environment;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by akash.singh on 11/21/2015.
 */
public class Utils {

    public static void hideSoftKeyboard(Context context,View view) {
        InputMethodManager imm = (InputMethodManager) context
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
    }

    public static void showToast(Context context,String stringText) {
        Toast.makeText(context, stringText, Toast.LENGTH_SHORT).show();

    }

    public static void ShowSoftKeyboard(Context context,View view) {
        InputMethodManager imm = (InputMethodManager) context
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(view, 1);
    }
    public static boolean validateEmail(String email) {

        Pattern pattern;
        Matcher matcher;
        String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }

    public static boolean validatePhone(String phone) {
        if(phone.length()>=10)
            return true;
        else
            return false;

    }

    public static boolean validatePassword(String phone) {
        if(phone.length()>= 6)
            return true;
        else
            return false;

    }

    public static String DeviceID(Context context){
        String device_id = ((TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE))
                .getDeviceId();
        if (device_id == null) {
            device_id = Settings.Secure.getString(context
                    .getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        return device_id;
    }

   /* public static ArrayList<Offer> GetOfferDetailItem() {
        ArrayList<OfferItem> mItems =  new ArrayList<>();
        mItems = new ArrayList<OfferItem>();
        OfferItem categoryItem = new OfferItem();
        categoryItem.setTitle("Wazwan Foods");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/m6bl_sqp.jpg?v=20151211100940");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setLocation("Sector 14");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLocation("Sector 14");
        categoryItem.setLink("");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLocation("Sector 14");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLocation("Sector 14");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLocation("Sector 14");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLocation("Sector 14");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setLocation("Sector 14");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);

        categoryItem = new OfferItem();
        categoryItem.setTitle("Jack and Jones, Haus Khas");
        categoryItem.setAmount("2000");
        categoryItem.setDiscount("20");
        categoryItem.setLocation("Sector 14");
        categoryItem.setBrandImage("https://asia-public.foodpanda.com/dynamic/production/in/images/vendors/r4kw_sqp.jpg?v=20151028172909");
        categoryItem.setEnd_date("25 Dec 2015");
        categoryItem.setLink("https://www.youtube.com/watch?v=2_Zm19Jcebk");
        mItems.add(categoryItem);
        return mItems;
    }*/

    public static void  copyFile(Context context)
    {
        try
        {
            File sd = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString());
            File data = Environment.getDataDirectory();
            boolean  bool =true;
            if (sd.canWrite())
            {
                String currentDBPath = "/data/" + context.getPackageName() + "/databases/db_eyes4deal.el";

                if(android.os.Build.VERSION.SDK_INT >= 4.2){
                    currentDBPath = context.getApplicationInfo().dataDir + "/databases/db_eyes4deal.el";
                } else {
                    currentDBPath = "/data/" + context.getPackageName() + "/databases/db_eyes4deal.el";
                }
                String backupDBPath = "db_eyes4deal.el";

                File currentDB = new File(currentDBPath);
                File backupDB = new File(sd, backupDBPath);

                if (currentDB.exists()) {
                    FileChannel src = new FileInputStream(currentDB).getChannel();
                    FileChannel dst = new FileOutputStream(backupDB).getChannel();
                    dst.transferFrom(src, 0, src.size());
                    src.close();
                    dst.close();
                }

            }
        }
        catch (Exception e) {
            Logger.d("Settings Backup", "::" + e);
        }
    }

    public static String DoubleDigitDecimal(Double price) {

        NumberFormat nf = NumberFormat.getNumberInstance(Locale.ENGLISH);
        DecimalFormat df = (DecimalFormat) nf;
        df.applyPattern("0.00");
        return df.format(price);
    }


    public static String getCurrentDateTime() {
        return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
    }

    public static void ShowAlertDialog(Context context,String message, final IDialogClick iDialogClick, final Fragment fragment) {
        if(context!=null){
            final AlertDialog alertDialog = new AlertDialog.Builder(context).create();

            alertDialog.setTitle(context.getString(R.string.app_name));

            alertDialog.setMessage(message);

            alertDialog.setButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    iDialogClick.OnClickListener(fragment);
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
        }

    }

    public static String ConvertDateFormat(String date) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1 = new Date() ;

        if(!TextUtils.isEmpty(date))
        {
            date = formatter.format(Date.parse(date));
            try {
                date1 = new SimpleDateFormat("dd-MMM-yyyy hh:mm a").parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return new SimpleDateFormat("dd-MMM-yyyy hh:mm a").format(date1);
    }

    public static int UseBloodGroupCode(String bloodGroup){

        if(bloodGroup.equalsIgnoreCase("A+"))
            return R.drawable.circle_blood_blue;
        else if(bloodGroup.equalsIgnoreCase("A-"))
            return R.drawable.circle_blood_green;
        else if(bloodGroup.equalsIgnoreCase("B+"))
            return R.drawable.circle_blood_grey;
        else if(bloodGroup.equalsIgnoreCase("B-"))
            return R.drawable.circle_blood_orange;
        else if(bloodGroup.equalsIgnoreCase("AB+"))
            return R.drawable.circle_blood_purple;
        else if(bloodGroup.equalsIgnoreCase("AB-"))
            return R.drawable.circle_blood_red;
        else if(bloodGroup.equalsIgnoreCase("O+"))
            return R.drawable.circle_blood_teal;
        else if(bloodGroup.equalsIgnoreCase("O-"))
            return R.drawable.circle_blood_pink;
        else
            return R.drawable.circle_blood_red;

    }

    public static int UseColorBloodGroupCode(String bloodGroup){

        if(bloodGroup.equalsIgnoreCase("A+"))
            return R.color.facebookPrimary;
        else if(bloodGroup.equalsIgnoreCase("A-"))
            return R.color.dark_green;
        else if(bloodGroup.equalsIgnoreCase("B+"))
            return R.color.text_color;
        else if(bloodGroup.equalsIgnoreCase("B-"))
            return R.color.orange_color;
        else if(bloodGroup.equalsIgnoreCase("AB+"))
            return R.color.Purple_color;
        else if(bloodGroup.equalsIgnoreCase("AB-"))
            return R.color.colorPrimary;
        else if(bloodGroup.equalsIgnoreCase("O+"))
            return R.color.teal_color;
        else if(bloodGroup.equalsIgnoreCase("O-"))
            return R.color.Pink_color;
        else
            return R.color.colorPrimary;

    }
}
