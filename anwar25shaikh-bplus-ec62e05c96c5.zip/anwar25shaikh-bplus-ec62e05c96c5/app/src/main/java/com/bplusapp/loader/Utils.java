/**
 *
 */
package com.bplusapp.loader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author ppphuc
 *
 */
public class Utils {


    public static void copyStream(InputStream in, OutputStream out) {
        final int buffer_size = 1024;
        byte[] bytes = new byte[buffer_size];
        for (;;) {
            int count = 0;
            try {
                count = in.read(bytes, 0, buffer_size);
                if (count == -1) {
                    break;
                }
                out.write(bytes, 0, count);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String getRatingValueString(String ratingName, double ratingValue) {
        String valueString = "";

        Double star_50 = new Double("5.0");
        Double star_45 = new Double("4.5");
        Double star_40 = new Double("4.0");
        Double star_35 = new Double("3.5");
        Double star_30 = new Double("3.0");
        Double star_25 = new Double("2.5");
        Double star_20 = new Double("2.0");
        Double star_15 = new Double("1.5");
        Double star_10 = new Double("1.0");
        Double star_05 = new Double("0.5");

        if (ratingName.equalsIgnoreCase("AAA")) {
            if (Double.compare(ratingValue, star_50) == 0) {
                valueString = "★★★★★";
            } else if (Double.compare(ratingValue, star_45) == 0) {
                valueString = "★★★★☆";
            } else if (Double.compare(ratingValue, star_40) == 0) {
                valueString = "★★★★";
            } else if (Double.compare(ratingValue, star_35) == 0) {
                valueString = "★★★☆";
            } else if (Double.compare(ratingValue, star_30) == 0) {
                valueString = "★★★";
            } else if (Double.compare(ratingValue, star_25) == 0) {
                valueString = "★★☆";
            } else if (Double.compare(ratingValue, star_20) == 0) {
                valueString = "★★";
            } else if (Double.compare(ratingValue, star_15) == 0) {
                valueString = "★☆";
            } else if (Double.compare(ratingValue, star_10) == 0) {
                valueString = "★";
            } else if (Double.compare(ratingValue, star_05) == 0) {
                valueString = "☆";
            }
        } else {
            if (Double.compare(ratingValue, star_50) == 0) {
                valueString = "�?�?�?�?�?";
            } else if (Double.compare(ratingValue, star_45) == 0) {
                valueString = "�?�?�?�?○";
            } else if (Double.compare(ratingValue, star_40) == 0) {
                valueString = "�?�?�?�?";
            } else if (Double.compare(ratingValue, star_35) == 0) {
                valueString = "�?�?�?○";
            } else if (Double.compare(ratingValue, star_30) == 0) {
                valueString = "�?�?�?";
            } else if (Double.compare(ratingValue, star_25) == 0) {
                valueString = "�?�?○";
            } else if (Double.compare(ratingValue, star_20) == 0) {
                valueString = "�?�?";
            } else if (Double.compare(ratingValue, star_15) == 0) {
                valueString = "�?○";
            } else if (Double.compare(ratingValue, star_10) == 0) {
                valueString = "�?";
            } else if (Double.compare(ratingValue, star_05) == 0) {
                valueString = "○";
            }
        }
        return valueString;
    }



    /*public static void SetImageViewPage1(List<CategoryItem> mItems){

        CategoryItem categoryItem = new CategoryItem();
        categoryItem.setmName("New Year Party");
        categoryItem.setmThumbnail("http://www.globaltours-bg.com/ibank/s/Happy_New_Year_007.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryNewYear());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Food & Beverage");
        categoryItem.setmThumbnail("http://hoteljobsasia.com/wp-content/uploads/2013/06/RoomService-Pen.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFood());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fashion");
        categoryItem.setmThumbnail("http://3.bp.blogspot.com/-onBGyyzsIdw/VcebTXV9iZI/AAAAAAAABkU/dQBm8nSsTWo/s640/Men%2527s%2BFashion%2BAccessories%2BSpring.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFashion());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Spa & Salon");
        categoryItem.setmThumbnail("http://expressionssalonandspa.com/images/spa_12453706.jpg");
        categoryItem.setSubCategoryItems(SetSubCategorySpaAndSalon());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Health & Fitness");
        categoryItem.setmThumbnail("http://www.baanamphawa.com/image/upload/spa_banner.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryHealthAndFitness());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fun Zone");
        categoryItem.setmThumbnail("http://files.elnashra.com/elnashrasports/pictures/1991554_1433423812.jpg");
        mItems.add(categoryItem);

        *//**//*

        categoryItem = new CategoryItem();
        categoryItem.setmName("Home Decor");
        categoryItem.setmThumbnail("http://4.bp.blogspot.com/-ZkAOyrnJ3Gs/Ua_uUaa869I/AAAAAAAANt0/tiB4NIIDBe4/s1600/Ogilvy+Department+Store+001.JPG");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Mix All");
        categoryItem.setmThumbnail("http://www.mycomptechservice.com/wp-content/uploads/2013/05/Apple-Products.jpg");
        mItems.add(categoryItem);


    }




    public static void SetImageViewPage2(List<CategoryItem> mItems){

        CategoryItem categoryItem = new CategoryItem();
        categoryItem.setmName("New Year Party");
        categoryItem.setmThumbnail("http://www.azhappynewyear2016hdwallpaper.com/wp-content/uploads/2015/11/Happy-New-Year-2016-Animated-Wallpaper.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryNewYear());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Food & Beverage");
        categoryItem.setmThumbnail("http://www.synthite.com/synthite/our-products/Industrial-Products-By-Application/Food-And-Beverages/myTextBlock/0/textBlock_files/file0/Food-and-beverages.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFood());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fashion");
        categoryItem.setmThumbnail("http://stat.homeshop18.com/homeshop18/images/productImages/639/fidato-only-you-mens-accessories-range-medium_c95f4fe54d59e08b3cc96cdf6558ae69.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFashion());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Spa & Salon");
        categoryItem.setmThumbnail("http://3.bp.blogspot.com/-mNGtJ9ITloM/UYiMFLbes7I/AAAAAAAAAn4/DvSh91WSHz4/s1600/bigstockphoto_spa_scene_1106801.jpg");
        categoryItem.setSubCategoryItems(SetSubCategorySpaAndSalon());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Health & Fitness");
        categoryItem.setmThumbnail("http://thenextfamily.com/wp-content/uploads/2013/04/weight-loss-200x200.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryHealthAndFitness());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fun Zone");
        categoryItem.setmThumbnail("http://www.fordesigner.com/imguploads/Image/cjbc/zcool/20080523/1211544096.jpg");
        mItems.add(categoryItem);

        *//**//*

        categoryItem = new CategoryItem();
        categoryItem.setmName("Home Decor");
        categoryItem.setmThumbnail("http://4.bp.blogspot.com/-ZkAOyrnJ3Gs/Ua_uUaa869I/AAAAAAAANt0/tiB4NIIDBe4/s1600/Ogilvy+Department+Store+001.JPG");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Mix All");
        categoryItem.setmThumbnail("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGwteekKcQVySmmV8PCkgEhW6kvgSaIZYjljgkjfEe2gLS7g7x9A");
        mItems.add(categoryItem);

    }

    public static void SetImageViewPage3(List<CategoryItem> mItems){

        CategoryItem categoryItem = new CategoryItem();
        categoryItem.setmName("New Year Party");
        categoryItem.setmThumbnail("http://3.bp.blogspot.com/-UVNyDcs-Qrg/VjSxzLoIaQI/AAAAAAAAAFY/b6VqWL90_Cc/s640/Happy%2BNew%2BYear%2B2016.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryNewYear());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Food & Beverage");
        categoryItem.setmThumbnail("http://hoteljobsasia.com/wp-content/uploads/2013/06/RoomService-Pen.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFood());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fashion");
        categoryItem.setmThumbnail("http://i.telegraph.co.uk/multimedia/archive/01757/lorenzi_1757708b.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFashion());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Spa & Salon");
        categoryItem.setmThumbnail("http://tanglesalonspa.com/wp-content/uploads/2014/05/311318__spa-treatment_p.jpg");
        categoryItem.setSubCategoryItems(SetSubCategorySpaAndSalon());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Health & Fitness");
        categoryItem.setmThumbnail("http://www.wikiihealth.com/wp-content/uploads/2014/12/Health-and-Fitness-200x200.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryHealthAndFitness());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fun Zone");
        categoryItem.setmThumbnail("http://api.ning.com/files/4OYMKu3tHDFN*WgS4B1JWJGKZajt333ncgfLC0vlhRPaItfvGTl7H-iMvP9ts1j4BeGnNEJTxgorkPTcBthwjCvRCiUZHZ2q/istockphoto_5681319musicmoviesandFun Zoneicons.jpg");
        mItems.add(categoryItem);

        *//**//*

        categoryItem = new CategoryItem();
        categoryItem.setmName("Home Decor");
        categoryItem.setmThumbnail("http://www.magetjooz.com/cdn-uploads/2015/08/29/6-x-6-office-cubicles-fashionable-office-cubicles-design-ideas-with-white-and-grey-color-schemes-and-with-yellow-accent-600x380.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Mix All");
        categoryItem.setmThumbnail("http://cache.lego.com/r/www/r/friends/-/media/franchises/friends2014/products/2015%202hy%20new/41108_web_01_744w_2x.jpg?l.r2=-2042713589");
        mItems.add(categoryItem);

    }

    public static void SetImageViewPage4(List<CategoryItem> mItems){

        CategoryItem categoryItem = new CategoryItem();
        categoryItem.setmName("New Year Party");
        categoryItem.setmThumbnail("http://img.freepik.com/free-vector/new-year-2016-card-with-fireworks_1035-384.jpg?size=338&ext=jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryNewYear());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Food & Beverage");
        categoryItem.setmThumbnail("http://www.blog.researchonglobalmarkets.com/wp-content/uploads/2015/05/food-and-beverage-image-5.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFood());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fashion");
        categoryItem.setmThumbnail("http://i1222.photobucket.com/albums/dd497/GabrielleLam1D/Lam%20Boutique/292373_10150958426518178_393510994_n.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFashion());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Spa & Salon");
        categoryItem.setmThumbnail("http://static.in.groupon-content.net/91/42/1428899854291.jpg");
        categoryItem.setSubCategoryItems(SetSubCategorySpaAndSalon());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Health & Fitness");
        categoryItem.setmThumbnail("http://planningwithkids.com/wp-content/2013/04/health-and-fitness-500.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fun Zone");
        categoryItem.setmThumbnail("http://network-magazine.co.uk/wp-content/uploads/2015/04/outdoor-cinema-essex.jpg");
        mItems.add(categoryItem);

        *//**//*

        categoryItem = new CategoryItem();
        categoryItem.setmName("Home Decor");
        categoryItem.setmThumbnail("http://dellacooks.com/wp-content/uploads/2014/06/modern-warm-cozy-bright-bedroom-design-with-white-bedroom-furniture-and-modern-furnishing-also-white-sheer-curtain-ideas-1024x640.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Mix All");
        categoryItem.setmThumbnail("https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcS0Sn_mcJzz39aDAlKmBrL-MGg46oUWIIX2nBLm4EJ0Oddyrwch");
        mItems.add(categoryItem);

    }

    public static void SetImageViewPage5(List<CategoryItem> mItems){

        CategoryItem categoryItem = new CategoryItem();
        categoryItem.setmName("New Year Party");
        categoryItem.setmThumbnail("http://www.magic4walls.com/wp-content/uploads/2015/09/happy-new-year-2016-golden-gift-box-with-bokeh-hearts-694x417.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryNewYear());
        mItems.add(categoryItem);


        categoryItem = new CategoryItem();
        categoryItem.setmName("Food & Beverage");
        categoryItem.setmThumbnail("http://www.livello6.it/wp-content/uploads/2015/03/FM-PHOTOGRAPHER-FOOD-BEVERAGE-17-400x300.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFood());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fashion");
        categoryItem.setmThumbnail("http://previews.123rf.com/images/dgemma/dgemma1405/dgemma140500104/28909567-Set-of-men-s-clothing-and-accessories-Hipster-concept-Stock-Photo.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFashion());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Spa & Salon");
        categoryItem.setmThumbnail("http://www.makevegasyourstumblr.com/article_images/ARIA_SpaSalon_SaltRoom.jpg");
        categoryItem.setSubCategoryItems(SetSubCategorySpaAndSalon());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Health & Fitness");
        categoryItem.setmThumbnail("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUcsaWsBpj8jxUoGulcs7rVPXSujOCFtvgaDbhPi8i63RIO-21");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fun Zone");
        categoryItem.setmThumbnail("http://dbijapkm3o6fj.cloudfront.net/resources/14556,4,1,6,4,0/-2424-/20150618020214/events.jpeg");
        mItems.add(categoryItem);

        *//**//*

        categoryItem = new CategoryItem();
        categoryItem.setmName("Home Decor");
        categoryItem.setmThumbnail("http://st.hzcdn.com/simgs/0dd1915f03218eaf_4-5440/eclectic-dining-room.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Mix All");
        categoryItem.setmThumbnail("http://images.wondershare.com/tunesgo/shujuxian.png");
        mItems.add(categoryItem);

    }


    public static void SetImageViewPage6(List<CategoryItem> mItems){

        CategoryItem categoryItem = new CategoryItem();
        categoryItem.setmName("New Year Party");
        categoryItem.setmThumbnail("http://venues.meraevents.com/blog/wp-content/uploads/2014/12/www.venues.meraevents.com_345.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryNewYear());
        mItems.add(categoryItem);


        categoryItem = new CategoryItem();
        categoryItem.setmName("Food & Beverage");
        categoryItem.setSubCategoryItems(SetSubCategoryFood());
        categoryItem.setmThumbnail("http://www.hfbleadership.org/admin/wordpress/wp-content/uploads/2014/01/2-Six-Seven.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fashion");
        categoryItem.setmThumbnail("http://previews.123rf.com/images/martm/martm1307/martm130700005/21044549-9-highly-detailed-men-accessories-icons-Stock-Vector-men-luxury-shoes.jpg");
        categoryItem.setSubCategoryItems(SetSubCategoryFashion());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Spa & Salon");
        categoryItem.setmThumbnail("http://www.baanamphawa.com/image/upload/spa_banner.jpg");
        categoryItem.setSubCategoryItems(SetSubCategorySpaAndSalon());
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Health & Fitness");
        categoryItem.setmThumbnail("http://www.nursetogether.com/sites/default/files/nurse_articles/body/customize-time-for-exercise-nurse.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Fun Zone");
        categoryItem.setmThumbnail("http://levick.com/sites/default/files/styles/vimeo-large/public/sports%5B2%5D.jpg?itok=vaH05RMb");
        mItems.add(categoryItem);



        categoryItem = new CategoryItem();
        categoryItem.setmName("Home Decor");
        categoryItem.setmThumbnail("http://www.homerevo.com/wp-content/uploads/Bamboo-for-decorating-living-room-and-furniture-Home-design-Image.jpg");
        mItems.add(categoryItem);

        categoryItem = new CategoryItem();
        categoryItem.setmName("Mix All");
        categoryItem.setmThumbnail("http://p-fst2.pixstatic.com/506afee3dbd0cb30850015d8._w.1500_s.fit_.jpg");
        mItems.add(categoryItem);

    }


    static ArrayList<SubCategoryItem> SetSubCategoryNewYear(){
        ArrayList<SubCategoryItem> subCategoryItems = new ArrayList<>() ;
       return subCategoryItems; 
    }

    private static ArrayList<SubCategoryItem> SetSubCategoryFood() {
        ArrayList<SubCategoryItem> subCategoryItems = new ArrayList<>() ;
        SubCategoryItem subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Food");
        subCategoryItem.setSubCategoryItems(new ArrayList<SubCategoryItem>());
        subCategoryItems.add(subCategoryItem);

        subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Beverage");
        subCategoryItem.setSubCategoryItems(new ArrayList<SubCategoryItem>());
        subCategoryItems.add(subCategoryItem);

        return subCategoryItems;
    }

    private static ArrayList<SubCategoryItem> SetSubCategoryFashion() {
        ArrayList<SubCategoryItem> subCategoryItems = new ArrayList<>() ;
        SubCategoryItem subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Men");
        ArrayList<SubCategoryItem> subCategoryItems1 = new ArrayList<>() ;
        SubCategoryItem subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Dresses");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Footwear");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Accessories");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);

        subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Women");
        subCategoryItems1 = new ArrayList<>() ;
        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Dresses");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Footwear");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Accessories");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);

        subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Kids");
        subCategoryItems1 = new ArrayList<>() ;
        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Dresses");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Footwear");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Accessories");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);

        return subCategoryItems;
    }

    private static ArrayList<SubCategoryItem> SetSubCategorySpaAndSalon() {
        ArrayList<SubCategoryItem> subCategoryItems = new ArrayList<>() ;
        SubCategoryItem subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Men");
        ArrayList<SubCategoryItem> subCategoryItems1 = new ArrayList<>() ;
        SubCategoryItem subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Spa");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 = new SubCategoryItem();
        subCategoryItem1.setmName("Salon");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);

        subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Women");
        subCategoryItems1 = new ArrayList<>() ;
        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Spa");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Salon");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);


        return subCategoryItems;

    }


    private static ArrayList<SubCategoryItem> SetSubCategoryHomeDecor() {
        ArrayList<SubCategoryItem> subCategoryItems = new ArrayList<>() ;
        SubCategoryItem subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Farniture");
        ArrayList<SubCategoryItem> subCategoryItems1 = new ArrayList<>() ;
        SubCategoryItem subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Spa");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 = new SubCategoryItem();
        subCategoryItem1.setmName("Farnish");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);

        subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Modular item");
        subCategoryItems1 = new ArrayList<>() ;
        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Spa");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem1 =  new SubCategoryItem();
        subCategoryItem1.setmName("Salon");
        subCategoryItems1.add(subCategoryItem1);

        subCategoryItem.setSubCategoryItems(subCategoryItems1);
        subCategoryItems.add(subCategoryItem);


        return subCategoryItems;

    }

    private static ArrayList<SubCategoryItem> SetSubCategoryHealthAndFitness() {

        ArrayList<SubCategoryItem> subCategoryItems = new ArrayList<>() ;

        SubCategoryItem subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Health Club");
        subCategoryItem.setSubCategoryItems(new ArrayList<SubCategoryItem>());
        subCategoryItems.add(subCategoryItem);

        subCategoryItem =  new SubCategoryItem();
        subCategoryItem.setmName("Clinic");
        subCategoryItem.setSubCategoryItems(new ArrayList<SubCategoryItem>());
        subCategoryItems.add(subCategoryItem);

        return  subCategoryItems;

    }*/

}
