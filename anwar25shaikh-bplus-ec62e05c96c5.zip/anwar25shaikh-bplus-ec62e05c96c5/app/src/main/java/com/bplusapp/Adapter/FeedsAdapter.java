package com.bplusapp.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bplusapp.Entity.Feed;
import com.bplusapp.Interface.IFeedItemListener;
import com.bplusapp.R;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.Utils.Utils;
import com.bplusapp.loader.ImageLoader;

import java.util.ArrayList;

/**
 * Created by Akash.Singh on 23/01/2016.
 */
public class FeedsAdapter extends RecyclerView.Adapter<FeedsAdapter.ViewHolder> {

    ImageLoader imageLoader;
    ArrayList<Feed> mItems;
    Context context;
    String fragmment_name;

    private IFeedItemListener iFeedItemListener ;
    public FeedsAdapter(Context context, ArrayList<Feed> mItems, String fragmment_name, IFeedItemListener iFeedItemListener) {
        super();
        this.mItems = mItems;
        this.context = context;
        this.fragmment_name = fragmment_name;
        imageLoader =  new ImageLoader(context);
        this.iFeedItemListener = iFeedItemListener ;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup,final int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.feed_item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        final Feed nature = mItems.get(i);
        viewHolder.edit_blood_group.setBackground(context.getResources().getDrawable(Utils.UseBloodGroupCode(nature.getBloodGroup())));
        viewHolder.edit_blood_group.setText(nature.getBloodGroup());
        viewHolder.requester_name.setText(nature.getpName());
        viewHolder.requester_title.setText(nature.getHospitalName());
        //viewHolder.requester_date_time.setText(Utils.ConvertDateFormat(nature.getDate())); Deepak comment and write below line
        viewHolder.requester_date_time.setText(nature.getRequestedDate());
        if(fragmment_name.equalsIgnoreCase("Accepted Request")){
            viewHolder.text_distance.setVisibility(View.INVISIBLE);
            viewHolder.iv_km.setVisibility(View.INVISIBLE);
        }else {
            viewHolder.text_distance.setVisibility(View.VISIBLE);
            viewHolder.iv_km.setVisibility(View.VISIBLE);
            viewHolder.text_distance.setText(""+nature.getDistance() + " km");
        }
    }

    @Override
    public int getItemCount() {

        return mItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public CustomTextView edit_blood_group,requester_name,requester_title
                ,requester_date_time,text_distance;
        public ImageView iv_km ;

        public ViewHolder(View itemView) {
            super(itemView);
            edit_blood_group = (CustomTextView) itemView.findViewById(R.id.edit_blood_group);
            requester_name = (CustomTextView)itemView.findViewById(R.id.requester_name);
            requester_title = (CustomTextView) itemView.findViewById(R.id.requester_title);
            requester_date_time = (CustomTextView) itemView.findViewById(R.id.requester_date_time);
            text_distance = (CustomTextView) itemView.findViewById(R.id.text_distance);
            iv_km = (ImageView) itemView.findViewById(R.id.iv_km);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            iFeedItemListener.feedItemClicked(mItems.get(getAdapterPosition()),fragmment_name);
        }
    }

}
