package com.bplusapp.Network;

/**
 * Created by Anwar on 8/4/2016.
 */
public interface Urls {

    String GOOGLE_PLACES_API_KEY = "AIzaSyC7pmeRSJkgUWUEvJhEteu-OtyPlxftkck";

    String GOOGLE_PLACES_BASE_URL = "https://maps.googleapis.com/maps/api/place/";
    String GET_ADRESS_API = "autocomplete/json";
    String GET_PLACE_DETAILS = "details/json";

}