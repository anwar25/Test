package com.bplusapp.Network;

import com.bplusapp.Network.models.PredictionResponse;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by Anwar on 5/21/2016.
 */
public interface RetrofitInterface {


    @GET(Urls.GET_ADRESS_API)
    Call<ResponseBody> getAddress(@Query("input") String adress, @Query("key") String key);

    @GET(Urls.GET_PLACE_DETAILS)
    Call<PredictionResponse> getPlaceDetails(@Query("placeid") String placeId, @Query("key") String key);

}
