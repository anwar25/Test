package com.bplusapp.fcm;

import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;

import com.bplusapp.ApplicationContainer;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.Utils.Utils;

import java.util.HashMap;

/**
 * Created by Anwar on 7/18/2016.
 */
public class RegisterToken {

    private static final String TAG = RegisterToken.class.getSimpleName();

    public static void sendRegistrationTokenToServer( final Context context,final String token) {
        UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
        if(userInfo != null && !TextUtils.isEmpty(userInfo.getUserId())){
            storeRegistrationId(context,token);
        }
    }

    public static  void storeRegistrationId(final Context context, final String regId) {
        (new AsyncTask() {
            @Override
            protected Object doInBackground(Object[] params) {
                HashMap<Object, Object> hashMap = new HashMap<>();
                hashMap.put("deviceId", Utils.DeviceID(context));
                hashMap.put("deviceToken",regId);
                PreHelper.storeRegId(context, regId);
                BaseNetwork.obj().PostMethodWay(context, BaseNetwork.URL_HOST, BaseNetwork.REGISTER_METHOD, hashMap, BaseNetwork.obj().TimeOut);
                return "";
            }

            protected  void onPostExecute(Object obj)
            {
                onPostExecute((String)obj);
            }

            protected void onPostExecute(String s)
            {
            }

        }).execute();

    }
}
