package com.bplusapp.Data;

import android.content.Context;

import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AsyncTaskTools;
import com.bplusapp.AsyncTask.BloodGroupAsyncTask;
import com.bplusapp.AsyncTask.CountryAsyncTask;
import com.bplusapp.Interface.IDataModel;

import java.util.HashMap;

/**
 * Created by Akash.Singh on 4/02/2016.
 * This class manage application content to local data.
 */
public class DataModel implements IDataModel {

    HashMap<Object,Object> countrylist =  new HashMap<Object,Object>();
    HashMap<Object,Object> bloodGrouplist =  new HashMap<Object,Object>();

    Context context;

    public DataModel(Context context){
        this.context = context;

    }


    @Override
    public void PopulateCountryList() {
        CountryAsyncTask compInfoAsyncTask =  new CountryAsyncTask(ApplicationContainer.getInstance().getDataModel());
        AsyncTaskTools.execute(compInfoAsyncTask);
    }

    @Override
    public HashMap<Object, Object> GetCountryList() {
        return countrylist;
    }

    public void SetCountryList(HashMap<Object,Object> countrylist){
        this.countrylist = countrylist;
    }




    @Override
    public void PopulateBloodGroupList() {
        BloodGroupAsyncTask compInfoAsyncTask =  new BloodGroupAsyncTask(ApplicationContainer.getInstance().getDataModel());
        AsyncTaskTools.execute(compInfoAsyncTask);
    }

    @Override
    public HashMap<Object, Object> GetBloodGroupList() {
        return bloodGrouplist;
    }

    public void SetBloodGroupList(HashMap<Object,Object> bloodGrouplist){
        this.bloodGrouplist = bloodGrouplist;
    }
    
    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }


}
