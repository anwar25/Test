package com.bplusapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.bplusapp.Entity.BloodGroup;
import com.bplusapp.Entity.Country;
import com.bplusapp.R;

import java.util.ArrayList;

/**
 * Created by Akash.Singh on 2/3/2016.
 */
public class SpinnerAdapter extends ArrayAdapter<Object> {
    ArrayList<Object> stringArrayList =  new ArrayList<>();

    public SpinnerAdapter(Context context, int textViewResourceId,ArrayList<Object> stringArrayList) {
        super(context, textViewResourceId, stringArrayList);
        this.stringArrayList = stringArrayList;
    }

    @Override
    public View getDropDownView(int position, View convertView,ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.my_spinner_style, parent, false);
        TextView my_spinner_text=(TextView)rowView.findViewById(R.id.my_spinner_text);
        if(stringArrayList.get(position) instanceof BloodGroup)
        {
            BloodGroup bloodGroup = (BloodGroup) stringArrayList.get(position);
            my_spinner_text.setText(bloodGroup.getBloodGroupName());
        }
        else if(stringArrayList.get(position) instanceof Country){
            Country country = (Country) stringArrayList.get(position);
            my_spinner_text.setText(country.getCountryName());

        }
        return rowView;
    }
}
