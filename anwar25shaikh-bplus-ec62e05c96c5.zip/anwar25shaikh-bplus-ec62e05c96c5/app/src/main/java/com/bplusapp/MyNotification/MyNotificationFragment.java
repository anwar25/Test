package com.bplusapp.MyNotification;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.bplusapp.AccountInfo.SignUpFragment;
import com.bplusapp.AccountInfo.UpdateProfileFragment;
import com.bplusapp.Adapter.MyNotificationAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.AllNotificationDataClass;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Feed.FeedDetailFragment;
import com.bplusapp.Feed.MyNotificationDetailFragment;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.TextUtility;
import com.bplusapp.Utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Akash.Singh on 1/20/2016.
 */
public class MyNotificationFragment extends Fragment implements IAsyncTaskRunner, IDialogClick{

    private ListView list_view_notification;
    private MyNotificationAdapter  notificationAdapter;
    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((BaseActivityScreen)getActivity()).SetToolbarInitialization(this, getString(R.string.notification));

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_notification_screen,container,false);
        list_view_notification = (ListView) view.findViewById(R.id.list_view_notification);
        performNotificationProcess();


        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        list_view_notification.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MyNotificationDetailFragment feedDetailFragment = new MyNotificationDetailFragment();
                Bundle bundle = new Bundle();
                bundle.putString("requestId",((AllNotificationDataClass)parent.getAdapter().getItem(position)).getRequestId());
                feedDetailFragment.setArguments(bundle);
                ((BaseActivityScreen) getActivity()).onReplaceFragment(feedDetailFragment, true);
            }
        });

    }

    public void performNotificationProcess(){
        loadingDialog =  new CustomLoadingDialog(getActivity());
        authCommonTask =  new AuthCommonTask(getActivity(), BaseNetwork.GET_ALL_NOTIFICATIONS,this,loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("userId", ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId() );
        authCommonTask.execute(hashMap);

    }


    @Override
    public void taskCompleted(Object obj) {


        if(obj!=null){
            ResultMessage resultMessage = (ResultMessage) obj;
            if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.GET_ALL_NOTIFICATIONS)){
                List<AllNotificationDataClass> allNotificationDataClassList  = (ArrayList<AllNotificationDataClass>) resultMessage.RESULT_OBJECT;
                
                notificationAdapter = new MyNotificationAdapter(getActivity(), allNotificationDataClassList);
                list_view_notification.setAdapter(notificationAdapter);
                
                if(allNotificationDataClassList.size() == 0){

                    Toast.makeText(getActivity(), "Notifications not available", Toast.LENGTH_SHORT).show();
                }

            }
        }

    }

    @Override
    public void taskErrorMessage(Object obj) {
        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);
    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }
}
