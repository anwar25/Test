package com.bplusapp.StaticData;

/**
 * Created by Akash.Singh on 7/30/2015.
 */
public class DbConstraints {


    public final String USER_RECORD_TABLE_NAME = "UserRecord";
    public final String FEEDS_TABLE_NAME = "Feeds";
    public final String ACCEPT_REQUEST_FEEDS_TABLE_NAME = "AcceptRequestFeeds";

    public final String UR_USER_ID = "userId";
    public final String UR_USER_EMAIL = "userEmail";
    public final String UR_USER_F_NAME = "userFName";
    public final String UR_USER_L_NAME = "userLName";
    public final String UR_USER_MOBILE = "userMobile";
    public final String UR_USER_ADDRESS = "userAddress";
    public final String UR_USER_BLOOD_GROUP = "userBloodGroup";
    public final String UR_USER_COUNTRY = "userCountry";
    public final String UR_USER_STATE = "userState";
    public final String UR_USER_CITY = "userCity";
    public final String UR_USER_ZIP_CODE = "userZipCode";
    public final String UR_USER_PROFILE_PIC = "profilePic";
    public final String UR_USER_AUTH_BY = "authBy";
    public final String UR_USER_FILTER_DISTANCE = "filter_distance";
    public final String UR_USER_FILTER_BG = "filter_bood_group";

    public final String FED_ID = "id";
    public final String FED_P_NAME = "pName";
    public final String FED_USER_ID = "userId";
    public final String FED_BLOOD_GROUP = "bloodGroup";
    public final String FED_REQUEST_DATE = "requestedDate";
    public final String FED_HOSPITAL_NAME = "hospitalName";
    public final String FED_HOSPITAL_ADDRESS = "hospitalAddr";
    public final String FED_HOSPITAL_COUNTRY = "country";
    public final String FED_HOSPITAL_STATE = "State";
    public final String FED_HOSPITAL_CITY = "city";
    public final String FED_HOSPITAL_ZIP_CODE = "zipCode";
    public final String FED_HOSPITAL_DESCRIPTION = "description";
    public final String FED_HOSPITAL_PHONE = "phone";
    public final String FED_HOSPITAL_LATTITUDE = "lattitude";
    public final String FED_HOSPITAL_LONGITUDE = "longitude";
    public final String FED_HOSPITAL_DATE = "date";
    public final String FED_HOSPITAL_DISTANCE = "Distance";

}
