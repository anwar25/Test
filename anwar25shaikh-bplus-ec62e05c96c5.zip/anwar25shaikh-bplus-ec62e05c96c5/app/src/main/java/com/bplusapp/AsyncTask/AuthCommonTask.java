// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.bplusapp.AsyncTask;

import android.content.Context;
import android.text.TextUtils;
import android.widget.ProgressBar;

import com.bplusapp.Data.HJSONParsing;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Logger;

import java.util.HashMap;

public class AuthCommonTask extends AsyncTaskRunner
{

    public AuthCommonTask(Context context, IAsyncTaskRunner iasynctaskrunner, String s)
    {
        super(context, s, iasynctaskrunner);
    }

    public AuthCommonTask(Context context,String s,  IAsyncTaskRunner iasynctaskrunner,CustomLoadingDialog progressdialog)
    {
        super(context,s,progressdialog,iasynctaskrunner);
    }


    public AuthCommonTask(Context context, IAsyncTaskRunner iasynctaskrunner, String s, ProgressBar progressbar)
    {
        super(context, s, progressbar, iasynctaskrunner);
    }



    protected Object doInBackground(Object obj[])
    {
        ResultMessage resultmessage = new ResultMessage();
        resultmessage.STATUS = 0;
        if (BaseNetwork.obj().checkConnOnline(context)) {
            publishProgress(new Integer[]{
                    Integer.valueOf(1)
            });
            resultmessage.TYPE = urlString;
            HJSONParsing jsonParser = new HJSONParsing();
            resultmessage.RESPONSE = "";

            resultmessage.RESPONSE = BaseNetwork.obj().PostMethodWay(context, BaseNetwork.URL_HOST,urlString,(HashMap < Object, Object >) obj[0], BaseNetwork.obj().TimeOut);

                Logger.d("AuthLoginTask", (new StringBuilder("::")).append(resultmessage.RESPONSE).toString());
                if (!isTerminationRequest() && !TextUtils.isEmpty(resultmessage.RESPONSE)) {
                    String s = urlString;
                BaseNetwork.obj().getClass();
                if (!resultmessage.RESPONSE.equalsIgnoreCase("404")) {
                    if (!resultmessage.RESPONSE.equalsIgnoreCase("500")) {
                        if (!isTerminationRequest()) {
                            if(s.equalsIgnoreCase(BaseNetwork.REGISTER_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseRegisterMethod(context,resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.LOGIN_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseLoginMethod(context, resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.DEVICEID)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseDeviceIdMethod(context, resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.UPDATE_PROFILE_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseUserProfileMethod(context, resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.CHANGE_PASSWORD_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseChangePasswordMethod(context, resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.FORGET_PASS_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseForgotPasswordMethod(context, resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.FEEDS_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseFeedsMethod(context, resultmessage.RESPONSE,BaseNetwork.FEEDS_METHOD);
                            }else if(s.equalsIgnoreCase(BaseNetwork.REQUESTS_BY_USER_ID_METHOD)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseFeedsMethod(context, resultmessage.RESPONSE, BaseNetwork.REQUESTS_BY_USER_ID_METHOD);
                            }else if(s.equalsIgnoreCase(BaseNetwork.BLOOD_REQUEST_METHOD)){

                                resultmessage.RESULT_OBJECT = jsonParser.ParseConfirmBloodRequestMethod(context, resultmessage.RESPONSE);


                                //resultmessage.RESULT_OBJECT = jsonParser.ParseForgotPasswordMethod(context, resultmessage.RESPONSE);
                            }/*else if(s.equalsIgnoreCase(BaseNetwork.CONFIRM_REQUEST)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseForgotPasswordMethod(context, resultmessage.RESPONSE);
                            }*/else if(s.equalsIgnoreCase(BaseNetwork.ACCEPTED_REQUEST)){
                                //resultmessage.RESULT_OBJECT = jsonParser.ParseForgotPasswordMethod(context, resultmessage.RESPONSE);
                                resultmessage.RESULT_OBJECT = jsonParser.ParseFeedsMethod(context, resultmessage.RESPONSE, BaseNetwork.REQUESTS_BY_USER_ID_METHOD);
                            }else if(s.equalsIgnoreCase(BaseNetwork.GET_ALL_NOTIFICATIONS)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseAllNotificationMethod(context, resultmessage.RESPONSE);
                            }else if (s.equalsIgnoreCase(BaseNetwork.REQUEST_DESCRIPTION)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseNotificationDesriptionMethod(context, resultmessage.RESPONSE);
                            }else if (s.equalsIgnoreCase(BaseNetwork.CONFIRM_REQUEST)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseConfirmRequestMethod(context, resultmessage.RESPONSE);
                            }else if(s.equalsIgnoreCase(BaseNetwork.VIEW_MY_REQUEST_DETAIL)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseMyRequestDesriptionMethod(context, resultmessage.RESPONSE);

                            }else if(s.equalsIgnoreCase(BaseNetwork.CLOSE_REQUEST)){
                                resultmessage.RESULT_OBJECT = jsonParser.ParseCloseRequestMethod(context, resultmessage.RESPONSE);

                            }else if (s.equalsIgnoreCase(BaseNetwork.FILTER_REQUESETS)){

                                resultmessage.RESULT_OBJECT = jsonParser.ParseFeedsMethod(context, resultmessage.RESPONSE,BaseNetwork.FEEDS_METHOD);
                            }
                            resultmessage.STATUS = 200;
                        }


                    } else
                        resultmessage.STATUS = 500;
                } else
                    resultmessage.STATUS = 400;

            }
            }
            else
                resultmessage.STATUS = 500;

        return resultmessage;
    }

    protected void onPostExecute(Object obj)
    {
        super.onPostExecute(obj);

    }

    protected void onProgressUpdate(Integer ainteger[])
    {
        super.onProgressUpdate(ainteger);
    }

    protected void onProgressUpdate(Object aobj[])
    {
        onProgressUpdate((Integer[])aobj);
    }
}
