package com.bplusapp.Entity;

import java.util.ArrayList;

/**
 * Created by DEEPAK on 5/5/2016.
 */
public class MyRequestDescriptionDataClass {

    private int id;
    private String requesterName;
    private String userId;
    private String bloodGroup;
    private String requestedDate;
    private String hospitalName;
    private String hospitalAddr;
    private String country;
    private String city;
    private String zipCode;
    private String description;
    private String phone;
    private String lattitude;
    private String longitude;
    private String date;
    private String numberOfConfirmation;
    private ArrayList<ReceiverInfo> mReceiverInfos ;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRequesterName() {
        return requesterName;
    }

    public void setRequesterName(String requesterName) {
        this.requesterName = requesterName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(String requestedDate) {
        this.requestedDate = requestedDate;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getHospitalAddr() {
        return hospitalAddr;
    }

    public void setHospitalAddr(String hospitalAddr) {
        this.hospitalAddr = hospitalAddr;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLattitude() {
        return lattitude;
    }

    public void setLattitude(String lattitude) {
        this.lattitude = lattitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNumberOfConfirmation() {
        return numberOfConfirmation;
    }

    public void setNumberOfConfirmation(String numberOfConfirmation) {
        this.numberOfConfirmation = numberOfConfirmation;
    }

    public ArrayList<ReceiverInfo> getmReceiverInfos() {
        return mReceiverInfos;
    }

    public void setmReceiverInfos(ArrayList<ReceiverInfo> mReceiverInfos) {
        this.mReceiverInfos = mReceiverInfos;
    }
}
