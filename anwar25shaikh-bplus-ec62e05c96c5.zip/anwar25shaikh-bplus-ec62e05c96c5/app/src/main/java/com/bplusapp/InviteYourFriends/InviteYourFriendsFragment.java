package com.bplusapp.InviteYourFriends;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bplusapp.R;

/**
 * Created by Akash.Singh on 2/24/2016.
 */
public class InviteYourFriendsFragment extends Fragment{

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.content_invite_your_friend_screen, container, false);
        MidMapping(rootView);
        return rootView;
    }

    private void MidMapping(View rootView) {

    }
}
