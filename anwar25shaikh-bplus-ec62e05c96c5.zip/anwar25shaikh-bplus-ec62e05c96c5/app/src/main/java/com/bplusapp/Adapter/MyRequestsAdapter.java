package com.bplusapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.bplusapp.Entity.Feed;
import com.bplusapp.R;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.Utils.Utils;

import java.util.List;

/**
 * Created by DEEPAK on 5/4/2016.
 */
public class MyRequestsAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private List<Object> mObjectArrayList;

    public MyRequestsAdapter(Context context, List<Object> mObjectArrayList) {

        this.context = context;
        //inflater = LayoutInflater.from(this.context); Deepak comment and write below line

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        this.mObjectArrayList = mObjectArrayList ;
    }

    @Override
    public int getCount() {
        return mObjectArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mObjectArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        MyViewHolder mViewHolder;
        Feed feed = (Feed) mObjectArrayList.get(position);

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.myrequest_item, parent, false);
            mViewHolder = new MyViewHolder(convertView);
            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (MyViewHolder) convertView.getTag();
        }

        mViewHolder.text_location.setText(feed.getHospitalName());
        mViewHolder.text_address_location.setText(feed.getDate());
        mViewHolder.text_confirmation_location.setText(feed.getNumberOfConfirmation());
        mViewHolder.btn_blood_request.setText(feed.getBloodGroup());
        mViewHolder.btn_blood_request.setBackgroundDrawable(context.getResources().getDrawable(Utils.UseBloodGroupCode(feed.getBloodGroup())));


        return convertView;
    }

    private class MyViewHolder {
        CustomTextView text_location ,text_address_location, text_confirmation_location;
        CustomTextView btn_blood_request;


        public MyViewHolder(View item) {
            text_location = (CustomTextView) item.findViewById(R.id.text_location);
            text_address_location = (CustomTextView) item.findViewById(R.id.text_address_location);
            text_confirmation_location = (CustomTextView) item.findViewById(R.id.text_confirmation_location);
            btn_blood_request = (CustomTextView) item.findViewById(R.id.btn_blood_request);
        }
    }
}
