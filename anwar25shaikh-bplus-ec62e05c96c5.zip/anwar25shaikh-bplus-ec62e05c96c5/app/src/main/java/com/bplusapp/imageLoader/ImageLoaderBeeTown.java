package com.bplusapp.imageLoader;

/**
 * This class is used to set image in image view and View background
 * 
 * @author Akash Jain
 * 
 */

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import android.widget.ImageView;

import com.bplusapp.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class ImageLoaderBeeTown {
	static ImageLoaderBeeTown imageloader = null;
	private int stub_id;
	private final int REQUIRED_SIZE;

	public static ImageLoaderBeeTown getImageLoader(Context context) {
		if (imageloader == null) {
			imageloader = new ImageLoaderBeeTown(context);
		}
		return imageloader;
	}

	MemoryCache memoryCache = new MemoryCache();
	FileCache fileCache;
	private Map<ImageView, String> imageViews = Collections
			.synchronizedMap(new WeakHashMap<ImageView, String>());
	private Map<View, String> views = Collections
			.synchronizedMap(new WeakHashMap<View, String>());
	ExecutorService executorService;

	public ImageLoaderBeeTown(Context context) {
		fileCache = new FileCache(context);
		executorService = Executors.newFixedThreadPool(5);
		REQUIRED_SIZE=400;
	}

	public void displayImage(String url, ImageView imageView, int resId) {
		if(imageView==null)
			return;
		stub_id = resId;
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			imageView.setImageBitmap(bitmap);
		} else {
			imageViews.put(imageView, url);
			queuePhoto(url, imageView, false);
			if(stub_id!=0 && stub_id!=1)
				imageView.setImageResource(stub_id);
			else if(stub_id==1)
				imageView.setImageResource(R.color.white);
			else{

            }
				//imageView.setImageResource(R.drawable.white_lines);
		}
	}

	public void displayImage(String url, ImageView imageView,ImageView view, int resId) {
		stub_id = resId;
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			{
				imageView.setImageBitmap(bitmap);
				view.setImageBitmap(bitmap);
			}
		} else {
			imageViews.put(imageView, url);
			queuePhoto(url, imageView,view, false);
			if(stub_id!=0)
			{
				imageView.setImageResource(stub_id);
				view.setImageResource(stub_id);
			}
			else
			{
				imageView.setImageResource(R.color.white);
				view.setImageResource(R.color.white);
			}
		}
	}

	public void displayImage(String url, ImageView imageView, int resId,
			boolean isRoundmage) {
		stub_id = resId;
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			imageView.setImageBitmap(bitmap);
		} else {
			imageViews.put(imageView, url);
			queuePhoto(url, imageView, isRoundmage);
			imageView.setImageResource(stub_id);
		}
	}

	public void setDefault(int resId) {
		stub_id = resId;
	}

	private void queuePhoto(String url, ImageView imageView,
			boolean isRoundImage) {
		PhotoToLoad p = new PhotoToLoad(url, imageView,null, isRoundImage);
		executorService.submit(new PhotosLoader(p));
	}

	private void queuePhoto(String url, ImageView imageView,ImageView view,
			boolean isRoundImage) {
		PhotoToLoad p = new PhotoToLoad(url, imageView,view, isRoundImage);
		executorService.submit(new PhotosLoader(p));
	}

	public Bitmap getBitmap(String url, boolean isRound) {
		File f;
		f=new File(url);
		if(!f.exists())
			f= fileCache.getFile(url);


		// from SD cache
		Bitmap b = decodeFile(f, isRound,REQUIRED_SIZE);
		if (b != null)
			return b;

		// from web
		try {
			Bitmap bitmap = null;
			URL imageUrl = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) imageUrl
					.openConnection();
			conn.setConnectTimeout(30000);
			conn.setReadTimeout(30000);
			conn.setInstanceFollowRedirects(true);
			InputStream is = conn.getInputStream();
			OutputStream os = new FileOutputStream(f);
			Utils.CopyStream(is, os);
			os.close();
			bitmap = decodeFile(f, isRound,REQUIRED_SIZE);

			return bitmap;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	// decodes image and scales it to reduce memory consumption
	public Bitmap decodeFile(File f, boolean isRoundImage,int size) {
		try {
			// decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;

			BitmapFactory.decodeStream(new FileInputStream(f), null, o);


			// decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			if (isRoundImage) {
				return getRoundedCornerImage(BitmapFactory.decodeStream(
						new FileInputStream(f), null, o2));
			} else {
				return BitmapFactory.decodeStream(new FileInputStream(f), null,
						o2);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	private Bitmap getRoundedCornerImage(Bitmap bitmap) {
		try {
			Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
					bitmap.getHeight(), Config.ARGB_8888);
			Canvas canvas = new Canvas(output);

			final int color = 0xff424242;
			final Paint paint = new Paint();
			final Rect rect = new Rect(0, 0, bitmap.getWidth(),
					bitmap.getHeight());
			final RectF rectF = new RectF(rect);
			final float roundPx = 100;
			paint.setAntiAlias(true);
			canvas.drawARGB(0, 0, 0, 0);
			paint.setColor(color);
			canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
			paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
			canvas.drawBitmap(bitmap, rect, rect, paint);
			return output;
		} catch (Exception e) {
			return null;
		}
	}

	// Task for the queue
	private class PhotoToLoad {
		public String url;
		public ImageView imageView,mView;
		public boolean isRoundImage;

		public PhotoToLoad(String u, ImageView i, ImageView view, boolean imageRound) {
			url = u;
			imageView = i;
			isRoundImage = imageRound;
			mView=view;
		}
	}

	class PhotosLoader implements Runnable {
		PhotoToLoad photoToLoad;

		PhotosLoader(PhotoToLoad photoToLoad) {
			this.photoToLoad = photoToLoad;
		}

		@Override
		public void run() {
			if (imageViewReused(photoToLoad))
				return;
			Bitmap bmp = getBitmap(photoToLoad.url, photoToLoad.isRoundImage);
			memoryCache.put(photoToLoad.url, bmp);
			if (imageViewReused(photoToLoad))
				return;
			if (bmp != null) {
				BitmapDisplayer bd = new BitmapDisplayer(bmp, photoToLoad);
				Activity a = (Activity) photoToLoad.imageView.getContext();
				a.runOnUiThread(bd);
			}
		}
	}

	boolean imageViewReused(PhotoToLoad photoToLoad) {
		String tag = imageViews.get(photoToLoad.imageView);
		if (tag == null || !tag.equals(photoToLoad.url))
			return true;
		return false;
	}

	// Used to display bitmap in the UI thread
	class BitmapDisplayer implements Runnable {
		Bitmap bitmap;
		PhotoToLoad photoToLoad;

		public BitmapDisplayer(Bitmap b, PhotoToLoad p) {
			bitmap = b;
			photoToLoad = p;
		}

		public void run() {
			if (imageViewReused(photoToLoad))
				return;
			if (bitmap != null) {
				{
					if(photoToLoad.mView!=null)
						photoToLoad.mView.setImageBitmap(bitmap);
					photoToLoad.imageView.setImageBitmap(bitmap);
				}
			} else
			{
				if(photoToLoad.mView!=null)
					photoToLoad.mView.setImageResource(stub_id);
				photoToLoad.imageView.setImageResource(stub_id);
			}
		}
	}

	public void clearCache() {
		memoryCache.clear();
		fileCache.clear();
	}

	@SuppressLint("NewApi") public void displayBackgroundImage( String url, View view) {
		stub_id = R.drawable.logo;
		views.put(view, url);
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			/*Drawable drawable=RoundedDrawable.fromBitmap(bitmap);
			if(VERSION.SDK_INT<VERSION_CODES.JELLY_BEAN)
			{
				view.setBackgroundDrawable(drawable);
			}
			else
			{
				view.setBackground(drawable);
			}*/
		} else {
			queuePhoto(view,url, false);
			if(stub_id!=0)
			{
				view.setBackgroundResource(stub_id);
			}
			else
			{
				view.setBackgroundResource(R.color.white);
			}
		}
	}

	private void queuePhoto(View view,String url,
			boolean isRoundImage) {
		LoadBackGroundPhoto p = new LoadBackGroundPhoto(url, view, isRoundImage);
		executorService.submit(new PhotoLoader(p));
	}

	class PhotoLoader implements Runnable {
		LoadBackGroundPhoto photoLoad;

		PhotoLoader(LoadBackGroundPhoto photoToLoad) {
			this.photoLoad = photoToLoad;
		}

		@Override
		public void run() {
			if (imageViewReused(photoLoad))
				return;
			Bitmap bmp = getBitmap(photoLoad.url, photoLoad.isRoundImage);
			memoryCache.put(photoLoad.url, bmp);
			if (imageViewReused(photoLoad))
				return;
			if (bmp != null) {
				BitmapDrawableDisplayer bd = new BitmapDrawableDisplayer(bmp, photoLoad);
				Activity a = (Activity) photoLoad.mView.getContext();
				a.runOnUiThread(bd);
			} 
		}
	}

	@SuppressLint("NewApi") class BitmapDrawableDisplayer implements Runnable {
		Bitmap bitmap;
		LoadBackGroundPhoto loadPhoto;

		public BitmapDrawableDisplayer(Bitmap b, LoadBackGroundPhoto p) {
			bitmap = b;
			loadPhoto = p;
		}

		public void run() {
			if (imageViewReused(loadPhoto))
				return;
			if (bitmap != null) {
				/*Drawable drawable=RoundedDrawable.fromBitmap(bitmap);
				if(VERSION.SDK_INT<VERSION_CODES.JELLY_BEAN)
				{
					loadPhoto.mView.setBackgroundDrawable(drawable);
				}
				else
				{
					loadPhoto.mView.setBackground(drawable);
				}*/
			} else
			{
				loadPhoto.mView.setBackgroundResource(stub_id);
			}
		}
	}
	private class LoadBackGroundPhoto {
		public String url;
		public View mView;
		public boolean isRoundImage;

		public LoadBackGroundPhoto(String u, View view, boolean imageRound) {
			url = u;
			mView = view;
			isRoundImage = imageRound;
		}
	}
	boolean imageViewReused(LoadBackGroundPhoto photoToLoad) {
		String tag = views.get(photoToLoad.mView);
		if (tag == null || !tag.equals(photoToLoad.url))
			return true;
		return false;
	}
}