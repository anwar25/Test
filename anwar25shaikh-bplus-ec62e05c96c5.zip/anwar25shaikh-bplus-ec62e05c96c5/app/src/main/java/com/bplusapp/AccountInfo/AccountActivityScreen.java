package com.bplusapp.AccountInfo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Logger;
import com.bplusapp.Utils.TextUtility;
import com.bplusapp.Utils.Utils;
import com.bplusapp.fcm.RegisterToken;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookAuthorizationException;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.internal.ImageRequest;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.plus.People;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;

public class AccountActivityScreen extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener,IAsyncTaskRunner,IDialogClick {
    EditText search_edit_frame,edit_search_country;
    GoogleApiClient mGoogleApiClient;
    CustomLoadingDialog customLoadingDialog ;
    int RC_SIGN_IN = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        GenerateFaceBookAPI();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_info_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        GenerateGoogleAPI();
        search_edit_frame = (EditText) findViewById(R.id.search_edit_frame);
        edit_search_country = (EditText) findViewById(R.id.edit_search_country);
        if(getIntent().getExtras().getInt(StaticConstant.FRAGMENT_TYPE)==0)
            onReplaceFragment(new SignInFragment(), false);
        else
            onReplaceFragment(new UpdateProfileFragment(), false);

        if(mayRequestPhonePermission()){
          //  ApplicationContainer.getInstance().registerGCMService();
        };
    }

    private void GenerateGoogleAPI() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
             //   .requestScopes(new Scope(Scopes.PROFILE))
             //   .requestScopes(new Scope(Scopes.PLUS_LOGIN))
                .requestProfile()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .addApi(Plus.API)
                .build();
    }
    CallbackManager mCallbackManager;
    private void GenerateFaceBookAPI() {

        FacebookSdk.sdkInitialize(this.getApplicationContext());

        mCallbackManager = CallbackManager.Factory.create();


        LoginManager.getInstance().registerCallback(mCallbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        Logger.d("Success", "Login" + "::" + loginResult.getAccessToken());
                        GetFacebookLogin(loginResult);
                    }
                    @Override
                    public void onCancel() {
                        Toast.makeText(AccountActivityScreen.this, "Login Cancel", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        if (exception instanceof FacebookAuthorizationException) {
                            if (AccessToken.getCurrentAccessToken() != null) {
                                LoginManager.getInstance().logOut();
                            }
                        }
                        Toast.makeText(AccountActivityScreen.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

    }

    private void GetFacebookLogin(LoginResult loginResult) {
        GraphRequest request = GraphRequest.newMeRequest(
                loginResult.getAccessToken(),
                new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(
                            JSONObject object,
                            GraphResponse response) {
                        // Application code
                        Logger.v("LoginActivity", response.toString());
                        if(object!=null) {
                            Logger.d("JSONObject", "::" + object.toString());
                            try {
                                JSONObject jsonObject = new JSONObject(object.toString());
                                UserInfo userInfo = new UserInfo();
                                if (jsonObject.has(StaticConstant.FB_ID)) ;
                                userInfo.setAuthId(jsonObject.getString(StaticConstant.FB_ID));
                                if(jsonObject.has(StaticConstant.FB_PROFILE_IMAGE)){
                                    userInfo.setProfile_image(jsonObject.getString(StaticConstant.FB_PROFILE_IMAGE));
                                }
                                String profileImageUrl = ImageRequest.getProfilePictureUri(object.optString("id"), 500, 500).toString();

                                if (jsonObject.has(StaticConstant.FB_NAME)) ;
                                {
                                    String FirstName = jsonObject.getString(StaticConstant.FB_NAME);
                                    if (!TextUtils.isEmpty(FirstName)) {
                                        String[] Name = FirstName.split(" ");
                                        try {
                                            if (Name.length > 0) {
                                                userInfo.setUserFName(Name[0]);
                                                if (Name.length > 1)
                                                    userInfo.setUserLName(Name[1]);
                                            }
                                        } catch (Exception e) {
                                            FirstName = jsonObject.getString(StaticConstant.FB_NAME);
                                            userInfo.setUserFName(FirstName);
                                        }

                                    }
                                }
                                if (jsonObject.has(StaticConstant.FB_EMAIL)) ;
                                userInfo.setUserEmail(jsonObject.getString(StaticConstant.FB_EMAIL));
                                PerformSignInProcess(userInfo.getUserEmail(),"",userInfo.getUserFName() ,userInfo.getUserLName(),userInfo.getAuthId(), "Facebook", profileImageUrl);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,gender, birthday,link");
        request.setParameters(parameters);
        request.executeAsync();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppEventsLogger.activateApp(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        AppEventsLogger.deactivateApp(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Logger.d("cek", "home selected");
        switch (item.getItemId()) {
            case android.R.id.home:
                    onBackPressed();
                    return true;
            case R.id.action_filter:
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onReplaceFragment(Fragment fragment, boolean flag) {
        FragmentManager fragmentmanager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentmanager.beginTransaction();
        String backStateName = fragment.getClass().getName();
        if (flag) {
            String s = fragmentmanager.getClass().getName();
            if (!fragmentmanager.popBackStackImmediate(s, 0)) {
                fragmentTransaction.replace(R.id.container, fragment, backStateName);
                fragmentTransaction.addToBackStack(s);
                fragmentTransaction.commit();
            }
            return;
        } else {
            fragmentTransaction.replace(R.id.container, fragment, backStateName);
            fragmentTransaction.commit();
            return;
        }
    }


    public void SetToolbarInitialization(Fragment fragment,String title){
        setTitle(title);
        if(fragment instanceof SignInFragment) {
            edit_search_country.setVisibility(View.GONE);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        else if(fragment instanceof SignUpFragment) {
            edit_search_country.setVisibility(View.GONE);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        else if(fragment instanceof UpdateProfileFragment) {
            edit_search_country.setVisibility(View.GONE);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        else if(fragment instanceof ForgotPasswordFragment) {
            edit_search_country.setVisibility(View.GONE);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        } else if(fragment instanceof ChangeCountry) {
            edit_search_country.setVisibility(View.VISIBLE);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }


    @Override
    public void onBackPressed() {
        InputMethodManager mgr = (InputMethodManager)
                getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(search_edit_frame.getWindowToken(), 0);

        FragmentManager fm = getSupportFragmentManager();
            Fragment fragment = fm.findFragmentById(R.id.container);
            if (fm.getBackStackEntryCount() > 0) {
                fm.popBackStack();
            } else {
                if(getIntent().getExtras().getInt(StaticConstant.FRAGMENT_TYPE)==0){
                    if (fragment instanceof SignInFragment) {
                        super.onBackPressed();
                    } else
                        onReplaceFragment(new SignInFragment(),false);
                }
                else{
                    if (fragment instanceof UpdateProfileFragment) {
                        super.onBackPressed();
                    } else
                        onReplaceFragment(new UpdateProfileFragment(),false);
                }

            }


    }


    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {

            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            Logger.d("result","1:"+result.getStatus());
            Logger.d("result","2:"+result.getSignInAccount());
            if (result.isSuccess()) {
                final UserInfo userInfo =  new UserInfo();
                GoogleSignInAccount acct = result.getSignInAccount();
                userInfo.setAuthId(acct.getId());
                String FirstName = acct.getDisplayName();
                final String mail = acct.getEmail();
                final Uri photoUri = acct.getPhotoUrl();
                if (!TextUtils.isEmpty(FirstName)) {
                    String[] Name = FirstName.split(" ");
                    try {
                        if (Name.length > 0) {
                            userInfo.setUserFName(Name[0]);
                            if (Name.length > 1)
                                userInfo.setUserLName(Name[1]);
                        }
                    } catch (Exception e) {
                        FirstName = acct.getDisplayName();
                        userInfo.setUserFName(FirstName);
                    }

                }

               /* Person person  = Plus.PeopleApi.getCurrentPerson(mGoogleApiClient);
                if(person != null){
                    String URL = person.getImage().getUrl();
                    PerformSignInProcess(mail, "", userInfo.getUserFName(), userInfo.getUserLName(), userInfo.getAuthId(), "Google", URL);
                }*/
                Plus.PeopleApi.load(mGoogleApiClient, acct.getId()).setResultCallback(new ResultCallback<People.LoadPeopleResult>() {
                    @Override
                    public void onResult(@NonNull People.LoadPeopleResult loadPeopleResult) {
                        if(loadPeopleResult.getPersonBuffer() != null){
                            Person person = loadPeopleResult.getPersonBuffer().get(0);
                       /* String TAG = "anwar";
                        Log.d(TAG,"Person loaded");
                        Log.d(TAG,"GivenName "+person.getName().getGivenName());
                        Log.d(TAG,"FamilyName "+person.getName().getFamilyName());
                        Log.d(TAG,("DisplayName "+person.getDisplayName()));
                        Log.d(TAG,"Gender "+person.getGender());
                        Log.d(TAG,"Url "+person.getUrl());
                        Log.d(TAG,"CurrentLocation "+person.getCurrentLocation());
                        Log.d(TAG,"AboutMe "+person.getAboutMe());
                        Log.d(TAG,"Birthday "+person.getBirthday());
                        Log.d(TAG,"Image "+person.getImage().getUrl());*/
                            if(customLoadingDialog!=null && customLoadingDialog.isShowing())
                                customLoadingDialog.dismiss();

                            if(person != null)
                                PerformSignInProcess(mail, "", userInfo.getUserFName(), userInfo.getUserLName(), userInfo.getAuthId(), "Google", person.getImage().getUrl());
                        }else{
                            if(photoUri != null){
                                PerformSignInProcess(mail, "", userInfo.getUserFName(), userInfo.getUserLName(), userInfo.getAuthId(), "Google", photoUri.toString());
                            }else{
                                PerformSignInProcess(mail, "", userInfo.getUserFName(), userInfo.getUserLName(), userInfo.getAuthId(), "Google", "");
                            }

                        }
                    }
                });
            }
            else if(result!=null && !TextUtils.isEmpty(result.getStatus().getStatusMessage()))
                Utils.showToast(this,result.getStatus().getStatusMessage());
            else
                Utils.showToast(this,"Login Error");

            if(customLoadingDialog!=null && customLoadingDialog.isShowing())
                customLoadingDialog.dismiss();
        }else {
            super.onActivityResult(requestCode, resultCode, data);
            mCallbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

   public void GoogleSignInProcess(){
       Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
       startActivityForResult(signInIntent, RC_SIGN_IN);
       if(customLoadingDialog==null) {
           customLoadingDialog = new CustomLoadingDialog(AccountActivityScreen.this);
           customLoadingDialog.show();
       }

       customLoadingDialog.setTitle("Sign Process,Loading...");
    }

    public void FaceBookSignInProcess(){
           LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "user_friends","email","user_birthday","user_photos"));
    }


    CustomLoadingDialog loadingDialog;
    AuthCommonTask authCommonTask;
    public void PerformSignInProcess(String EmailAddress,String EditPassword,String FirstName,String LastName,String AuthId,String AuthBy , String profile_pic) {
        loadingDialog =  new CustomLoadingDialog(AccountActivityScreen.this);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(StaticConstant.FNAME,FirstName);
        hashMap.put(StaticConstant.LNAME, LastName);
        hashMap.put(StaticConstant.USER_EMAIL,EmailAddress);
        hashMap.put(StaticConstant.USER_PASSWORD, EditPassword);
        hashMap.put(StaticConstant.USER_AUTH_ID,AuthId);
        hashMap.put(StaticConstant.USER_AUTH_BY,AuthBy);
        hashMap.put(StaticConstant.DEVICE_ID,Utils.DeviceID(this));
        hashMap.put(StaticConstant.USER_PROFILE_PIC,profile_pic);
        authCommonTask =  new AuthCommonTask(AccountActivityScreen.this, BaseNetwork.LOGIN_METHOD,this,loadingDialog);
        authCommonTask.execute(hashMap);
    }

    public void performDeviceIdSendProcess(String deviceId, String deviceToken, String deviceType, String latitude, String longitude, String userId){
        loadingDialog =  new CustomLoadingDialog(AccountActivityScreen.this);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(StaticConstant.DEVICETOKEN, deviceToken);
        hashMap.put(StaticConstant.DEVICETYPE,deviceType);
        hashMap.put(StaticConstant.LATTITUDE, latitude);
        hashMap.put(StaticConstant.LONGITUDE,longitude);
        hashMap.put(StaticConstant.USERID,userId);
        hashMap.put(StaticConstant.DEVICE_ID,deviceId);
        authCommonTask =  new AuthCommonTask(AccountActivityScreen.this, BaseNetwork.DEVICEID,this,loadingDialog);
        authCommonTask.execute(hashMap);

    }


    public void PerformForgotPasswordProcess(String EmailAddress) {
        loadingDialog =  new CustomLoadingDialog(AccountActivityScreen.this);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(StaticConstant.USER_EMAIL,EmailAddress);
        authCommonTask =  new AuthCommonTask(AccountActivityScreen.this, BaseNetwork.FORGET_PASS_METHOD,this,loadingDialog);
        authCommonTask.execute(hashMap);
    }

    public void PerformSignUpProcess(String FirstName,String LastName,String EmailAddress,String EditPassword){
        loadingDialog =  new CustomLoadingDialog(AccountActivityScreen.this);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(StaticConstant.FNAME,FirstName);
        hashMap.put(StaticConstant.LNAME,LastName);
        hashMap.put(StaticConstant.USER_EMAIL,EmailAddress);
        hashMap.put(StaticConstant.USER_PASSWORD,EditPassword);
        hashMap.put(StaticConstant.USER_AUTH_ID,"");
        hashMap.put(StaticConstant.USER_AUTH_BY,"");
        hashMap.put(StaticConstant.DEVICE_ID,Utils.DeviceID(this));
        authCommonTask =  new AuthCommonTask(AccountActivityScreen.this, BaseNetwork.REGISTER_METHOD,this,loadingDialog);
        authCommonTask.execute(hashMap);
    }

    public void PerformUpdateProfileProcess(String userid,String bloodGroup,String address,String country,String state,String city,String zipcode,String phone){
        loadingDialog =  new CustomLoadingDialog(AccountActivityScreen.this);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(StaticConstant.USER_ID,userid);
        hashMap.put(StaticConstant.BLOOD_GROUP,bloodGroup);
        hashMap.put(StaticConstant.ADDRESS,address);
        hashMap.put(StaticConstant.COUNTRY,country);
        hashMap.put(StaticConstant.CITY,city);
        hashMap.put(StaticConstant.STATE,state);
        hashMap.put(StaticConstant.ZIPCODE,zipcode);
        hashMap.put(StaticConstant.PHONE,phone);
        authCommonTask =  new AuthCommonTask(AccountActivityScreen.this, BaseNetwork.UPDATE_PROFILE_METHOD,this,loadingDialog);
        authCommonTask.execute(hashMap);
    }

    @Override
    public Context getContext() {
        return AccountActivityScreen.this;

    }

    @Override
    public void taskCompleted(Object obj) {
        if(obj!=null){
            ResultMessage resultMessage = (ResultMessage) obj;
            if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.REGISTER_METHOD)){
                ResponseMessage responseMessage = (ResponseMessage) resultMessage.RESULT_OBJECT;
                if(responseMessage.getStatus()==1)
                    Utils.ShowAlertDialog(AccountActivityScreen.this, responseMessage.getMessage(), this,new SignUpFragment());
                else if(responseMessage.getStatus() == 0)
                    Utils.ShowAlertDialog(AccountActivityScreen.this, responseMessage.getMessage(), this,null);

            }else if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.LOGIN_METHOD)){
                UserInfo userInfo  = (UserInfo) resultMessage.RESULT_OBJECT;
                if(userInfo.getSuccess()==1){
                    // call firebase to generate token

                    ;
                    PreHelper.storeNotificationCount(AccountActivityScreen.this,userInfo.getTotalNotifications());
                    Utils.showToast(AccountActivityScreen.this, userInfo.getMessage());
                    if(TextUtils.isEmpty(TextUtility.checkIsStringEmpty(userInfo.getUserBloodGroup()))){
                        onReplaceFragment(new UpdateProfileFragment(), true);
                    }else{
                        // Deepak Code
                        performDeviceIdSendProcess(Utils.DeviceID(AccountActivityScreen.this), PreHelper.getRegId(AccountActivityScreen.this),"Android","28.4595","77.0266",userInfo.getUserId());
                    }
                    if(FirebaseInstanceId.getInstance().getToken() != null){
                        RegisterToken.sendRegistrationTokenToServer(this,FirebaseInstanceId.getInstance().getToken());
                    }
                }
                else if(userInfo.getSuccess() == 0)
                    Utils.ShowAlertDialog(AccountActivityScreen.this, userInfo.getMessage(), this,null);


            }
            else if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.UPDATE_PROFILE_METHOD)){
                UserInfo userInfo  = (UserInfo) resultMessage.RESULT_OBJECT;
                if(userInfo.getSuccess()==1) {
                    performDeviceIdSendProcess(Utils.DeviceID(AccountActivityScreen.this), PreHelper.getRegId(AccountActivityScreen.this),"Android","28.4595","77.0266",userInfo.getUserId());
                    Utils.showToast(AccountActivityScreen.this, userInfo.getMessage());
                }
                else if(userInfo.getSuccess() == 0)
                    Utils.ShowAlertDialog(AccountActivityScreen.this, userInfo.getMessage(), this,null);

            }else if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.DEVICEID)){

                UserInfo userInfo  = (UserInfo) resultMessage.RESULT_OBJECT;
                if(userInfo.getSuccess()==1) {
                    //Utils.showToast(AccountActivityScreen.this, userInfo.getMessage());
                }
                Intent intent = new Intent(AccountActivityScreen.this, BaseActivityScreen.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();

            }

        }

    }

    @Override
    public void taskErrorMessage(Object obj) {
        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
            Utils.ShowAlertDialog(AccountActivityScreen.this, resultMessage.ERRORMESSAGE, this, null);

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    public void onCancelFragment(){

        if(authCommonTask!=null)
        {
            if(!authCommonTask.isCancelled())
                authCommonTask.cancel(true);
        }
    }

    @Override
    public void OnClickListener(Fragment fragment) {
        if(fragment!=null){
            if(fragment instanceof SignUpFragment)
                onBackPressed();
            else
                onReplaceFragment(fragment, false);
        }
    }

    private final int REQUEST_PHONE_STATE_PERMISSION = 4;

    private boolean mayRequestPhonePermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(Manifest.permission.READ_PHONE_STATE)) {
            Toast.makeText(this, getString(R.string.phone_permission_rationale_location)
                    , Toast.LENGTH_LONG).show();
            requestPermissions(new String[]{android.Manifest.permission.READ_PHONE_STATE}, REQUEST_PHONE_STATE_PERMISSION);
            return false;
        } else {
            requestPermissions(new String[]{android.Manifest.permission.READ_PHONE_STATE}, REQUEST_PHONE_STATE_PERMISSION);
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_PHONE_STATE_PERMISSION) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Anwar code
             //   ApplicationContainer.getInstance().registerGCMService();
               // redirect();
            } else {
                Toast.makeText(this, getString(R.string.phone_permission_required_toast), Toast.LENGTH_LONG).show();
            }
        }
    }
}
