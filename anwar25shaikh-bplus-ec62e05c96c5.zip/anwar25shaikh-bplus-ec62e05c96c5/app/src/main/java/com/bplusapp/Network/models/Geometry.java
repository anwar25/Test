package com.bplusapp.Network.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Anwar on 8/4/2016.
 */
public class Geometry {

    @SerializedName("location")
    @Expose
    private HospitalLocation location;

    /**
     *
     * @return
     * The location
     */
    public HospitalLocation getLocation() {
        return location;
    }

    /**
     *
     * @param location
     * The location
     */
    public void setLocation(HospitalLocation location) {
        this.location = location;
    }

}