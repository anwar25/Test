package com.bplusapp.Storage;

import android.content.Context;

import com.bplusapp.R;

/**
 * Created by Akash.Singh on 7/29/2015.
 */
public class CountryStorage extends JSONStorage {
    public CountryStorage(Context context) {
        super(context);
    }

    @Override
    public void setFileName() {
        FILE_NAME = "country";
        mAssetsFileID = R.raw.country;

    }
}