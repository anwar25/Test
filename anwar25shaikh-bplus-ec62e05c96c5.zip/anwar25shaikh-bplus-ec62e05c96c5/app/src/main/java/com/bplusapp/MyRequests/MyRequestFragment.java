package com.bplusapp.MyRequests;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bplusapp.Adapter.MyNotificationAdapter;
import com.bplusapp.Adapter.MyRequestsAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.AllNotificationDataClass;
import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Interface.IFragmentLifeCycle;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/**
 * Created by Akash.Singh on 1/5/2016.
 */
public class MyRequestFragment extends Fragment implements IFragmentLifeCycle,IAsyncTaskRunner,IDialogClick{

    private ListView list_view_my_requests;
    private MyRequestsAdapter myRequestsAdapter;
    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;
    private  ArrayList<Object> mObjectArrayList ;
    private TextView tv_empty;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_requests_screen,container,false);

        list_view_my_requests = (ListView) view.findViewById(R.id.list_view_my_requests);
        tv_empty = (TextView) view.findViewById(R.id.tv_empty);
        performMyRequestsProcess();

        return view;
    }

    @Override
    public void onActivityCreated( Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        list_view_my_requests.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                         MyRequestDetailFragment myRequestDetailFragment = new MyRequestDetailFragment();
                         Bundle bundle = new Bundle();
                         Feed feed = (Feed)parent.getAdapter().getItem(position);
                         bundle.putString("requestId", String.valueOf(feed.getId()));
                         myRequestDetailFragment.setArguments(bundle);
                        ((BaseActivityScreen) getActivity()).onReplaceFragment(myRequestDetailFragment, true);


            }
        });
    }

    private void performMyRequestsProcess() {

        loadingDialog =  new CustomLoadingDialog(getActivity());
        authCommonTask =  new AuthCommonTask(getActivity(), BaseNetwork.REQUESTS_BY_USER_ID_METHOD,this,loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("userId", ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
        authCommonTask.execute(hashMap);
    }


    @Override
    public void onPauseFragment() {

    }

    @Override
    public void onResumeFragment() {

    }

    @Override
    public void taskCompleted(Object obj) {

        if(obj!=null){
            ResultMessage resultMessage = (ResultMessage) obj;
            if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.REQUESTS_BY_USER_ID_METHOD)){
                ResponseMessage responseMessage  = (ResponseMessage)resultMessage.RESULT_OBJECT;
                mObjectArrayList = responseMessage.getObjectArrayList();
                try {
                    myRequestsAdapter = new MyRequestsAdapter(getActivity(), mObjectArrayList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                list_view_my_requests.setAdapter(myRequestsAdapter);

                if(mObjectArrayList.size() == 0){
                    //Toast.makeText(getActivity(), "No Request Found", Toast.LENGTH_SHORT).show();
                    tv_empty.setVisibility(View.VISIBLE);
                }else {
                    tv_empty.setVisibility(View.INVISIBLE);
                }
            }
        }

    }

    @Override
    public void taskErrorMessage(Object obj) {
        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null){
            //Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);
        }


    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }
}
