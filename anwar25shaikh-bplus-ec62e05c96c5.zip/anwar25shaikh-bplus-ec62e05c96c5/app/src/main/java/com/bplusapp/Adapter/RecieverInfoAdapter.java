package com.bplusapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.bplusapp.Entity.MyRequestDescriptionDataClass;
import com.bplusapp.R;
import com.bplusapp.loader.ImageLoader;

import java.util.List;

/**
 * Created by DEEPAK on 5/6/2016.
 */
public class RecieverInfoAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private List<MyRequestDescriptionDataClass> myRequestDescriptionDataClasses ;
    private boolean showSelector ;
    private ImageLoader imageLoader;
    private RadioButton mSelectedRB;
    private int mSelectedPosition = -1;

    public RecieverInfoAdapter(Context context, List<MyRequestDescriptionDataClass> myRequestDescriptionDataClasses,boolean showSelector) {
        this.context = context;
        this.myRequestDescriptionDataClasses = myRequestDescriptionDataClasses;
        imageLoader = new ImageLoader(context);
        inflater = LayoutInflater.from(this.context);
        this.showSelector = showSelector ;
    }

    @Override
    public int getCount() {
        return myRequestDescriptionDataClasses.get(0).getmReceiverInfos().size();
    }

    @Override
    public Object getItem(int position) {
        return myRequestDescriptionDataClasses.get(0).getmReceiverInfos().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        MyViewHolder mViewHolder;
        if (convertView == null) {
          //  android.R.layout.simple_list_item_single_choice;
           // convertView = inflater.inflate(R.layout.row_reciever_info, parent, false);
            convertView = inflater.inflate(R.layout.single_choice_row, parent, false);
            mViewHolder = new MyViewHolder(convertView);
            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (MyViewHolder) convertView.getTag();
        }


     /*   mViewHolder.radioBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(position != mSelectedPosition && mSelectedRB != null){
                    mSelectedRB.setChecked(false);
                }

                mSelectedPosition = position;
                mSelectedRB = (RadioButton)v;
            }
        });

        if(mSelectedPosition != position){
            mViewHolder.radioBtn.setChecked(false);
        }else{
            mViewHolder.radioBtn.setChecked(true);
            if(mSelectedRB != null && mViewHolder.radioBtn != mSelectedRB){
                mSelectedRB = mViewHolder.radioBtn;
            }
        }*/

        mViewHolder.tv_reciever.setText(myRequestDescriptionDataClasses.get(0).getmReceiverInfos().get(position).getUser_name());

        imageLoader.DisplayImage( myRequestDescriptionDataClasses.get(0).getmReceiverInfos().get(position).getUser_image(), mViewHolder.iv_reciever);

        return convertView;
    }

    private class MyViewHolder {
        TextView tv_reciever ;
        com.bplusapp.UI.CircleImageView iv_reciever ;
        ImageView radioBtn ;

        public MyViewHolder(View item) {
            tv_reciever = (TextView) item.findViewById(R.id.tv_reciever);
            iv_reciever = (com.bplusapp.UI.CircleImageView) item.findViewById(R.id.iv_reciever);
            radioBtn = (ImageView) item.findViewById(R.id.radioButton) ;
            if(!showSelector){
                radioBtn.setVisibility(View.GONE);
            }
        }
    }
}
