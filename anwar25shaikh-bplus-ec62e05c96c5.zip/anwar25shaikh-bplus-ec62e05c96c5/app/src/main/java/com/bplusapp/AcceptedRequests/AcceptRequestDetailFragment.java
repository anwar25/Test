package com.bplusapp.AcceptedRequests;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.Feed;
import com.bplusapp.R;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.Utils.Utils;
import com.bplusapp.loader.ImageLoaderRect;

/**
 * Created by Akash.Singh on 1/20/2016.
 */
public class AcceptRequestDetailFragment extends Fragment{

    CustomTextView text_blood_group,text_hospital_name,requester_name,requester_date_time,requester_phone,text_hospitalAddress;
    Feed feed;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_accept_request_detail_screen,container,false);
        feed = (Feed) getArguments().getSerializable("Feed");

        ((BaseActivityScreen)getActivity()).SetToolbarInitialization(this,feed.getBloodGroup());
        WidgetMapping(view);
        return view;
    }

    private void WidgetMapping(View view) {
        text_blood_group = (CustomTextView) view.findViewById(R.id.text_blood_group);
        text_hospital_name = (CustomTextView) view.findViewById(R.id.text_hospital_name);
        requester_name = (CustomTextView) view.findViewById(R.id.requester_name);
        requester_date_time = (CustomTextView) view.findViewById(R.id.requester_date_time);
        requester_phone = (CustomTextView) view.findViewById(R.id.requester_phone);
        text_hospitalAddress = (CustomTextView) view.findViewById(R.id.text_hospitalAddress);

        SetFeedValue();

        ImageLoaderRect imageLoader =  new ImageLoaderRect(getActivity());
        String URL = "https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=600x250&" +
                "sensor=false&maptype=roadmap&markers=color:0xff6600%7C"+feed.getLattitude() +","+feed.getLongitude()+"&key="+getString(R.string.google_maps_key);
        //imageLoader.DisplayImage(URL, ((ImageView) view.findViewById(R.id.img_map)));
    }

    private void SetFeedValue() {
        text_blood_group.setBackground(getActivity().getResources().getDrawable(Utils.UseBloodGroupCode(feed.getBloodGroup())));
        text_blood_group.setText(feed.getBloodGroup());
        requester_name.setText(feed.getpName());
        text_hospital_name.setText("Urgent Requirement at "+feed.getHospitalName());
        requester_date_time.setText(Utils.ConvertDateFormat(feed.getDate()));
        text_hospitalAddress.setText(feed.getHospitalAddr());
        requester_phone.setText(feed.getPhone());
    }
}
