package com.bplusapp.imageLoader;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.Log;
import android.widget.ImageView;

import com.bplusapp.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class ImageLoader {

	MemoryCache memoryCache = new MemoryCache();
	FileCache fileCache;
	private Map<ImageView, String> imageViews = Collections
			.synchronizedMap(new WeakHashMap<ImageView, String>());
	ExecutorService executorService;
	private Context context;
	private static ImageLoader instance;
	private int stub_id2;
	private boolean isRounded = false;

	public ImageLoader(Context context) {
		fileCache = new FileCache(context);
		executorService = Executors.newFixedThreadPool(5);
		this.context = context;
	}

	public static ImageLoader getInstance(Activity context) {
		if (instance == null || instance.context == null) {
			instance = new ImageLoader(context);
		}
		return instance;
	}

	final int stub_id = R.drawable.logo;

	public void DisplayBanner(String url, ImageView imageView, int height,
			int width) {
		imageViews.put(imageView, url);
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			imageView.setImageBitmap(bitmap);
		} else {
			queuePhoto(url, imageView);
			imageView.setImageResource(stub_id);
		}
	}

	final int stub_id_event = R.drawable.logo;
	public void DisplayBannerForEvent(String url, ImageView imageView, int height,
			int width) {
		imageViews.put(imageView, url);
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			imageView.setImageBitmap(bitmap);
		} else {
			queuePhoto(url, imageView);
			//imageView.setImageResource(R.drawable.left_arrow_selector);
		}
	}
	
	private void queuePhoto(String url, ImageView imageView) {
		PhotoToLoad p = new PhotoToLoad(url, imageView);
		executorService.submit(new PhotosLoader(p));
	}
	public String getBitmapPath(String url) {
		File f = fileCache.getFile(url);
		return f.getPath();
	}

		// from web
	public Bitmap getBitmap(String url) {
		File f = fileCache.getFile(url);
		// from SD cache
		Bitmap b = decodeFile(f);
		if (b != null)
			return b;

		// from web
		try {
			Bitmap bitmap = null;
			URL imageUrl = new URL(url.toString());
			HttpURLConnection conn = (HttpURLConnection) imageUrl
					.openConnection();
			conn.setConnectTimeout(30000);
			conn.setReadTimeout(30000);
			conn.setInstanceFollowRedirects(true);
			InputStream is = conn.getInputStream();
			OutputStream os = new FileOutputStream(f);
			Utils.CopyStream(is, os);
			os.close();
			bitmap = decodeFile(f);
			
			return bitmap;
		} catch (Throwable ex) {
			ex.printStackTrace();
			if (ex instanceof OutOfMemoryError)
				memoryCache.clear();
			return null;
		}
	}

	// decodes image and scales it to reduce memory consumption
	public Bitmap decodeFile(File f) {
		try {
			// decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);

			// Find the correct scale value. It should be the power of 2.
			final int REQUIRED_SIZE = 400;
			int width_tmp = o.outWidth, height_tmp = o.outHeight;
			Log.e("width =" + width_tmp, "height is =" + height_tmp);
			int scale = 1;
			while (true) {
				if (width_tmp / 2 < REQUIRED_SIZE
						|| height_tmp / 2 < REQUIRED_SIZE)
					break;
				width_tmp /= 2;
				height_tmp /= 2;
				scale *= 2;
			}

			// decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;
			return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		} catch (FileNotFoundException e) {
		}
		return null;
	}

	// Task for the queue
	private class PhotoToLoad {
		public String url;
		public ImageView imageView;

		public PhotoToLoad(String u, ImageView i) {
			url = u;
			imageView = i;
		}
	}

	class PhotosLoader implements Runnable {
		PhotoToLoad photoToLoad;

		PhotosLoader(PhotoToLoad photoToLoad) {
			this.photoToLoad = photoToLoad;
		}

		@Override
		public void run() {
			if (imageViewReused(photoToLoad))
				return;
			Bitmap bmp = getBitmap(photoToLoad.url);
			memoryCache.put(photoToLoad.url, bmp);
			if (imageViewReused(photoToLoad))
				return;
			BitmapDisplayer bd = new BitmapDisplayer(bmp, photoToLoad);
			Activity a = (Activity) photoToLoad.imageView.getContext();
			a.runOnUiThread(bd);
		}
	}

	boolean imageViewReused(PhotoToLoad photoToLoad) {
		String tag = imageViews.get(photoToLoad.imageView);
		if (tag == null || !tag.equals(photoToLoad.url))
			return true;
		return false;
	}

	// Used to display bitmap in the UI thread
	class BitmapDisplayer implements Runnable {
		Bitmap bitmap;
		PhotoToLoad photoToLoad;

		public BitmapDisplayer(Bitmap b, PhotoToLoad p) {
			bitmap = b;
			photoToLoad = p;
		}

		@Override
		public void run() {
			if (imageViewReused(photoToLoad))
				return;
			if (bitmap != null)
				photoToLoad.imageView.setImageBitmap(bitmap);
			else
				photoToLoad.imageView.setImageResource(stub_id);
		}
	}

	public void clearCache() {
		memoryCache.clear();
		fileCache.clear();
	}

	private void circularImageview(ImageView imageview, Bitmap bitmap) {

		Bitmap bitmapRounded = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), bitmap.getConfig());
		Canvas canvas = new Canvas(bitmapRounded);
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setShader(new BitmapShader(bitmap, Shader.TileMode.CLAMP,
				Shader.TileMode.CLAMP));
		canvas.drawRoundRect(
				(new RectF(0.0f, 0.0f, bitmap.getWidth(), bitmap.getHeight())),
				10, 10, paint);

		imageview.setImageBitmap(bitmapRounded);
	}

	public void displayImage(String url, ImageView imageView, boolean isReward,
			int placeholder_imageview_id) {
		stub_id2 = placeholder_imageview_id;
		imageViews.put(imageView, url);
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null)
			imageView.setImageBitmap(bitmap);
		else {
			queuePhoto(url, imageView);
			if (isReward) {
				// imageView.setImageResource(stub_id1);
			} else {
				imageView.setImageResource(stub_id2);
			}
		}
	}

	public void displayImageRoundedCorner(String url, ImageView imageView,
			boolean isReward, int placeholder_imageview_id, boolean isImagerounded) {
		stub_id2 = placeholder_imageview_id;
		imageViews.put(imageView, url);
		isRounded = isImagerounded;
		Bitmap bitmap = memoryCache.get(url);
		if (bitmap != null) {
			 bitmap =roundCorner(bitmap, 45.0f);
			 imageView.setImageBitmap(bitmap);
		} else {
			queuePhoto(url, imageView);
			if (isReward) {
				// imageView.setImageResource(stub_id1);
			} else {
			   bitmap = BitmapFactory.decodeResource(context.getResources(), stub_id2);
				 bitmap =roundCorner(bitmap, 45.0f);
			   imageView.setImageBitmap(bitmap);
			//	imageView.setImageResource(stub_id2);
			}
		}
	}
	 /**
		 * to make the user image into rounded corners
		 * 
		 */
	 public Bitmap roundCorner(Bitmap src, float round) {
		    // image size
		    int width = src.getWidth();
		    int height = src.getHeight();
		    // create bitmap output
		    Bitmap result = Bitmap.createBitmap(width, height, Config.ARGB_8888);
		    // set canvas for painting
		    Canvas canvas = new Canvas(result);
		    canvas.drawARGB(0, 0, 0, 0);
		 
		    // config paint
		    final Paint paint = new Paint();
		    paint.setAntiAlias(true);
		    paint.setColor(Color.BLACK);
		 
		    // config rectangle for embedding
		    final Rect rect = new Rect(0, 0, width, height);
		    final RectF rectF = new RectF(rect);
		 
		    // draw rect to canvas
		    canvas.drawRoundRect(rectF, round, round, paint);
		 
		    // create Xfer mode
		    paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		    // draw source image to canvas
		    canvas.drawBitmap(src, rect, rect, paint);
		 
		    // return final image
		    return result;
		}
}
