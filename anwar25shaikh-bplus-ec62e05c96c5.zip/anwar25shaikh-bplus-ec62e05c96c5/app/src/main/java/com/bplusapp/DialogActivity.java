package com.bplusapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Utils;

import java.util.HashMap;

/**
 * Created by DEEPAK on 5/3/2016.
 */
public class DialogActivity extends Activity implements IAsyncTaskRunner, IDialogClick{

    private Button btn_cancel;
    private Button btn_send;

    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;


    private EditText et_message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_activity);

        btn_send = (Button) findViewById(R.id.btn_send);
        btn_cancel = (Button) findViewById(R.id.btn_cancel);

        et_message = (EditText) findViewById(R.id.et_message);


        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(et_message.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(DialogActivity.this, "Please enter the message", Toast.LENGTH_LONG).show();
                }else {
                    performGoingButtonProcess(et_message.getText().toString());
                }



            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });

    }

    private void performGoingButtonProcess(String message){
        loadingDialog =  new CustomLoadingDialog(this);
        authCommonTask =  new AuthCommonTask(this, BaseNetwork.CONFIRM_REQUEST,this,loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("requestId", getIntent().getExtras().get("requestId").toString());
        hashMap.put("senderId", getIntent().getExtras().get("senderId").toString());
        hashMap.put("receiverId", getIntent().getExtras().get("receiverId").toString());
        hashMap.put("reqStatus", getIntent().getExtras().get("reqStatus").toString());
        hashMap.put("message", message);
        authCommonTask.execute(hashMap);
    }

    @Override
    public Context getContext() {
        return null;
    }

    @Override
    public void taskCompleted(Object obj) {

        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
             ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
        {

            UserInfo user = (UserInfo)resultMessage.RESULT_OBJECT;
            Utils.ShowAlertDialog(DialogActivity.this,user.getMessage(), DialogActivity.this, null);

        }



    }

    @Override
    public void taskErrorMessage(Object obj) {
        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
            Utils.ShowAlertDialog(DialogActivity.this, resultMessage.ERRORMESSAGE, this, null);

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    @Override
    public void OnClickListener(Fragment fragment) {
        Intent intent = new Intent("custom-event-name");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        finish();

    }


}
