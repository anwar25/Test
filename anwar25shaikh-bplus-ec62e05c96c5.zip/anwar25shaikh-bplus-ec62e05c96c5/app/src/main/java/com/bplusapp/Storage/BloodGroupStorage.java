package com.bplusapp.Storage;

import android.content.Context;

import com.bplusapp.R;

/**
 * Created by Akash.Singh on 7/29/2015.
 */
public class BloodGroupStorage extends JSONStorage {
    public BloodGroupStorage(Context context) {
        super(context);
    }

    @Override
    public void setFileName() {
        FILE_NAME = "bloodgroup";
        mAssetsFileID = R.raw.bloodgroup;

    }
}