package com.bplusapp.Adapter;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bplusapp.Entity.AllNotificationDataClass;
import com.bplusapp.R;
import com.bplusapp.Utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by DEEPAK on 4/19/2016.
 */
public class MyNotificationAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private List<AllNotificationDataClass> mAllNotificationDataClasses;


    public MyNotificationAdapter(Context context, List<AllNotificationDataClass> mAllNotificationDataClasses) {

        this.context = context;
        inflater = LayoutInflater.from(this.context);
        this.mAllNotificationDataClasses = mAllNotificationDataClasses ;
    }

    @Override
    public int getCount() {
        return mAllNotificationDataClasses.size();
    }

    @Override
    public Object getItem(int position) {
        return mAllNotificationDataClasses.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MyViewHolder mViewHolder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_notification_view, parent, false);
            mViewHolder = new MyViewHolder(convertView);
            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (MyViewHolder) convertView.getTag();
        }

        mViewHolder.tv_notification_message.setText(mAllNotificationDataClasses.get(position).getMessage());
        mViewHolder.tv_notification_date.setText(mAllNotificationDataClasses.get(position).getDateTime());
        mViewHolder.btn_bplus.setText(mAllNotificationDataClasses.get(position).getBloodGroup());

        mViewHolder.btn_bplus.setBackground(context.getResources().getDrawable(Utils.UseBloodGroupCode(mAllNotificationDataClasses.get(position).getBloodGroup())));

        return convertView;
    }
    private class MyViewHolder {
        TextView tv_notification_message, tv_notification_date;
        Button btn_bplus ;

        public MyViewHolder(View item) {
            tv_notification_message = (TextView) item.findViewById(R.id.tv_notification_message);
            tv_notification_date = (TextView) item.findViewById(R.id.tv_notification_date);
            btn_bplus = (Button) item.findViewById(R.id.btn_bplus);
        }
    }
}
