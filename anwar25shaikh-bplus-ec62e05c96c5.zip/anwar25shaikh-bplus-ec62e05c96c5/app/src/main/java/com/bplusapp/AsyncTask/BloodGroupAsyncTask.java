package com.bplusapp.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;

import com.bplusapp.Data.DataModel;
import com.bplusapp.Data.HJSONParsing;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.Storage.BloodGroupStorage;

/**
 * Created by Akash.Singh on 12/4/2015.
 * This process run on background for save counties server xml string to local xml string file
 */
public class BloodGroupAsyncTask extends AsyncTask{

    BloodGroupStorage bloodGroupStorage;
    Context context;
    DataModel dataModel;
    public BloodGroupAsyncTask(DataModel dataModel){
        this.context = dataModel.getContext();
        this.dataModel = dataModel;
        bloodGroupStorage =  new BloodGroupStorage(context);
        bloodGroupStorage.setFileName();
    }

    @Override
    protected Object doInBackground(Object[] params) {
        LoadCountryListFormServer();
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);

    }

    void LoadCountryListFormFile(){
        String XmlResponse = bloodGroupStorage.LoadXmlFromFile();
        if(!TextUtils.isEmpty(XmlResponse)){
            HJSONParsing xmlParsing =  new HJSONParsing();
            dataModel.SetBloodGroupList(xmlParsing.parseCurrencyData(XmlResponse));
        }
        else
            return;
    }

    void LoadCountryListFormServer(){
        if(PreHelper.getStoredBoolean(context, StaticConstant.FIRSTTIMECOMPILEBLOODGROUPLIST))
        {
            String XmlResponse = bloodGroupStorage.LoadXmlFromAssets();
            if(!TextUtils.isEmpty(XmlResponse)){
                HJSONParsing xmlParsing =  new HJSONParsing();
                if(bloodGroupStorage.SaveXmlToFile(XmlResponse)) {
                    PreHelper.storeBoolean(context, StaticConstant.FIRSTTIMECOMPILEBLOODGROUPLIST, false);
                }
                dataModel.SetBloodGroupList(xmlParsing.parseCurrencyData(XmlResponse));
            }
        }
        else
            LoadCountryListFormFile();
    }

}
