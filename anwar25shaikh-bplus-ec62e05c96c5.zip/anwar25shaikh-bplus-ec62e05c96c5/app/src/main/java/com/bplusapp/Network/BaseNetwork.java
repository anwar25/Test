// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.bplusapp.Network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;

import com.bplusapp.Utils.Logger;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class BaseNetwork
{

    private static BaseNetwork obj = null;
    public static final String REGISTER_METHOD = "register";
    public static final String DEVICEID = "deviceid";
    public static final String LOGIN_METHOD = "login";

    public static final String UPDATE_PROFILE_METHOD = "updateprofile";
    public static final String CHANGE_PASSWORD_METHOD ="changepassword";
    public static final String FORGET_PASS_METHOD = "forgetpass";
    public static final String BLOOD_REQUEST_METHOD = "bloodrequest";
    public static final String FEEDS_METHOD = "feeds";
    public static final String REQUESTS_BY_USER_ID_METHOD = "requestsByUserId";
    public static final String CONFIRM_REQUEST = "confirmRequest";
    public static final String ACCEPTED_REQUEST = "acceptedRequests";

    //Notifications URL
    public static final String GET_ALL_NOTIFICATIONS = "getAllNotifications";
    public static final String REQUEST_DESCRIPTION = "requestDescription";
    public static final String VIEW_MY_REQUEST_DETAIL = "viewMyRequestDetail";

   // public static final String REQUESTS_BY_USERID = "requestsByUserId";
    public static final String URL_HOST = "http://development.eweblabs.in/bplus/api/";


    public static final String CLOSE_REQUEST = "closeRequest";

    public static final String FILTER_REQUESETS = "filterRequesets";
    public static final String CONFIRM_DONOR = "confirmDoner";


    public int TimeOut = 100000;
    public BaseNetwork()
    {
        TimeOut = 100000;
    }

    public static BaseNetwork obj()
    {
        BaseNetwork basenetwork;
        if (obj == null)
        {
            obj = new BaseNetwork();
        }
        basenetwork = obj;
        return basenetwork;
    }

    HttpURLConnection urlConnection = null;
   public  String PostMethodWay(Context context,String URL_HOST, String KeyWord, HashMap<Object,Object> hashMap, int timeout) {
        String response = "";

        try {
            if(urlConnection!=null)
                urlConnection.disconnect();
            String URLPaTH = URL_HOST+KeyWord;
            Logger.d("URLPaTH", "::" + URLPaTH);
            DefaultHttpClient httpclient = new DefaultHttpClient();
            HttpPost httpost = new HttpPost(URLPaTH);
            JSONObject holder = new JSONObject();
            for(Map.Entry entry: hashMap.entrySet()){
                holder.put((String) entry.getKey(), entry.getValue());
            }
            Logger.d("JSONObject", holder.toString());
            StringEntity se = new StringEntity(holder.toString());
            httpost.setEntity(se);
            httpost.setHeader("Accept", "application/json");
            httpost.setHeader("Content-type", "application/json");
            HttpResponse result = httpclient.execute(httpost);
            response = EntityUtils.toString(result.getEntity());
            Logger.d("STATUS", "::" + response);
            if(TextUtils.isEmpty(response))
            {
                response = "404";
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            response = "404";
         } catch (SocketTimeoutException e) {
            e.printStackTrace();
            response = "500";
        }catch (EOFException e){
            e.printStackTrace();
            PostMethodWay(context,URL_HOST,KeyWord,hashMap,timeout);
        }catch (IOException e) {
            e.printStackTrace();
            response = "404";
        } catch (JSONException e) {
            e.printStackTrace();
            response = "404";
        } finally {
            if (urlConnection != null) {
                try{
                    urlConnection.disconnect();
                }
                catch (Exception e){
                    e.printStackTrace();
                    response = "500";
                }

            }
        }
        return response;
    }

    public  String PostMethodWay(String URL_HOST, String KeyWord, HashMap<Object,Object> hashMap, int timeout) {
        String response = "";

        try {
            if(urlConnection!=null)
                urlConnection.disconnect();
            String URLPaTH = URL_HOST+KeyWord;
            Logger.d("URLPaTH", "::" + URLPaTH);
            DefaultHttpClient httpclient = new DefaultHttpClient();
            HttpPost httpost = new HttpPost(URLPaTH);
            JSONObject holder = new JSONObject();
            for(Map.Entry entry: hashMap.entrySet()){
                holder.put((String) entry.getKey(), entry.getValue());
            }
            Logger.d("JSONObject", holder.toString());
            StringEntity se = new StringEntity(holder.toString());
            httpost.setEntity(se);
            httpost.setHeader("Accept", "application/json");
            httpost.setHeader("Content-type", "application/json");
            HttpResponse result = httpclient.execute(httpost);
            response = EntityUtils.toString(result.getEntity());
            Logger.d("STATUS", "::" + response);
            if(TextUtils.isEmpty(response))
            {
                response = "404";
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            response = "404";
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            response = "500";
        }catch (EOFException e){
            e.printStackTrace();
            PostMethodWay(URL_HOST,KeyWord,hashMap,timeout);
        }catch (IOException e) {
            e.printStackTrace();
            response = "404";
        } catch (JSONException e) {
            e.printStackTrace();
            response = "404";
        } finally {
            if (urlConnection != null) {
                try{
                    urlConnection.disconnect();
                }
                catch (Exception e){
                    e.printStackTrace();
                    response = "500";
                }

            }
        }
        return response;
    }

    private String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    private static final char PARAMETER_DELIMITER = '&';
    private static final char PARAMETER_EQUALS_CHAR = '=';
    public static String createQueryStringForParameters(Map<Object,Object> parameters) {
        StringBuilder parametersAsQueryString = new StringBuilder();
        if (parameters != null) {
            boolean firstParameter = true;

            for (Object parameterName : parameters.keySet()) {
                if (!firstParameter) {
                    parametersAsQueryString.append(PARAMETER_DELIMITER);
                }

                parametersAsQueryString.append((String)parameterName)
                        .append(PARAMETER_EQUALS_CHAR)
                        .append(URLEncoder.encode(
                                (String) parameters.get(parameterName)));

                firstParameter = false;
            }
        }
        return parametersAsQueryString.toString();
    }



    public boolean checkConnOnline(Context context)
    {
        ConnectivityManager cm =
                (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }


    public String LoadXmlFromAssets(Context context,int mAssetsFileID){
        StringBuilder stringBuilder =  new StringBuilder();
        BufferedReader bufferedReader;
        InputStream inputStream = context.getResources().openRawResource(mAssetsFileID);
        try {
            bufferedReader=new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
        String line;
        try {
            while ((line=bufferedReader.readLine())!=null){
                stringBuilder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return stringBuilder.toString();
    }
}
