package com.bplusapp.Feed;

import android.app.Activity;

/**
 * Created by DEEPAK on 4/27/2016.
 */
public class NotificationDescriptionActivity extends Activity {
}
