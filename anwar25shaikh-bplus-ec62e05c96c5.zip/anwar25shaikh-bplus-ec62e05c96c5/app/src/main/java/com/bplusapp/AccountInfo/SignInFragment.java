package com.bplusapp.AccountInfo;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.bplusapp.R;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomAppCompatButton;
import com.bplusapp.UI.CustomEditView;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.UI.CustomTextWatcher;
import com.bplusapp.Utils.Utils;

/**
 * Created by Akash.Singh on 1/6/2016.
 */
public class SignInFragment extends Fragment implements View.OnClickListener {
    CustomTextView term_and_condition;
    CustomEditView edit_email_address,edit_password;
    TextInputLayout input_email_address,input_password;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_sign_in_screen,container,false);
        ((AccountActivityScreen)getActivity()).SetToolbarInitialization(this,getString(R.string.title_sign_in));
        WidgetMapping(view);
        return view;
    }

    private void WidgetMapping(View view) {
        edit_email_address = (CustomEditView) view.findViewById(R.id.edit_email_address);
        edit_password = (CustomEditView) view.findViewById(R.id.edit_password);

        input_email_address = (TextInputLayout) view.findViewById(R.id.input_email_address);
        input_password = (TextInputLayout) view.findViewById(R.id.input_password);

        edit_email_address.addTextChangedListener(new CustomTextWatcher(input_email_address));
        edit_password.addTextChangedListener(new CustomTextWatcher(input_password));

        ((CustomAppCompatButton)view.findViewById(R.id.btnSignin)).setOnClickListener(this);
        ((CustomTextView)view.findViewById(R.id.text_forget_password)).setOnClickListener(this);
        ((CustomAppCompatButton)view.findViewById(R.id.btngoogle)).setOnClickListener(this);
        ((CustomAppCompatButton)view.findViewById(R.id.btnfacbook)).setOnClickListener(this);
        ((TextView)view.findViewById(R.id.text_sign_up)).setOnClickListener(this);
        term_and_condition = (CustomTextView) view.findViewById(R.id.term_and_condition);
        SpanningMethod();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSignin:
                if(Validation())
                    ((AccountActivityScreen)getActivity()).PerformSignInProcess(edit_email_address.getText().toString(),edit_password.getText().toString(),"","","","", "");
                break;
            case R.id.btngoogle:
                ((AccountActivityScreen)getActivity()).GoogleSignInProcess();
                break;
            case R.id.btnfacbook:
                ((AccountActivityScreen)getActivity()).FaceBookSignInProcess();
                break;
            case R.id.text_sign_up:
                ((AccountActivityScreen) getActivity()).onReplaceFragment(new SignUpFragment(), true);
                break;
            case R.id.text_forget_password:
                ((AccountActivityScreen)getActivity()).onReplaceFragment(new ForgotPasswordFragment(),true);
                break;
        }
    }

    private boolean Validation(){
        if(TextUtils.isEmpty(edit_email_address.getText().toString())) {
            input_email_address.setError(getString(R.string.hint_please_enter_your_email_address));
            return false;
        }
        else if(!TextUtils.isEmpty(edit_email_address.getText().toString()) && !Utils.validateEmail(edit_email_address.getText().toString())){
            input_email_address.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        }else if(TextUtils.isEmpty(edit_password.getText().toString())) {
            input_password.setError(getString(R.string.hint_please_enter_your_password));
            return false;
        }else if(!TextUtils.isEmpty(edit_password.getText().toString())&& !Utils.validatePassword(edit_password.getText().toString())) {
            input_password.setError(getString(R.string.hint_please_enter_valid_phone));
            return false;
        }

        return  true;
    }


    private void SpanningMethod() {
        SpannableString text = new SpannableString("By Logging in you agree to our Terms & Condition");
        final ForegroundColorSpan fcs = new ForegroundColorSpan(Color.RED);
        // text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.hotel_checkout_deactivated_tab_color)), text.length() - 18, text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.setSpan(fcs, text.length() - 17, text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View v) {
                terms_dialog();

            }
        }, text.length() - 17, text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        term_and_condition.setHighlightColor(getResources().getColor(android.R.color.transparent));
        term_and_condition.setText(text);
        term_and_condition.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void terms_dialog(){
        final Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.term_and_conditions);
        dialog.setCancelable(true);
        WebView webView= (WebView) dialog.findViewById(R.id.webView);
        Button ok=(Button)dialog.findViewById(R.id.btnok);
        webView.loadUrl("file:////android_asset/"+ StaticConstant.TERM_AND_CONDITIONS);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        Window window = dialog.getWindow();
        lp.copyFrom(window.getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        window.setAttributes(lp);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        dialog.show();
    }




}
