package com.bplusapp.AccountInfo;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CompoundButton;

import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Interface.IMenuItemClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomCheckBox;
import com.bplusapp.R;
import com.bplusapp.UI.CustomEditView;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.UI.CustomTextWatcher;
import com.bplusapp.Utils.Utils;

import java.util.HashMap;

/**
 * Created by Akash.Singh on 1/6/2016.
 */
public class SignUpFragment extends Fragment implements View.OnClickListener,IDialogClick{
    CustomCheckBox cb_term_and_conditions;
    CustomEditView edit_first_name,edit_last_name,edit_email_address,edit_password;
    TextInputLayout input_first_name,input_last_name,input_email_address,input_password;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_sign_up_screen,container,false);
        ((AccountActivityScreen)getActivity()).SetToolbarInitialization(this,getString(R.string.title_create_account));
        WidgetMapping(view);
        return view;
    }

    private void WidgetMapping(View view) {
        ((AppCompatButton)view.findViewById(R.id.btnSignUp)).setOnClickListener(this);
        edit_first_name = (CustomEditView) view.findViewById(R.id.edit_first_name);
        edit_last_name = (CustomEditView) view.findViewById(R.id.edit_last_name);
        edit_email_address = (CustomEditView) view.findViewById(R.id.edit_email_address);
        edit_password = (CustomEditView) view.findViewById(R.id.edit_password);

        input_first_name = (TextInputLayout) view.findViewById(R.id.input_first_name);
        input_last_name = (TextInputLayout) view.findViewById(R.id.input_last_name);
        input_email_address = (TextInputLayout) view.findViewById(R.id.input_email_address);
        input_password = (TextInputLayout) view.findViewById(R.id.input_password);

        edit_first_name.addTextChangedListener(new CustomTextWatcher(input_first_name));
        edit_last_name.addTextChangedListener(new CustomTextWatcher(input_last_name));
        edit_email_address.addTextChangedListener(new CustomTextWatcher(input_email_address));
        edit_password.addTextChangedListener(new CustomTextWatcher(input_password));




        cb_term_and_conditions = (CustomCheckBox) view.findViewById(R.id.cb_term_and_conditions);
        cb_term_and_conditions.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked)
                    terms_dialog();
            }
        });
    }

    private boolean Validation(){
        if(TextUtils.isEmpty(edit_first_name.getText().toString())) {
            input_first_name.setError(getString(R.string.hint_please_enter_your_first_name));
            return false;
        }else if(TextUtils.isEmpty(edit_last_name.getText().toString())) {
            input_last_name.setError(getString(R.string.hint_please_enter_your_last_name));
            return false;
        }else if(TextUtils.isEmpty(edit_email_address.getText().toString())) {
            input_email_address.setError(getString(R.string.hint_please_enter_your_email_address));
            return false;
        }
        else if(!TextUtils.isEmpty(edit_email_address.getText().toString()) && !Utils.validateEmail(edit_email_address.getText().toString())){
            input_email_address.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        }else if(TextUtils.isEmpty(edit_password.getText().toString())) {
            input_password.setError(getString(R.string.hint_please_enter_your_password));
            return false;
        }
        else if(!TextUtils.isEmpty(edit_password.getText().toString()) && !Utils.validatePassword(edit_password.getText().toString()) ) {
            input_password.setError(getString(R.string.hint_please_enter_valid_phone));
            return false;
        }
        else if(!cb_term_and_conditions.isChecked()){
            Utils.ShowAlertDialog(getActivity(),getString(R.string.please_read_term_and_condition),this,null);
            return false;
        }
        return  true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSignUp:
                if(Validation()) {
                    ((AccountActivityScreen)getActivity()).PerformSignUpProcess(edit_first_name.getText().toString(),edit_last_name.getText().toString(),edit_email_address.getText().toString(),edit_password.getText().toString());
                }
                break;
        }
    }


    public void terms_dialog(){
        final Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.term_and_conditions);
        dialog.setCancelable(true);
        WebView webView= (WebView) dialog.findViewById(R.id.webView);
        Button ok=(Button)dialog.findViewById(R.id.btnok);
        webView.loadUrl("file:////android_asset/"+ StaticConstant.TERM_AND_CONDITIONS);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cb_term_and_conditions.setChecked(true);
                dialog.dismiss();
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        Window window = dialog.getWindow();
        lp.copyFrom(window.getAttributes());
        lp.width = WindowManager.LayoutParams.FILL_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        window.setAttributes(lp);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        dialog.show();
    }


    @Override
    public void OnClickListener(Fragment fragment) {

    }
}
