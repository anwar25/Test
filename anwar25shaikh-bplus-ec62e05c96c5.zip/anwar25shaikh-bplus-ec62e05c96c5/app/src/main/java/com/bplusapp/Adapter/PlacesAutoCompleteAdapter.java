package com.bplusapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.bplusapp.Network.RetrofitInstance;
import com.bplusapp.Network.Urls;
import com.bplusapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by Anwar on 7/3/2016.
 */
public class PlacesAutoCompleteAdapter extends ArrayAdapter<PlaceDetails> implements Filterable {

    ArrayList<PlaceDetails> resultList;

    Context mContext;
    int mResource;

    //PlaceAPI mPlaceAPI = new PlaceAPI();

    public PlacesAutoCompleteAdapter(Context context, int resource , ArrayList<PlaceDetails> resultList) {
        super(context, resource);

        mContext = context;
        this.resultList = resultList ;
    }

    @Override
    public int getCount() {
        // Last item will be the footer
        return resultList.size();
    }

    @Override
    public PlaceDetails getItem(int position) {
        return resultList.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            convertView = inflater.inflate(R.layout.spinner_item_layout, parent, false);
           /* if (position != (resultList.size() - 1))
                convertView = inflater.inflate(R.layout.spinner_item_layout, parent, false);
            else
                convertView = inflater.inflate(R.layout.spinner_item_google_image, parent, false);*/
        }
        //if (position != (resultList.size() - 1))
            ((TextView) convertView.findViewById(android.R.id.text1)).setText(getItem(position).getDescription());
      //      ((ImageView) convertView.findViewById(android.R.id.text1)).setText(getItem(position));
        return convertView;
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();
                if (constraint != null) {
                    //resultList = mPlaceAPI.autocomplete(constraint.toString());
                    Call<ResponseBody> responseBody = RetrofitInstance.getInstance(Urls.GOOGLE_PLACES_BASE_URL)
                            .getAddress(String.valueOf(constraint), Urls.GOOGLE_PLACES_API_KEY);
                    Response<ResponseBody> resBody = null;
                    try {
                        resBody = responseBody.execute();
                       // String result = resBody.body().string();
                       // Logger.e("anwar",result);
                        JSONObject jsonObj = new JSONObject(resBody.body().string());
                        JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

                        // Extract the Place descriptions from the results
                        resultList = new ArrayList<PlaceDetails>(predsJsonArray.length());
                        for (int i = 0; i < predsJsonArray.length(); i++) {
                            resultList.add(new PlaceDetails(predsJsonArray.getJSONObject(i).getString("description"),
                                    predsJsonArray.getJSONObject(i).getString("place_id")));
                        }
                        //resultList.add("Powered By Google");
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    filterResults.values = resultList;
                    filterResults.count = resultList.size();
                }

                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (results != null && results.count > 0) {
                    notifyDataSetChanged();
                }
                else {
                    notifyDataSetInvalidated();
                }
            }
        };

        return filter;
    }
}