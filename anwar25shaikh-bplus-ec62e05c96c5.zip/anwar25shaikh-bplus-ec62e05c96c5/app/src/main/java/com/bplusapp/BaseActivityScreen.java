package com.bplusapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bplusapp.AcceptedRequests.AcceptRequestFragment;
import com.bplusapp.AccountInfo.AccountActivityScreen;
import com.bplusapp.AccountInfo.ChangePasswordFragment;
import com.bplusapp.AccountInfo.UpdateProfileFragment;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BloodRequest.BloodRequestFragment;
import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Feed.FeedDetailFragment;
import com.bplusapp.Feed.FeedFragment;
import com.bplusapp.Feed.MyNotificationDetailFragment;
import com.bplusapp.Home.HomeFragment;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Interface.IMenuItemClick;
import com.bplusapp.MyNotification.MyNotificationFragment;
import com.bplusapp.MyRequests.MyRequestDetailFragment;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomCheckBox;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.UI.MyMenuItemStuffListener;
import com.bplusapp.Utils.ImageDownloaderTask;
import com.bplusapp.Utils.Logger;
import com.bplusapp.Utils.Utils;
import com.bplusapp.imageLoader.ImageLoaderNeww;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.plus.Plus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class BaseActivityScreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, IMenuItemClick, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, IDialogClick, IAsyncTaskRunner {
    public static final int DISTANCE = 5;
    ActionBarDrawerToggle toggle;

    private AppCompatButton btnPostBloodRequest;
    private CustomCheckBox chk_APlus, chk_AMinus, chk_BPlus, chk_BMinus, chk_ABPlus, chk_ABMinus, chk_OPlus, chk_OMinus;
    private CustomTextView tv_distance;
    ImageView add_distance, sub_distance;

    private ImageLoaderNeww imageLoader;
    public static ArrayList<String> bloodGroupStringArrayList = new ArrayList<String>();
    public static String distance;
    private boolean isUserSignnedOut = false;

    private Tracker mTracker;
    private String defaultDistance = "5";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_screen);
        chk_APlus = (CustomCheckBox) findViewById(R.id.chk_APlus);
        chk_AMinus = (CustomCheckBox) findViewById(R.id.chk_AMinus);
        chk_BPlus = (CustomCheckBox) findViewById(R.id.chk_BPlus);
        chk_BMinus = (CustomCheckBox) findViewById(R.id.chk_BMinus);
        chk_ABPlus = (CustomCheckBox) findViewById(R.id.chk_ABPlus);
        chk_ABMinus = (CustomCheckBox) findViewById(R.id.chk_ABMinus);
        chk_OPlus = (CustomCheckBox) findViewById(R.id.chk_OPlus);
        chk_OMinus = (CustomCheckBox) findViewById(R.id.chk_OMinus);
        tv_distance = (CustomTextView) findViewById(R.id.tv_distance);

        //   ApplicationContainer application = (ApplicationContainer) getApplication();
        // mTracker = application.getDefaultTracker();


        add_distance = (ImageView) findViewById(R.id.add_distance);
        add_distance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (Integer.parseInt(tv_distance.getText().toString()) >= 50) {
                } else {

                    int count = Integer.parseInt(tv_distance.getText().toString());
                    count = count + 5;
                    tv_distance.setText("" + count);
                }

            }
        });
        sub_distance = (ImageView) findViewById(R.id.sub_distance);
        sub_distance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Integer.parseInt(tv_distance.getText().toString()) <= 5) {
                } else {
                    int count = Integer.parseInt(tv_distance.getText().toString());
                    count = count - 5;
                    tv_distance.setText("" + count);
                }
            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //GET user information
        UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
        tv_distance.setText(userInfo.getFilterDistance());
        distance = userInfo.getFilterDistance();
        if(distance == null || TextUtils.isEmpty(distance)){
            tv_distance.setText(defaultDistance);
        }
        btnPostBloodRequest = (AppCompatButton) findViewById(R.id.btnPostBloodRequest);

        chk_APlus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    bloodGroupStringArrayList.add("A+");
                } else {
                    bloodGroupStringArrayList.remove("A+");
                }
            }
        });

        chk_AMinus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("A-");
                } else {
                    bloodGroupStringArrayList.remove("A-");
                }
            }
        });
        chk_BPlus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("B+");
                } else {
                    bloodGroupStringArrayList.remove("B+");
                }
            }
        });
        chk_BMinus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("B-");
                } else {
                    bloodGroupStringArrayList.remove("B-");
                }
            }
        });
        chk_ABPlus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("AB+");
                } else {
                    bloodGroupStringArrayList.remove("AB+");
                }
            }
        });
        chk_ABMinus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("AB-");
                } else {
                    bloodGroupStringArrayList.remove("AB-");
                }
            }
        });
        chk_OPlus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("O+");
                } else {
                    bloodGroupStringArrayList.remove("O+");
                }
            }
        });
        chk_OMinus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bloodGroupStringArrayList.add("O-");
                } else {
                    bloodGroupStringArrayList.remove("O-");
                }
            }
        });

        btnPostBloodRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                distance = tv_distance.getText().toString();

                //Update filter data in user info table
                UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();

                ArrayList<String> selectBgList = new ArrayList<String>();

                if (chk_APlus.isChecked()) {
                    selectBgList.add("A+");
                }
                if (chk_AMinus.isChecked()) {
                    selectBgList.add("A-");
                }
                if (chk_BPlus.isChecked()) {
                    selectBgList.add("B+");
                }
                if (chk_BMinus.isChecked()) {
                    selectBgList.add("B-");
                }
                if (chk_ABPlus.isChecked()) {
                    selectBgList.add("AB+");
                }
                if (chk_ABMinus.isChecked()) {
                    selectBgList.add("AB-");
                }
                if (chk_OPlus.isChecked()) {
                    selectBgList.add("O+");
                }
                if (chk_OMinus.isChecked()) {
                    selectBgList.add("O-");
                }

                userInfo.setFilterDistance(distance);
                userInfo.setFilterBloodGroup(android.text.TextUtils.join(",", selectBgList));
                ApplicationContainer.getInstance().getBPlusSavedDBData().InsertUserInfoID(userInfo);

                onReplaceFragment(new HomeFragment(), false);

                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.END);

                //Toast.makeText(BaseActivityScreen.this, "Done", Toast.LENGTH_SHORT).show();

            }
        });

        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view_left);
        navigationView.setNavigationItemSelectedListener(this);
        final View headerView = (View) LayoutInflater.from(this).inflate(R.layout.nav_header_splash_screen, null);
        navigationView.addHeaderView(headerView);


        /// HIDE change password for social login start

        String loginBy = userInfo.getAuthBy();
        if(loginBy != null){
            if (loginBy.equalsIgnoreCase("Facebook") || loginBy.equals("Google")) {
                Menu nav_Menu = navigationView.getMenu();
                nav_Menu.findItem(R.id.nav_change_password).setVisible(false);
            }
        }

        /// HIDE change password for social login end
        ((TextView) headerView.findViewById(R.id.txt_username)).setText(userInfo.getUserFName() + " " + userInfo.getUserLName());


        imageLoader = ImageLoaderNeww.getMyImageLoaderInstance(BaseActivityScreen.this);

        // imageLoader.DisplayImage(userInfo.getProfilePic(),(ImageView) headerView.findViewById(R.id.profile_img), 150);
        new ImageDownloaderTask((ImageView) headerView.findViewById(R.id.profile_img), userInfo.getProfilePic(), BaseActivityScreen.this).execute(userInfo.getProfilePic());

        toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        ((LinearLayout) headerView.findViewById(R.id.navigation_header)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
                /*if (ApplicationController.getInstance().getUserInfo() != null &&
                        !TextUtils.isEmpty(ApplicationController.getInstance().getUserInfo().getUserEmail())) {
                    onReplaceFragment(new ProfileScreen(), true);
                } else {
                    onReplaceFragment(new SignInScreen(), true);
                }*/
            }
        });


        onReplaceFragment(new HomeFragment(), false);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.container);
                if (currentFragment instanceof HomeFragment) {
                    drawer.openDrawer(GravityCompat.START);
                } else {
                    onBackPressed();
                }
            }
        });

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        buildGoogleApiClient();

        if (getIntent() != null) {
            String bloodRequestId = getIntent().getStringExtra(StaticConstant.BLOOD_REQUEST_ID);
            if (!TextUtils.isEmpty(bloodRequestId)) {
                Bundle bundle = new Bundle();
                bundle.putString("requestId", bloodRequestId);
                FeedDetailFragment feedDetailFragment = new FeedDetailFragment();
                feedDetailFragment.setArguments(bundle);
                onReplaceFragment(feedDetailFragment, true);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ApplicationContainer.getInstance().trackScreenView(BaseActivityScreen.class.getCanonicalName());
    }

    private void sendScreenName() {
        String name = BaseActivityScreen.class.getName();

        // [START screen_view_hit]
        Log.i(name, "Setting screen name: " + name);
        mTracker.setScreenName(name);
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
        GoogleAnalytics.getInstance(this).dispatchLocalHits();
        // [END screen_view_hit]
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
        if (fragment instanceof HomeFragment) {
            if (getTitle().toString().equalsIgnoreCase(getString(R.string.title_feed))) {
                getMenuInflater().inflate(R.menu.menu_refresh, menu);
                final View menu_hotlist = menu.findItem(R.id.action_notification).getActionView();
                TextView notification_count = (TextView) menu_hotlist.findViewById(R.id.notification_count);
                if (PreHelper.getNotificationCount(BaseActivityScreen.this).equals("0")) {
                    notification_count.setVisibility(View.GONE);
                } else {
                    notification_count.setVisibility(View.VISIBLE);
                    notification_count.setText(PreHelper.getNotificationCount(BaseActivityScreen.this));
                }
                new MyMenuItemStuffListener(menu_hotlist, "Show My Notification", this);
                return super.onCreateOptionsMenu(menu);
            } else
                return true;
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Logger.d("cek", "home selected");
        switch (item.getItemId()) {
            case android.R.id.home:
                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.container);
                if (currentFragment instanceof HomeFragment) {
                    if (toggle.onOptionsItemSelected(item))
                        return true;
                } else {
                    onBackPressed();
                    return true;
                }
                break;
            case R.id.action_filter:
                DrawerLayout mDrawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                if (mDrawer.isDrawerOpen(Gravity.RIGHT)) {
                    mDrawer.closeDrawer(Gravity.RIGHT);
                } else {
                    mDrawer.openDrawer(Gravity.RIGHT);
                    // if drawer open set  filter data
                    UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
                    tv_distance.setText(userInfo.getFilterDistance());

                    //ArrayList<String> selectedBloodGroupList = android.text.TextUtils.join(",",userInfo.getFilterBloodGroup()) ;
                    // List<String> selectedBloodGroupList = Arrays.asList(userInfo.getFilterBloodGroup().split(","));
                    if (userInfo.getFilterBloodGroup() != null) {
                        List<String> selectedBloodGroupList = Arrays.asList(userInfo.getFilterBloodGroup().split(","));
                        for (String bloodGroup : selectedBloodGroupList) {
                            switch (bloodGroup.toUpperCase()) {
                                case "A+":
                                    chk_APlus.setChecked(true);
                                    break;
                                case "A-":
                                    chk_AMinus.setChecked(true);
                                    break;
                                case "B+":
                                    chk_BPlus.setChecked(true);
                                    break;
                                case "B-":
                                    chk_BMinus.setChecked(true);
                                    break;
                                case "AB+":
                                    chk_ABPlus.setChecked(true);
                                    break;
                                case "AB-":
                                    chk_ABMinus.setChecked(true);
                                    break;
                                case "O+":
                                    chk_OPlus.setChecked(true);
                                    break;
                                case "O-":
                                    chk_OMinus.setChecked(true);
                                    break;
                            }
                        }
                    }
                    //chk_APlus, chk_AMinus, chk_BPlus, chk_BMinus, chk_ABPlus, chk_ABMinus, chk_OPlus, chk_OMinus;

                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.container);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        int id = item.getItemId();
        if (id == R.id.nav_rate_us) {
            RateYourExperience();
        } else if (id == R.id.nav_promote_this_app) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, String.format(getString(R.string.app_play_store_link), getPackageName()));
            sendIntent.setType("text/plain");
            startActivity(Intent.createChooser(sendIntent, getResources().getText(R.string.send_to)));
        } else if (id == R.id.nav_log_out) {
            signOut();
        } else if (id == R.id.nav_update_profile) {
            Bundle bundle = new Bundle();
            bundle.putBoolean(StaticConstant.BLOOD_GROUP_NON_EDITABLE, true);
            UpdateProfileFragment updateProfileFragment = new UpdateProfileFragment();
            updateProfileFragment.setArguments(bundle);
            onReplaceFragment(updateProfileFragment, false);
        } else if (id == R.id.nav_contact_us) {

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + "info@eweblabs.com"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "B+");
            intent.putExtra(Intent.EXTRA_TEXT, "Here is your Text !");
            startActivity(intent);
        } else if (id == R.id.nav_change_password) {
            onReplaceFragment(new ChangePasswordFragment(), false);


        }

        return true;
    }

    private void RateYourExperience() {
        LayoutInflater factory = LayoutInflater.from(this);
        final View deleteDialogView = factory.inflate(
                R.layout.content_rateyourexperience_dialog, null);
        final AlertDialog deleteDialog = new AlertDialog.Builder(this).create();
        deleteDialog.setView(deleteDialogView);
        ((RatingBar) deleteDialogView.findViewById(R.id.ratingbar_default)).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                deleteDialog.dismiss();
                if (rating > 3) {
                    RateToApplication();
                } else {
                    String[] EMail = new String[1];
                    EMail[0] = "bplusapp@gmail.com";
                    shareToGMail(EMail, "Suggest Something", "Briefly explain what could improve \r\nPlease write below this line -----------------------------" + "\r\n");
                }
            }
        });
        deleteDialog.show();
    }

    public void RateToApplication() {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Enjoying " + getString(R.string.app_name) + "?");
        builder.setMessage("Please take moment to rate us on Google Play, it helps us provide free updates.");
        builder.setPositiveButton("RATE " + getString(R.string.app_name), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(getString(R.string.app_play_store_link, getPackageName())))));

            }
        });
        builder.setNegativeButton("NOT NOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void shareToGMail(String[] email, String subject, String content) {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_EMAIL, email);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_TEXT, content);
        final PackageManager pm = getPackageManager();
        final List<ResolveInfo> matches = pm.queryIntentActivities(emailIntent, 0);
        ResolveInfo best = null;
        for (final ResolveInfo info : matches)
            if (info.activityInfo.packageName.endsWith(".gm") || info.activityInfo.name.toLowerCase().contains("gmail"))
                best = info;
        if (best != null)
            emailIntent.setClassName(best.activityInfo.packageName, best.activityInfo.name);
        startActivity(emailIntent);
    }

    private void signOut() {
        UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
        ApplicationContainer.getInstance().getBPlusSavedDBData().resetUserTable();
        if (!TextUtils.isEmpty(userInfo.getAuthBy())) {
            if (userInfo.getAuthBy().equalsIgnoreCase("FaceBook")) {
                FacebookSdk.sdkInitialize(this, new FacebookSdk.InitializeCallback() {
                    @Override
                    public void onInitialized() {
                        Logger.e("BaseActivityScreen", "Facebook sign out");
                        LoginManager.getInstance().logOut();
                    }
                });

            } else if (userInfo.getAuthBy().equalsIgnoreCase("Google")) {
                if (mGoogleApiClient.isConnected()) {
                    Logger.e("BaseActivityScreen", "google sign out");
                    doGoogleSignout();
                } else {
                    isUserSignnedOut = true;
                    buildGoogleApiClient();
                }

            }
        }
        Toast.makeText(BaseActivityScreen.this, getString(R.string.logout_successful), Toast.LENGTH_LONG).show();
        Intent intent = new Intent(BaseActivityScreen.this, AccountActivityScreen.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra(StaticConstant.FRAGMENT_TYPE, 0);
        startActivity(intent);
        finish();


    }

    private void doGoogleSignout() {
        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                        Logger.e("anwar", "onResult");
                    }
                });

        Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                        Logger.e("anwar", "revokeAccess");
                        // [START_EXCLUDE]
                        // [END_EXCLUDE]
                    }
                });
        Logger.e("anwar", "google user signout ");
    }

    public void onReplaceFragment(Fragment fragment, boolean flag) {
        FragmentManager fragmentmanager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentmanager.beginTransaction();
        String backStateName = fragment.getClass().getName();
        if (flag) {
            String s = fragmentmanager.getClass().getName();
            if (!fragmentmanager.popBackStackImmediate(s, 0)) {
                fragmentTransaction.replace(R.id.container, fragment, backStateName);
                fragmentTransaction.addToBackStack(s);
                fragmentTransaction.commit();
            }
            return;
        } else {
            fragmentTransaction.replace(R.id.container, fragment, backStateName);
            fragmentTransaction.commit();
            return;
        }
    }


    NavigationView navigationView;

    public void SetToolbarInitialization(Fragment fragment, String title) {
        navigationView = (NavigationView) findViewById(R.id.nav_view_left);
        setTitle(title);
        if (fragment instanceof BloodRequestFragment || fragment instanceof MyNotificationFragment ||
                fragment instanceof FeedDetailFragment || fragment instanceof MyRequestDetailFragment || fragment instanceof MyNotificationDetailFragment) {
            SetDrawerVisibility(1);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            invalidateOptionsMenu();

            // Deepak Code and comment below
       /*     if (fragment instanceof FeedDetailFragment || fragment instanceof MyRequestDetailFragment) {
                getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(Utils.UseBloodGroupCode(title)));
                setStatusBarColor(title);
            } else {
                getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorPrimary)));
                setStatusBarColor();
            }*/

            getSupportActionBar().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.colorPrimary)));
            setStatusBarColor();
        } else {
            getSupportActionBar().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.colorPrimary)));
            setStatusBarColor();
            SetDrawerVisibility(0);
            navigationView.invalidate();
            invalidateOptionsMenu();

        }

    }

    public void setStatusBarColor(String title) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, Utils.UseColorBloodGroupCode(title)));
        }
    }

    public void setStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START))
            drawer.closeDrawer(GravityCompat.START);
        else {
            FragmentManager fm = getSupportFragmentManager();
            Fragment fragment = fm.findFragmentById(R.id.container);
            if (fragment instanceof FeedFragment)
                ((FeedFragment) fragment).onCancelFragment();
            if (fragment instanceof AcceptRequestFragment)
                ((FeedFragment) fragment).onCancelFragment();


            if (fm.getBackStackEntryCount() > 0) {
                fm.popBackStack();
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            } else {
                if (fragment instanceof HomeFragment) {
                    ApplicationContainer.getInstance().getBPlusSavedDBData().resetFeedsDetail();
                    ApplicationContainer.getInstance().getBPlusSavedDBData().resetAcceptRequestDetail();
                    super.onBackPressed();
                    bloodGroupStringArrayList.clear();
                } else
                    onReplaceFragment(new HomeFragment(), false);
            }
            if (fragment instanceof MyNotificationDetailFragment) {
                SetToolbarInitialization(fragment, "Notification");
            }


        }


    }

    public void SetDrawerVisibility(int status) {
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView nav_view_right = (NavigationView) findViewById(R.id.nav_view_right);
        NavigationView nav_view_left = (NavigationView) findViewById(R.id.nav_view_left);
        if (status == 0) {
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, nav_view_left);
            toggle.onDrawerStateChanged(DrawerLayout.LOCK_MODE_UNLOCKED);
            toggle.setDrawerIndicatorEnabled(true);
            toggle.syncState();
        } else if (status == 1) {
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, nav_view_left);
            toggle.onDrawerStateChanged(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            toggle.setDrawerIndicatorEnabled(false);
            toggle.syncState();
        }
    }

    @Override
    public void onMenuClick() {
        PreHelper.storeNotificationCount(BaseActivityScreen.this, "0");
        onReplaceFragment(new MyNotificationFragment(), true);
    }


    private android.location.Location mLastLocation;
    private GoogleApiClient mGoogleApiClient;
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 1000;

    public boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil
                .isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Toast.makeText(getApplicationContext(),
                        "This device is not supported.", Toast.LENGTH_LONG)
                        .show();
                finish();
            }
            return false;
        }
        return true;
    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .addApi(Plus.API)
                .addApi(Auth.GOOGLE_SIGN_IN_API).build();
        mGoogleApiClient.connect();

      /*  mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .addApi(Plus.API)
                .build();*/
    }

    public android.location.Location displayLocation() {
        mLastLocation = getLocation();
        if (mLastLocation != null) {
            double latitude = mLastLocation.getLatitude();
            double longitude = mLastLocation.getLongitude();
            PreHelper.storeDouble(getApplicationContext(), StaticConstant.APP_LATITUDE, latitude);
            PreHelper.storeDouble(getApplicationContext(), StaticConstant.APP_LONGITUDE, longitude);
            android.location.Location CurrentLocation = new android.location.Location("");
            CurrentLocation.setLatitude(latitude);
            CurrentLocation.setLongitude(longitude);
            ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
            for (Feed feed : ApplicationContainer.getInstance().getBPlusSavedDBData().getFeeds()) {
                android.location.Location FeedLocation = new android.location.Location("");
                feed.setLattitude(feed.getLattitude());
                feed.setLongitude(feed.getLongitude());
                double distanceInMeters = FeedLocation.distanceTo(CurrentLocation);
                feed.setDistance(distanceInMeters);
                ApplicationContainer.getInstance().getBPlusSavedDBData().UpdateFeedDistance(feed);
            }
        }
        return mLastLocation;
    }

    public android.location.Location getLocation() {

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return null;
        }
        return LocationServices.FusedLocationApi
                .getLastLocation(mGoogleApiClient);
    }

    public void ShowGPSEnable() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Location is not enabled.Do you want to go to settings menu?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent I = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(I);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });
        android.app.AlertDialog alert = builder.create();
        alert.show();
    }


    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.i("BaseActivityScreen", "Connection failed: ConnectionResult.getErrorCode() = "
                + result.getErrorCode());
    }

    @Override
    public void onConnected(Bundle arg0) {
        // Once connected with google api, get the location
        //displayLocation();
        if (checkPlayServices()) {
            displayLocation();
        }
        if (isUserSignnedOut) {
            doGoogleSignout();
            isUserSignnedOut = false;
        }
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onStop() {
        super.onStop();
        mGoogleApiClient.disconnect();
    }

    CustomLoadingDialog loadingDialog;
    AuthCommonTask authCommonTask;

    public void PerformUpdateProfileProcess(String userid, String bloodGroup, String address, String country, String state, String city, String zipcode, String phone) {
        loadingDialog = new CustomLoadingDialog(BaseActivityScreen.this);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(StaticConstant.USER_ID, userid);
        hashMap.put(StaticConstant.BLOOD_GROUP, bloodGroup);
        hashMap.put(StaticConstant.ADDRESS, address);
        hashMap.put(StaticConstant.COUNTRY, country);
        hashMap.put(StaticConstant.CITY, city);
        hashMap.put(StaticConstant.STATE, state);
        hashMap.put(StaticConstant.ZIPCODE, zipcode);
        hashMap.put(StaticConstant.PHONE, phone);
        authCommonTask = new AuthCommonTask(BaseActivityScreen.this, BaseNetwork.UPDATE_PROFILE_METHOD, this, loadingDialog);
        authCommonTask.execute(hashMap);
    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }

    @Override
    public Context getContext() {
        return null;
    }

    @Override
    public void taskCompleted(Object obj) {
        if (obj != null) {
            ResultMessage resultMessage = (ResultMessage) obj;
            if (resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.UPDATE_PROFILE_METHOD)) {
                UserInfo userInfo = (UserInfo) resultMessage.RESULT_OBJECT;
                if (userInfo.getSuccess() == 1) {
                    Utils.showToast(BaseActivityScreen.this, userInfo.getMessage());
                    Intent intent = new Intent(BaseActivityScreen.this, BaseActivityScreen.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                } else if (userInfo.getSuccess() == 0)
                    Utils.ShowAlertDialog(BaseActivityScreen.this, userInfo.getMessage(), this, null);

            }
        }
    }

    @Override
    public void taskErrorMessage(Object obj) {

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }
}
