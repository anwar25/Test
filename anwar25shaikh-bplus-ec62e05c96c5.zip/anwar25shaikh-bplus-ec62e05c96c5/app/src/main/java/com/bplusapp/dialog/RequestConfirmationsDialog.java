package com.bplusapp.dialog;

import android.app.Dialog;
import android.content.Context;
import android.widget.ListView;
import android.widget.TextView;

import com.bplusapp.Adapter.RecieverInfoAdapter;
import com.bplusapp.Entity.MyRequestDescriptionDataClass;
import com.bplusapp.R;
import com.bplusapp.UI.CustomTextView;

import java.util.List;

/**
 * Created by DEEPAK on 5/25/2016.
 */
public class RequestConfirmationsDialog extends Dialog {

    private ListView list_recievers ;
    private TextView text_no_of_confirmation;
    private RecieverInfoAdapter recieverInfoAdapter ;

    public RequestConfirmationsDialog(Context context,  List<MyRequestDescriptionDataClass> myRequestDescriptionDataClasses) {
        super(context);
        setContentView(R.layout.confirmation_dialog);

        list_recievers = (ListView) findViewById(R.id.list_recievers);
        text_no_of_confirmation = (CustomTextView) findViewById(R.id.text_no_of_confirmation);

        if(myRequestDescriptionDataClasses != null && myRequestDescriptionDataClasses.size() > 0){
            text_no_of_confirmation.setText(myRequestDescriptionDataClasses.get(0).getNumberOfConfirmation());
            recieverInfoAdapter = new RecieverInfoAdapter(context, myRequestDescriptionDataClasses,false);
            list_recievers.setAdapter(recieverInfoAdapter);
        }

       /* String[] names = new String[] { "Android", "Windows7", "Symbian", "iPhone",
                "Android", "Windows7", "Symbian", "iPhone",
                "Android", "Windows7", "Symbian", "iPhone" };
        ArrayAdapter<String> ad = new ArrayAdapter<String>(context,
                android.R.layout.simple_list_item_single_choice,
                android.R.id.text1, names);
        list_recievers.setAdapter(ad);
        list_recievers.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
*/
     //   list_recievers.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        /*list_recievers.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ((ListView)parent).setItemChecked(position, true);
            }
        });*/
    }
}
