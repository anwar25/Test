package com.bplusapp.Home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bplusapp.AcceptedRequests.AcceptRequestFragment;
import com.bplusapp.Adapter.ViewPagerAdapter;
import com.bplusapp.Feed.FeedFragment;
import com.bplusapp.Interface.IFragmentLifeCycle;
import com.bplusapp.MyRequests.MyRequestFragment;
import com.bplusapp.UI.NonSwipeableViewPager;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.R;

/**
 * Created by Akash.Singh on 1/13/2016.
 */
public class HomeFragment extends Fragment {

    public NonSwipeableViewPager viewPager;
    TabLayout tabs_bottom;
    ViewPagerAdapter adapter;

    public HomeFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.homefragment, container, false);
        MidMapping(rootView);
        return rootView;

    }

    private void MidMapping(View rootView) {
        viewPager = (NonSwipeableViewPager) rootView.findViewById(R.id.viewpager);
        tabs_bottom = (TabLayout) rootView.findViewById(R.id.tabs_bottom);
        setupViewPager();
    }

    private void setupViewPager() {
        adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFrag(new FeedFragment(), "");
        adapter.addFrag(new MyRequestFragment(), "");
        adapter.addFrag(new AcceptRequestFragment(), "");
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(1);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            int currentPosition = 0;
            public void onPageScrollStateChanged(int state) {

            }

            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            public void onPageSelected(int newPosition) {
                SetTitleMessage(newPosition);
                IFragmentLifeCycle fragmentToShow = (IFragmentLifeCycle)adapter.getItem(newPosition);
               // fragmentToShow.onResumeFragment();

                IFragmentLifeCycle fragmentToHide = (IFragmentLifeCycle)adapter.getItem(currentPosition);
               // fragmentToHide.onPauseFragment();
                currentPosition = newPosition;

            }
        });
        viewPager.setCurrentItem(0);
        tabs_bottom.setupWithViewPager(viewPager);
        setupTabIcons();
        SetTitleMessage(viewPager.getCurrentItem());
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void setupTabIcons() {
        tabs_bottom.getTabAt(0).setIcon(R.drawable.ic_home_white_24dp);
        tabs_bottom.getTabAt(1).setIcon(R.drawable.ic_blood_request);
        tabs_bottom.getTabAt(2).setIcon(R.drawable.ic_blood_donner);
    }

    private void SetTitleMessage(int position) {
        switch (position) {
            case 0:
                ((BaseActivityScreen) getActivity()).SetToolbarInitialization(this, getString(R.string.title_feed));
                break;
            case 1:
                ((BaseActivityScreen) getActivity()).SetToolbarInitialization(this, getString(R.string.my_requests));
                break;
            case 2:
                ((BaseActivityScreen) getActivity()).SetToolbarInitialization(this, getString(R.string.history));
                break;
        }

    }
}