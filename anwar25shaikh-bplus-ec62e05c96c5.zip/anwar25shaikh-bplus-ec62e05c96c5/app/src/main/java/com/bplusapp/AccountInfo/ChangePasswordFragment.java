package com.bplusapp.AccountInfo;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Utils;

import java.util.HashMap;

/**
 * Created by DEEPAK on 6/23/2016.
 */
public class ChangePasswordFragment extends Fragment implements IAsyncTaskRunner, IDialogClick{

    private EditText et_old_password, et_new_password, et_confirm_password;
    private Button btn_change_password;

    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_change_password,container,false);

        et_old_password = (EditText) view.findViewById(R.id.et_old_password);
        et_new_password = (EditText) view.findViewById(R.id.et_new_password);
        et_confirm_password = (EditText) view.findViewById(R.id.et_confirm_password);

        et_old_password.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
        et_new_password.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
        et_confirm_password.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));

        btn_change_password = (Button) view.findViewById(R.id.btn_change_password);
        btn_change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Validation()){
                    String newPassword = et_new_password.getText().toString();
                    String confirmPassword = et_confirm_password.getText().toString();
                    String oldPassword = et_old_password.getText().toString();
                    performChangePasswordProcess(oldPassword, newPassword, confirmPassword);
                }

            }
        });


        ((BaseActivityScreen)getActivity()).SetToolbarInitialization(this, getString(R.string.title_change_password));

        return view;

    }

    private void performChangePasswordProcess(String oldPassword, String newPassword, String confirmPassword) {

        loadingDialog = new CustomLoadingDialog(getActivity());
        authCommonTask = new AuthCommonTask(getActivity(), BaseNetwork.CHANGE_PASSWORD_METHOD, this, loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("oldPassword", oldPassword);
        hashMap.put("newPassword", newPassword);
        hashMap.put("userId", ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
        hashMap.put("confirmPassword", confirmPassword);
        authCommonTask.execute(hashMap);
    }

    private boolean Validation(){
        if(TextUtils.isEmpty(et_old_password.getText().toString())) {
            et_old_password.setError(getString(R.string.hint_please_enter_your_old_pass));
            return false;
        }
        else if(TextUtils.isEmpty(et_new_password.getText().toString()) ){
            et_new_password.setError(getString(R.string.hint_please_enter_your_new_pass));
            return false;
        }else if(TextUtils.isEmpty(et_confirm_password.getText().toString())) {
            et_confirm_password.setError(getString(R.string.hint_please_enter_your_confirm_pass));
            return false;
        }else if(!et_new_password.getText().toString().equalsIgnoreCase(et_confirm_password.getText().toString())) {
            et_confirm_password.setError(getString(R.string.hint_please_enter_your_match_pass));
            return false;
        }

        return  true;
    }


    @Override
    public void taskCompleted(Object obj) {

        if (obj != null) {

            ResultMessage resultMessage = (ResultMessage) obj;
            if (resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.CHANGE_PASSWORD_METHOD)) {
                ResponseMessage userInfo = (ResponseMessage) resultMessage.RESULT_OBJECT;
                Toast.makeText(getActivity(), userInfo.getMessage(), Toast.LENGTH_LONG).show();
                if(userInfo.getStatus() == 1){
                    Intent intent = new Intent(getActivity(), BaseActivityScreen.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    getActivity().getSupportFragmentManager().popBackStack();
                }

            }
        }
    }

    @Override
    public void taskErrorMessage(Object obj) {

        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }
}
