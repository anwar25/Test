package com.bplusapp.AccountInfo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bplusapp.BaseActivityScreen;
import com.bplusapp.R;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomEditView;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.UI.CustomTextWatcher;
import com.bplusapp.Utils.Utils;

/**
 * Created by Akash.Singh on 2/3/2016.
 */
public class ForgotPasswordFragment extends Fragment implements View.OnClickListener {
    CustomEditView edit_email_address;
    TextInputLayout input_email_address;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_forgot_password_screen,container,false);
        ((AccountActivityScreen)getActivity()).SetToolbarInitialization(this,getString(R.string.forget_password));
        WidgetMapping(view);
        return view;
    }

    private void WidgetMapping(View view) {
        ((AppCompatButton)view.findViewById(R.id.btnForgetPassword)).setOnClickListener(this);
        edit_email_address = (CustomEditView) view.findViewById(R.id.edit_email_address);
        input_email_address = (TextInputLayout) view.findViewById(R.id.input_email_address);
        edit_email_address.addTextChangedListener(new CustomTextWatcher(input_email_address));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnForgetPassword:
                if(Validation()){
                    ((AccountActivityScreen)getActivity()).PerformForgotPasswordProcess(edit_email_address.getText().toString());
                }
                break;
        }
    }

    private boolean Validation(){
        if(TextUtils.isEmpty(edit_email_address.getText().toString())) {
            input_email_address.setError(getString(R.string.hint_please_enter_your_email_address));
            return false;
        }
        else if(!TextUtils.isEmpty(edit_email_address.getText().toString()) && !Utils.validateEmail(edit_email_address.getText().toString())){
            input_email_address.setError(getString(R.string.hint_please_enter_valid_email_password));
            return false;
        }
        return  true;
    }
}
