package com.bplusapp.AcceptedRequests;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bplusapp.Adapter.FeedsAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Feed.FeedDetailFragment;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Interface.IFeedItemListener;
import com.bplusapp.Interface.IFragmentLifeCycle;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.Utils.Logger;
import com.bplusapp.Utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Akash.Singh on 1/29/2016.
 */
public class AcceptRequestFragment extends Fragment implements IAsyncTaskRunner, SwipeRefreshLayout.OnRefreshListener, IFragmentLifeCycle
        , IDialogClick, IFeedItemListener {
    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    ArrayList<Feed> categoryArrayList = new ArrayList<Feed>();
    SwipeRefreshLayout swipeRefreshLayout;
    private TextView tv_empty;

    public AcceptRequestFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_feed_screen, container, false);
        WidgetMapping(view);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        onResumeFragment();
    }


    private void WidgetMapping(View rootView) {
        swipeRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.swipe_refresh_layout);
        tv_empty = (TextView) rootView.findViewById(R.id.tv_empty);
        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                R.color.colorPrimaryDark,
                R.color.background);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);

        FloatingActionButton fab = (FloatingActionButton) rootView.findViewById(R.id.fab);
        fab.setVisibility(View.INVISIBLE);
    }

    AuthCommonTask authCommonTask;

    public void PerformProcessProcess() {
        swipeRefreshLayout.setRefreshing(true);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("senderId", "" + ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
        authCommonTask = new AuthCommonTask(getActivity(), this, BaseNetwork.ACCEPTED_REQUEST);
        authCommonTask.execute(hashMap);
    }

    @Override
    public Context getContext() {
        return getActivity();
    }

    @Override
    public void taskCompleted(Object obj) {
        swipeRefreshLayout.setRefreshing(false);
        if (obj != null) {
            ResultMessage resultMessage = (ResultMessage) obj;
            ResponseMessage responseItem = (ResponseMessage) resultMessage.RESULT_OBJECT;
            if (responseItem.getStatus() == 1) {
                {
                    // ((BaseActivityScreen)getActivity()).displayLocation(); Deepak comment
                    categoryArrayList = new ArrayList<Feed>();
                    //for (Object object: ApplicationContainer.getInstance().getBPlusSavedDBData().getAcceptRequestFeeds()) {
                    for (Object object : responseItem.getObjectArrayList()) {
                        categoryArrayList.add((Feed) object);
                    }
                    CreateOfferDetail();
                }
            } else if (!TextUtils.isEmpty(responseItem.getMessage())) {
                //Utils.ShowAlertDialog(getActivity(),responseItem.getMessage(), this, null);

            }
        }

    }

    private void CreateOfferDetail() {
        Logger.d("categoryArrayList", "::" + categoryArrayList.size());
        if (categoryArrayList.size() > 0) {
            mRecyclerView.setVisibility(View.VISIBLE);
            mLayoutManager = new GridLayoutManager(getActivity(), 1);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mAdapter = new FeedsAdapter(getActivity(), categoryArrayList, "Accepted Request", this);
            mRecyclerView.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
            tv_empty.setText("No Accept Request Found");
            tv_empty.setVisibility(View.INVISIBLE);
        } else {
            mRecyclerView.setVisibility(View.VISIBLE);
            mLayoutManager = new GridLayoutManager(getActivity(), 1);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mAdapter = new FeedsAdapter(getActivity(), categoryArrayList, "Accepted Request", this);
            mRecyclerView.setAdapter(mAdapter);
            tv_empty.setText("No Accept Request Found");
            // Utils.ShowAlertDialog(getActivity(), "No Accept Request Found", this, null);
            tv_empty.setVisibility(View.VISIBLE);
        }
    }


    @Override
    public void taskErrorMessage(Object obj) {
        mRecyclerView.setVisibility(View.VISIBLE);
        mLayoutManager = new GridLayoutManager(getActivity(), 1);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new FeedsAdapter(getActivity(), categoryArrayList, "Accepted Request", this);
        mRecyclerView.setAdapter(mAdapter);
        swipeRefreshLayout.setRefreshing(false);
        ResultMessage resultMessage = (ResultMessage) obj;
        if (resultMessage != null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);


    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    public void onCancelFragment() {

        if (authCommonTask != null) {
            if (!authCommonTask.isCancelled())
                authCommonTask.cancel(true);
        }
    }

    @Override
    public void onRefresh() {
        swipeRefreshLayout.setRefreshing(true);
        PerformProcessProcess();
    }

    String TAG = "AcceptRequestFragment";

    @Override
    public void onPauseFragment() {
        onCancelFragment();
    }

    @Override
    public void onResumeFragment() {
        categoryArrayList = new ArrayList<>();
        for (Object object : ApplicationContainer.getInstance().getBPlusSavedDBData().getAcceptRequestFeeds()) {
            categoryArrayList.add((Feed) object);
        }
        //Deepak wrote below line
        categoryArrayList.clear();
        if (categoryArrayList.size() == 0)
            PerformProcessProcess();
        else
            CreateOfferDetail();

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }

    @Override
    public void feedItemClicked(Feed feed, String fragmentName) {
        Bundle bundle = new Bundle();
        bundle.putString("requestId", String.valueOf(feed.getId()));
        if (fragmentName.equalsIgnoreCase("Accepted Request")) {
            bundle.putString("FragmentName", fragmentName);
            bundle.putInt(StaticConstant.DONATED, feed.getDonated());
        }
        FeedDetailFragment feedDetailFragment = new FeedDetailFragment();
        feedDetailFragment.setArguments(bundle);
        ((BaseActivityScreen) getContext()).onReplaceFragment(feedDetailFragment, true);

    }
}
