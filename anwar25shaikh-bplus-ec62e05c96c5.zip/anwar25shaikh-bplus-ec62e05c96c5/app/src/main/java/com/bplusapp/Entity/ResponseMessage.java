package com.bplusapp.Entity;

import java.util.ArrayList;

/**
 * Created by Anil on 12/15/2015.
 */
public class ResponseMessage {

    int status;
    String message;
    Object object;

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    ArrayList<Object> ObjectArrayList =  new ArrayList<>();

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<Object> getObjectArrayList() {
        return ObjectArrayList;
    }

    public void setObjectArrayList(ArrayList<Object> objectArrayList) {
        ObjectArrayList = objectArrayList;
    }
}
