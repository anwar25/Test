package com.bplusapp.UI;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.CheckBox;
import com.bplusapp.R;

/**
 * Created by Akash.Singh on 6/2/2015.
 * This is custom TextView class. This class use declare font on global
 */
public class CustomCheckBox extends CheckBox{

    private static final String LatoBold= "LatoBold";
    private static final String LatoRegular= "LatoRegular";


    public CustomCheckBox(Context context, AttributeSet attrs) {
        super(context, attrs);
        if(!isInEditMode()) {
            Init(attrs);
        }
    }

    private void Init(AttributeSet  attributeset) {
            if (attributeset != null)
            {
                TypedArray attributeset1 = getContext().obtainStyledAttributes(attributeset, R.styleable.CustomCheckBox);
                String s = attributeset1.getString(0);
                if(LatoBold.equals(s)){
                    setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoBold.ttf"));
                }
                else if(LatoRegular.equals(s)){
                    setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
                }
                attributeset1.recycle();
            }
  }
}
