package com.bplusapp.Interface;

import java.util.HashMap;


/**
 * Created by Akash.Singh on 6/4/2015.
 */
public interface IDataModel {
    void PopulateCountryList();
    HashMap<Object,Object> GetCountryList();
    void PopulateBloodGroupList();
    HashMap<Object,Object> GetBloodGroupList();
}
