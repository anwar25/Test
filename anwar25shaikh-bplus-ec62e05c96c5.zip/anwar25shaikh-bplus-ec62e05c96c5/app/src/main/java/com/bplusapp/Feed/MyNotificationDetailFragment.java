package com.bplusapp.Feed;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bplusapp.Adapter.MyNotificationAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.DialogActivity;
import com.bplusapp.Entity.AllNotificationDataClass;
import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.NotificationDescriptionDataClass;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.Utils.Utils;
import com.bplusapp.loader.ImageLoaderRect;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.R;
import com.bplusapp.map.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Akash.Singh on 1/20/2016.
 */
public class MyNotificationDetailFragment extends Fragment implements IAsyncTaskRunner, IDialogClick, View.OnClickListener {

    private CustomTextView text_blood_group,text_hospital_name,requester_name,requester_date_time,requester_phone,text_hospitalAddress;
    private FloatingActionButton fab_phone, fab_msg, fab_share;
    private ImageView img_map;
    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;
    private List<NotificationDescriptionDataClass> notificationDescriptionDataClassList;
    private AppCompatButton btnPostBloodRequest;

    private MapFragment mMapFragment ;
 //   public static double lat;
 //   public static double lon;

    public MyNotificationDetailFragment(){

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mMessageReceiver,
                new IntentFilter("custom-event-name"));
        performNotificationDetailProcess();
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_feed_detail_screen,container,false);

        WidgetMapping(view);

        return view;
    }

    private void WidgetMapping(View view) {
        FragmentManager fm = getChildFragmentManager();
        mMapFragment = (MapFragment) fm.findFragmentById(R.id.map);
        if (mMapFragment == null) {
            mMapFragment = (MapFragment) SupportMapFragment.newInstance();
            fm.beginTransaction().replace(R.id.map, mMapFragment).commit();
        }
        text_blood_group = (CustomTextView) view.findViewById(R.id.text_blood_group);
        text_hospital_name = (CustomTextView) view.findViewById(R.id.text_hospital_name);
        requester_name = (CustomTextView) view.findViewById(R.id.requester_name);
        requester_date_time = (CustomTextView) view.findViewById(R.id.requester_date_time);
        requester_phone = (CustomTextView) view.findViewById(R.id.requester_phone);
        text_hospitalAddress = (CustomTextView) view.findViewById(R.id.text_hospitalAddress);
       //img_map = (ImageView) view.findViewById(R.id.img_map);

        btnPostBloodRequest = (AppCompatButton) view.findViewById(R.id.btnPostBloodRequest);
        fab_phone = (FloatingActionButton) view.findViewById(R.id.fab_phone);
        fab_msg = (FloatingActionButton) view.findViewById(R.id.fab_msg);
        fab_share = (FloatingActionButton) view.findViewById(R.id.fab_share);

        fab_phone.setOnClickListener(this);
        fab_msg.setOnClickListener(this);
        fab_share.setOnClickListener(this);
        btnPostBloodRequest.setOnClickListener(this);



    }

    private void performNotificationDetailProcess() {

        loadingDialog =  new CustomLoadingDialog(getActivity());
        authCommonTask =  new AuthCommonTask(getActivity(), BaseNetwork.REQUEST_DESCRIPTION,this,loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        String id = getArguments().getString("requestId");
        hashMap.put("requestId", id);
        authCommonTask.execute(hashMap);
    }


    @Override
    public void taskCompleted(Object obj) {
        if(obj!=null){
            ResultMessage resultMessage = (ResultMessage) obj;
            if(resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.REQUEST_DESCRIPTION)){
                notificationDescriptionDataClassList  = (ArrayList<NotificationDescriptionDataClass>) resultMessage.RESULT_OBJECT;
                SetFeedValue(notificationDescriptionDataClassList);
            }
        }
    }

    @Override
    public void taskErrorMessage(Object obj) {
        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);
    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }

    private void SetFeedValue( List<NotificationDescriptionDataClass> feed) {
        text_blood_group.setBackground(getActivity().getResources().getDrawable(Utils.UseBloodGroupCode(feed.get(0).getBloodGroup())));
        text_blood_group.setText(feed.get(0).getBloodGroup());
        requester_name.setText(feed.get(0).getRequesterName());
        text_hospital_name.setText("Urgent Requirement at "+feed.get(0).getHospitalName());
        // requester_date_time.setText(Utils.ConvertDateFormat(feed.get(0).getDate()));
        requester_date_time.setText(feed.get(0).getRequestedDate());
        text_hospitalAddress.setText(feed.get(0).getHospitalAddr());
        requester_phone.setText(feed.get(0).getPhone());

       // ImageLoaderRect imageLoader =  new ImageLoaderRect(getActivity());
       // String URL = "https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=600x250&" +
        //        "sensor=false&maptype=roadmap&markers=color:0xff6600%7C"+Double.parseDouble(feed.get(0).getLattitude()) +","+Double.parseDouble(feed.get(0).getLongitude()) + "&key=" + getString(R.string.google_maps_key);
       // imageLoader.DisplayImage(URL, img_map);



        ((BaseActivityScreen)getActivity()).SetToolbarInitialization(this, feed.get(0).getBloodGroup());
        Location location  = new Location("");
        location.setLatitude(Double.parseDouble(feed.get(0).getLattitude()));
        location.setLongitude(Double.parseDouble(feed.get(0).getLongitude()));
        mMapFragment.setmCurrentLocation(location);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.fab_phone :

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" +notificationDescriptionDataClassList.get(0).getPhone()));
                startActivity(intent);

                break;

            case R.id.fab_msg :

                String message = "Help me! there is urgent requirement for blood("+   notificationDescriptionDataClassList.get(0).getBloodGroup()+ ")  on hospital("+notificationDescriptionDataClassList.get(0).getHospitalName()+").If you donate your blood we will very thankful to you.";
                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                sendIntent.putExtra("address"  , new String(notificationDescriptionDataClassList.get(0).getPhone()));
                sendIntent.putExtra("sms_body", message);
                sendIntent.setType("vnd.android-dir/mms-sms");
                startActivity(sendIntent);
                break;


            case R.id.fab_share :

                String message1 = "Help me! there is urgent requirement for blood("+   notificationDescriptionDataClassList.get(0).getBloodGroup()+ ")  on hospital("+notificationDescriptionDataClassList.get(0).getHospitalName()+").If you donate your blood we will very thankful to you.";
                Intent sendIntent1 = new Intent();
                sendIntent1.setAction(Intent.ACTION_SEND);
                sendIntent1.putExtra(Intent.EXTRA_TEXT, String.format(getString(R.string.app_message) + message1, getActivity().getPackageName()));
                sendIntent1.setType("text/plain");
                startActivity(Intent.createChooser(sendIntent1, getResources().getText(R.string.send_to)));
                break;


            case R.id.btnPostBloodRequest :

                Intent mIntent1 = new Intent(getActivity(), DialogActivity.class);
                mIntent1.putExtra("requestId", notificationDescriptionDataClassList.get(0).getId());
                mIntent1.putExtra("senderId",  notificationDescriptionDataClassList.get(0).getUserId());
                mIntent1.putExtra("receiverId", ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
                mIntent1.putExtra("reqStatus","1");
                startActivityForResult(mIntent1,101);

                break;
        }
    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            btnPostBloodRequest.setText("Accepted");
            btnPostBloodRequest.setClickable(false);
            btnPostBloodRequest.setBackgroundResource(R.drawable.app_rectangle_accepted_button);
        }
    };



    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mMessageReceiver);
        super.onDestroy();
    }
}
