package com.bplusapp.Feed;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bplusapp.Adapter.FeedsAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.BloodRequest.BloodRequestFragment;
import com.bplusapp.Entity.Feed;
import com.bplusapp.Entity.ResponseMessage;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Interface.IFeedItemListener;
import com.bplusapp.Interface.IFragmentLifeCycle;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.R;
import com.bplusapp.SharedPreferences.PreHelper;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Logger;
import com.bplusapp.Utils.Utils;
import com.bplusapp.map.GPSTracker;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Akash.Singh on 1/5/2016.
 */
public class FeedFragment extends Fragment implements IAsyncTaskRunner, SwipeRefreshLayout.OnRefreshListener
        , IFragmentLifeCycle, IDialogClick, IFeedItemListener {
    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    ArrayList<Feed> categoryArrayList = new ArrayList<>();
    SwipeRefreshLayout swipeRefreshLayout;
    private TextView tv_empty;
    private CustomLoadingDialog loadingDialog1;

    public FeedFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_feed_screen, container, false);
        loadingDialog1 = new CustomLoadingDialog(getActivity());
        loadingDialog1.show();
        WidgetMapping(view);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        onResumeFragment();
    }

    private void WidgetMapping(View rootView) {
        swipeRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.swipe_refresh_layout);
        tv_empty = (TextView) rootView.findViewById(R.id.tv_empty);
        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                R.color.colorPrimaryDark,
                R.color.background);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        FloatingActionButton fab = (FloatingActionButton) rootView.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((BaseActivityScreen) getActivity()).onReplaceFragment(new BloodRequestFragment(), true);
            }
        });
    }

    AuthCommonTask authCommonTask;
    GPSTracker gps;
    double latitude;
    double longitude;

    public void PerformProcessProcess() {

        loadingDialog = new CustomLoadingDialog(getActivity());
        gps = new GPSTracker(getActivity());
        if (gps.canGetLocation()) {
            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
        } else {
            gps.showSettingsAlert();
        }
        swipeRefreshLayout.setRefreshing(true);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("lattitude", "" + PreHelper.getStoredDouble(getActivity(), StaticConstant.APP_LATITUDE));
        hashMap.put("longitude", "" + PreHelper.getStoredDouble(getActivity(), StaticConstant.APP_LONGITUDE));

        hashMap.put("lattitude", String.valueOf(latitude));
        hashMap.put("longitude", String.valueOf(longitude));
        hashMap.put("userId", ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
        hashMap.put("distance", "" + ((BaseActivityScreen) getActivity()).DISTANCE);
        authCommonTask = new AuthCommonTask(getActivity(), BaseNetwork.FEEDS_METHOD, this, loadingDialog);
        authCommonTask.execute(hashMap);
    }

    CustomLoadingDialog loadingDialog;

    public void PerformFilterProcess(String latitude, String longitude, String bloodGroup, String distance) {


        loadingDialog = new CustomLoadingDialog(getActivity());
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put(StaticConstant.LATTITUDE, latitude);
        hashMap.put(StaticConstant.LONGITUDE, longitude);
        hashMap.put(StaticConstant.BLOOD_GROUP, bloodGroup);
        hashMap.put(StaticConstant.DISTANCE, distance);
        hashMap.put(StaticConstant.USER_ID, ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
        authCommonTask = new AuthCommonTask(getActivity(), BaseNetwork.FILTER_REQUESETS, this, loadingDialog);
        authCommonTask.execute(hashMap);
    }


    @Override
    public Context getContext() {
        return getActivity();
    }

    @Override
    public void taskCompleted(Object obj) {

        if (loadingDialog1.isShowing())
            loadingDialog1.dismiss();
        swipeRefreshLayout.setRefreshing(false);
        if (obj != null) {
            ResultMessage resultMessage = (ResultMessage) obj;
            ResponseMessage responseItem = (ResponseMessage) resultMessage.RESULT_OBJECT;
            if (responseItem.getStatus() == 1) {
                {
                    categoryArrayList.clear();
                    ArrayList<Object> al = responseItem.getObjectArrayList();

                    for (Object object : al) {
                        categoryArrayList.add((Feed) object);
                    }

                    //((BaseActivityScreen)getActivity()).displayLocation(); Deepak comment
                   /* categoryArrayList =  new ArrayList<>();
                    for (Object object: ApplicationContainer.getInstance().getBPlusSavedDBData().getFeeds()) {
                        categoryArrayList.add((Feed) object);
                    } *///Deepak comment

                    ApplicationContainer.getInstance().getBPlusSavedDBData().resetFeedsDetail();
                    CreateOfferDetail();

                }
            } else if (!TextUtils.isEmpty(responseItem.getMessage())) {
                //Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);
            }
        }
    }

    private void CreateOfferDetail() {
        Logger.d("categoryArrayList", "::" + categoryArrayList.size());
        if (categoryArrayList.size() > 0) {
            mLayoutManager = new GridLayoutManager(getActivity(), 1);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mAdapter = new FeedsAdapter(getActivity(), categoryArrayList, "Feed Fragment", this);
            mRecyclerView.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
            tv_empty.setVisibility(View.INVISIBLE);
        } else {
            mRecyclerView.setVisibility(View.VISIBLE);
            mLayoutManager = new GridLayoutManager(getActivity(), 1);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mAdapter = new FeedsAdapter(getActivity(), categoryArrayList, "Feed Fragment", this);
            mRecyclerView.setAdapter(mAdapter);
            //Utils.ShowAlertDialog(getActivity(), "No Feed Found", this,null);
            tv_empty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void taskErrorMessage(Object obj) {
        mRecyclerView.setVisibility(View.VISIBLE);
        mLayoutManager = new GridLayoutManager(getActivity(), 1);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new FeedsAdapter(getActivity(), categoryArrayList, "Feed Fragment", this);
        mRecyclerView.setAdapter(mAdapter);
        swipeRefreshLayout.setRefreshing(false);
        ResultMessage resultMessage = (ResultMessage) obj;
        if (resultMessage != null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    public void onCancelFragment() {

        if (authCommonTask != null) {
            if (!authCommonTask.isCancelled())
                authCommonTask.cancel(true);
        }
    }

    @Override
    public void onRefresh() {
        swipeRefreshLayout.setRefreshing(true);
        PerformProcessProcess();
    }

    String TAG = "FeedFragment";

    @Override
    public void onPauseFragment() {
        onCancelFragment();
    }

    @Override
    public void onResumeFragment() {
        categoryArrayList = new ArrayList<>();
        for (Object object : ApplicationContainer.getInstance().getBPlusSavedDBData().getFeeds()) {
            categoryArrayList.add((Feed) object);
        }
        categoryArrayList.clear();
        if (categoryArrayList.size() == 0) {
         /*   if(!BaseActivityScreen.bloodGroup.toString().equalsIgnoreCase("")){
                PerformFilterProcess("28.599206","77.346050",BaseActivityScreen.bloodGroup.toString(), "5");
            }else {
                PerformProcessProcess();
            }*/


            if (BaseActivityScreen.bloodGroupStringArrayList.size() == 0) {
                PerformProcessProcess();

            } else {

               // StringBuilder sb = new StringBuilder();

                UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();
                String filterBloodGroup  = userInfo.getFilterBloodGroup();
                // add elements to al, including duplicates
                /*Set<String> hs = new HashSet<String>();
                hs.addAll(BaseActivityScreen.bloodGroupStringArrayList);
                BaseActivityScreen.bloodGroupStringArrayList.clear();
                BaseActivityScreen.bloodGroupStringArrayList.addAll(hs);
                for (int i = 0; i < BaseActivityScreen.bloodGroupStringArrayList.size(); i++) {

                    sb.append(BaseActivityScreen.bloodGroupStringArrayList.get(i));
                    sb.append(",");
                }*/

                PerformFilterProcess("28.599206", "77.346050", filterBloodGroup, BaseActivityScreen.distance);
            }
        } else
            CreateOfferDetail();

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }

    @Override
    public void feedItemClicked(Feed feed, String fragmentName) {
        Bundle bundle = new Bundle();
        bundle.putString("requestId", String.valueOf(feed.getId()));
        bundle.putString("userId", String.valueOf(feed.getUserId()));
        if (fragmentName.equalsIgnoreCase("Accepted Request")) {
            bundle.putString("FragmentName", fragmentName);
            bundle.putInt(StaticConstant.DONATED, feed.getDonated());
        }

        FeedDetailFragment feedDetailFragment = new FeedDetailFragment();
        feedDetailFragment.setArguments(bundle);

        ((BaseActivityScreen) getContext()).onReplaceFragment(feedDetailFragment, true);

    }
}
