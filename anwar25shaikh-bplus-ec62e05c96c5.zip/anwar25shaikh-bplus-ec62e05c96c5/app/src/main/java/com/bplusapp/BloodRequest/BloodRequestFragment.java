package com.bplusapp.BloodRequest;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bplusapp.Adapter.PlaceDetails;
import com.bplusapp.Adapter.PlacesAutoCompleteAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.AsyncTask.AuthCommonTask;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.ResultMessage;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.IAsyncTaskRunner;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.Network.BaseNetwork;
import com.bplusapp.Network.RetrofitInstance;
import com.bplusapp.Network.Urls;
import com.bplusapp.Network.models.AddressComponent;
import com.bplusapp.Network.models.PredictionResponse;
import com.bplusapp.R;
import com.bplusapp.UI.CustomEditView;
import com.bplusapp.UI.CustomLoadingDialog;
import com.bplusapp.Utils.Utils;
import com.bplusapp.dialog.BloodRequestCustomDialog;
import com.bplusapp.map.GPSTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.google.android.gms.plus.PlusShare;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Akash.Singh on 1/6/2016.
 */
public class BloodRequestFragment extends Fragment implements IAsyncTaskRunner, IDialogClick {

    String Date, Time;
    private int year, month, day, mHour, mMinute;
    private CustomEditView edit_patient_name, edit_blood_group, edit_within_time, edit_within_date,
    edit_hospital_address, edit_phone;
    private AutoCompleteTextView   edit_hosptial_name ;
    private CheckBox cb_urgent_requirements;
    private Button cb_facebook, cb_google, cb_twitter;

    private CustomLoadingDialog loadingDialog;
    private AuthCommonTask authCommonTask;


    GPSTracker gps;
    private PlacesAutoCompleteAdapter mAutoPlaceCompleteAdapter;
    private ArrayList<PlaceDetails> placeDetailsList;

    public BloodRequestFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FacebookSdk.sdkInitialize(getActivity());
    }
    double latitude ;
    double longitude ;
    private void performBloodRequestProcess(String edit_patient_name, String edit_blood_group, String edit_within_time, String edit_within_date, String edit_hosptial_name, String edit_hospital_address, String edit_phone) {


       /* gps = new GPSTracker(getActivity());
        // check if GPS enabled
        if(gps.canGetLocation()){

             latitude = gps.getLatitude();
             longitude = gps.getLongitude();

            // \n is for new line
           // Toast.makeText(getActivity(), "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
        }else{
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }*/

        loadingDialog = new CustomLoadingDialog(getActivity());
        authCommonTask = new AuthCommonTask(getActivity(), BaseNetwork.BLOOD_REQUEST_METHOD, this, loadingDialog);
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("patientName", edit_patient_name);
        hashMap.put("userId", ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo().getUserId());
        hashMap.put("bloodGroup", edit_blood_group);
        hashMap.put("reqDate", edit_within_date);
        hashMap.put("reqTime", edit_within_time);
        hashMap.put("HospitalName", edit_hosptial_name);
        hashMap.put("hospitalAddr", edit_hospital_address);
        hashMap.put("phone", edit_phone);
        hashMap.put("lattitude", String.valueOf(latitude));
        hashMap.put("longitude", String.valueOf(longitude));
        hashMap.put("urgent", ""+cb_urgent_requirements.isChecked());
        authCommonTask.execute(hashMap);
    }

    @Override
    public void taskCompleted(Object obj) {
        if (obj != null) {

            ResultMessage resultMessage = (ResultMessage) obj;
            if (resultMessage.TYPE.equalsIgnoreCase(BaseNetwork.BLOOD_REQUEST_METHOD)) {
                UserInfo userInfo = (UserInfo) resultMessage.RESULT_OBJECT;
                Toast.makeText(getActivity(), userInfo.getMessage(), Toast.LENGTH_LONG).show();
                getActivity().getSupportFragmentManager().popBackStack();
            }
        }
    }

    @Override
    public void taskErrorMessage(Object obj) {

        if(loadingDialog!=null && loadingDialog.isShowing())
            loadingDialog.dismiss();
        ResultMessage resultMessage = (ResultMessage) obj;
        if(resultMessage!=null)
            Utils.ShowAlertDialog(getActivity(), resultMessage.ERRORMESSAGE, this, null);

    }

    @Override
    public void taskProgress(Object obj) {

    }

    @Override
    public void taskStarting() {

    }

    @Override
    public void onCanceled() {

    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_blood_request_screen, container, false);
        ((BaseActivityScreen) getActivity()).SetToolbarInitialization(this, getString(R.string.need_blood_for));
        WidgetMapping(view);
        return view;
    }

    private void WidgetMapping(View view) {

        edit_patient_name = (CustomEditView) view.findViewById(R.id.edit_patient_name);

        edit_patient_name.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                edit_patient_name.setCursorVisible(true);
                return false;
            }
        });
        edit_blood_group = (CustomEditView) view.findViewById(R.id.edit_blood_group);
        edit_within_time = (CustomEditView) view.findViewById(R.id.edit_within_time);
        edit_within_date = (CustomEditView) view.findViewById(R.id.edit_within_date);
        edit_hosptial_name = (AutoCompleteTextView) view.findViewById(R.id.edit_hosptial_name);
        edit_hospital_address = (CustomEditView) view.findViewById(R.id.edit_hospital_address);
        edit_hosptial_name.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
        edit_hosptial_name.setThreshold(2);
        placeDetailsList = new ArrayList<PlaceDetails>();
        mAutoPlaceCompleteAdapter = new PlacesAutoCompleteAdapter(getContext(), 1, placeDetailsList);
        edit_hosptial_name.setAdapter(mAutoPlaceCompleteAdapter);
        edit_hosptial_name.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Logger.e(TAG, mAutoPlaceCompleteAdapter.getItem(position));
                //PlaceDetails placeDetails = mAutoPlaceCompleteAdapter.getItem(position);
                edit_hosptial_name.setText(mAutoPlaceCompleteAdapter.getItem(position).getDescription());
                getAddress(mAutoPlaceCompleteAdapter.getItem(position));
            }
        });


        edit_phone = (CustomEditView) view.findViewById(R.id.edit_phone);
        cb_urgent_requirements = (CheckBox) view.findViewById(R.id.cb_urgent_requirements);

        cb_facebook = (Button) view.findViewById(R.id.cb_facebook);
        cb_google = (Button) view.findViewById(R.id.cb_google);
        cb_twitter = (Button) view.findViewById(R.id.cb_twitter);

        shareDialog = new ShareDialog(getActivity());
        callbackManager = CallbackManager.Factory.create();


        shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {

            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });

        cb_facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (edit_patient_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter patient name", Toast.LENGTH_LONG).show();
                } else if (edit_blood_group.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter Blood group ", Toast.LENGTH_LONG).show();
                } else if (edit_within_date.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter date", Toast.LENGTH_LONG).show();
                } else if (edit_within_time.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter time", Toast.LENGTH_LONG).show();
                } else if (edit_hosptial_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital name", Toast.LENGTH_LONG).show();
                } else if (edit_hospital_address.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital address", Toast.LENGTH_LONG).show();
                } else if (edit_phone.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter phone number", Toast.LENGTH_LONG).show();
                } else {
                    if (ShareDialog.canShow(ShareLinkContent.class)) {
                        ShareLinkContent linkContent = new ShareLinkContent.Builder()
                                .setContentTitle("Urgent Need Blood")
                                .setContentDescription("Patient Name : " + edit_patient_name.getText().toString() + " , " + System.getProperty("line.separator") + "Blood Group : " + edit_blood_group.getText().toString() + " , " + System.getProperty("line.separator") + "Date : " + edit_within_date.getText().toString() + ", " + System.getProperty("line.separator") + "Time : " + edit_within_time.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Name : " + edit_hosptial_name.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Address : " + edit_hospital_address.getText().toString() + ", " + System.getProperty("line.separator") + "Phone : " + edit_phone.getText().toString())
                                .setContentUrl(Uri.parse("https://play.google.com/store?utm_source=apac_med&utm_medium=hasem&utm_content=Jun2515&utm_campaign=evergreen&pcampaignid=MKT-DR-apac-in-all-med-hasem-py-evergreen-Jun2515-1-en-bkws&gclid=CJyA04yt5s0CFUUeaAod9dYMaw&gclsrc=aw.ds"))
                                .build();

                        shareDialog.show(linkContent);
                    }
                }


            }

        });


        cb_google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (edit_patient_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter patient name", Toast.LENGTH_LONG).show();
                } else if (edit_blood_group.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter Blood group ", Toast.LENGTH_LONG).show();
                } else if (edit_within_date.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter date", Toast.LENGTH_LONG).show();
                } else if (edit_within_time.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter time", Toast.LENGTH_LONG).show();
                } else if (edit_hosptial_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital name", Toast.LENGTH_LONG).show();
                } else if (edit_hospital_address.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital address", Toast.LENGTH_LONG).show();
                } else if (edit_phone.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter phone number", Toast.LENGTH_LONG).show();
                } else {
                    Intent shareIntent = new PlusShare.Builder(getActivity())
                            .setType("text/plain")
                            .setText("Patient Name : " + edit_patient_name.getText().toString() + " , " + System.getProperty("line.separator") + "Blood Group : " + edit_blood_group.getText().toString() + " , " + System.getProperty("line.separator") + "Date : " + edit_within_date.getText().toString() + ", " + System.getProperty("line.separator") + "Time : " + edit_within_time.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Name : " + edit_hosptial_name.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Address : " + edit_hospital_address.getText().toString() + ", " + System.getProperty("line.separator") + "Phone : " + edit_phone.getText().toString())
                            .setContentUrl(Uri.parse("https://play.google.com/store?utm_source=apac_med&utm_medium=hasem&utm_content=Jun2515&utm_campaign=evergreen&pcampaignid=MKT-DR-apac-in-all-med-hasem-py-evergreen-Jun2515-1-en-bkws&gclid=CJyA04yt5s0CFUUeaAod9dYMaw&gclsrc=aw.ds"))
                            .getIntent();

                    startActivityForResult(shareIntent, 0);
                }
            }
        });

        cb_twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (edit_patient_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter patient name", Toast.LENGTH_LONG).show();
                } else if (edit_blood_group.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter Blood group ", Toast.LENGTH_LONG).show();
                } else if (edit_within_date.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter date", Toast.LENGTH_LONG).show();
                } else if (edit_within_time.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter time", Toast.LENGTH_LONG).show();
                } else if (edit_hosptial_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital name", Toast.LENGTH_LONG).show();
                } else if (edit_hospital_address.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital address", Toast.LENGTH_LONG).show();
                } else if (edit_phone.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter phone number", Toast.LENGTH_LONG).show();
                } else {
                  /*  Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_SEND);
                    intent.putExtra(Intent.EXTRA_TEXT, "Patient Name : " + edit_patient_name.getText().toString() + " , " + System.getProperty("line.separator") + "Blood Group : " + edit_blood_group.getText().toString() + " , " + System.getProperty("line.separator") + "Date : " + edit_within_date.getText().toString() + ", " + System.getProperty("line.separator") + "Time : " + edit_within_time.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Name : " + edit_hosptial_name.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Address : " + edit_hospital_address.getText().toString() + ", " + System.getProperty("line.separator") + "Phone : " + edit_phone.getText().toString());
                    intent.setType("text/plain");
                    intent.setPackage("com.twitter.android");
                    startActivity(intent);*/
                    String tweetUrl = String.format("https://twitter.com/intent/tweet?text=%s",
                            urlEncode("Patient Name : " + edit_patient_name.getText().toString() + " , " + System.getProperty("line.separator") + "Blood Group : " + edit_blood_group.getText().toString() + " , " + System.getProperty("line.separator") + "Date : " + edit_within_date.getText().toString() + ", " + System.getProperty("line.separator") + "Time : " + edit_within_time.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Name : " + edit_hosptial_name.getText().toString() + ", " + System.getProperty("line.separator") + "Hospital Address : " + edit_hospital_address.getText().toString() + ", " + System.getProperty("line.separator") + "Phone : " + edit_phone.getText().toString())
                            );
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(tweetUrl));

// Narrow down to official Twitter app, if available:
                    List<ResolveInfo> matches = getActivity().getPackageManager().queryIntentActivities(intent, 0);
                    for (ResolveInfo info : matches) {
                        if (info.activityInfo.packageName.toLowerCase().startsWith("com.twitter")) {
                            intent.setPackage(info.activityInfo.packageName);
                        }
                    }

                    startActivity(intent);
                }
            }
        });

        edit_blood_group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new BloodRequestCustomDialog(getActivity(), edit_blood_group).show();
               // edit_patient_name.clearFocus();
               // edit_patient_name.clearFocus();
                edit_patient_name.setCursorVisible(false);
            }
        });

        edit_within_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dpd = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @SuppressLint("SimpleDateFormat")
                            @Override
                            public void onDateSet(DatePicker arg0, int Year,
                                                  int Month, int Day) {
                                String months = "";
                                if (Month < 10) {
                                    months = "0" + (Month + 1);
                                } else {
                                    months = String.valueOf((Month + 1));
                                }

                                String date = Day + "-" + months + "-" + Year;
                                Log.e("old date", date);
                                SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
                                try {
                                    String newDate = sdf.format(new SimpleDateFormat("dd-MM-yyyy").parse(date));
                                    Date = "";
                                    Date = newDate;
                                    edit_within_date.setText(Html.fromHtml(" " + newDate));
                                    Log.e("new date", sdf.format(new SimpleDateFormat("dd-MM-yyyy").parse(date)));
                                } catch (java.text.ParseException e) {
                                    e.printStackTrace();
                                }

                                edit_patient_name.setCursorVisible(false);
                            }
                        }, year, month, day);
                dpd.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                dpd.show();
            }
        });

        edit_within_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);
                TimePickerDialog tpd = new TimePickerDialog(getActivity(),
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                String minutes = "";


                                if (minute < 10) {

                                    minutes = "0" + minute;

                                } else {
                                    minutes = String.valueOf(minute);
                                }

                                Log.e("minutes", minute + "");
                                if (hourOfDay > 12) {
                                    Time = "";
                                    Time = String.valueOf(hourOfDay - 12) + ":" + minutes + " PM";
                                    edit_within_time.setText(Html.fromHtml(" " + String.valueOf(hourOfDay - 12) + ":" + minutes + " PM"));
                                }
                                if (hourOfDay == 12) {
                                    Time = "";
                                    Time = "12" + ":" + minutes + " PM";
                                    edit_within_time.setText(Html.fromHtml(" " + "12" + ":" + minutes + " PM"));
                                }
                                if (hourOfDay < 12) {
                                    if (hourOfDay != 0) {
                                        Time = "";
                                        Time = String.valueOf(hourOfDay) + ":" + minutes + " AM";
                                        edit_within_time.setText(Html.fromHtml(" " + String.valueOf(hourOfDay) + ":" + minutes + " AM"));
                                    } else {
                                        Time = "";
                                        Time = "12" + ":" + minutes + " AM";
                                        edit_within_time.setText(Html.fromHtml("" + "12" + ":" + minutes + " AM"));
                                    }
                                }
                                edit_patient_name.setCursorVisible(false);
                                edit_hosptial_name.requestFocus();
                            }
                        }, mHour, mMinute, false);
                tpd.show();
            }
        });
        ((AppCompatButton) view.findViewById(R.id.btnPostBloodRequest)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (edit_patient_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter patient name", Toast.LENGTH_LONG).show();
                } else if (edit_blood_group.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter Blood group ", Toast.LENGTH_LONG).show();
                } else if (edit_within_date.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter date", Toast.LENGTH_LONG).show();
                } else if (edit_within_time.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter time", Toast.LENGTH_LONG).show();
                } else if (edit_hosptial_name.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital name", Toast.LENGTH_LONG).show();
                } else if (edit_hospital_address.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter hospital address", Toast.LENGTH_LONG).show();
                } else if (edit_phone.getText().toString().trim().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Enter phone number", Toast.LENGTH_LONG).show();
                } else {
                    performBloodRequestProcess(edit_patient_name.getText().toString().trim(), edit_blood_group.getText().toString().trim()
                            , edit_within_time.getText().toString().trim(), edit_within_date.getText().toString().trim(), edit_hosptial_name.getText().toString().trim(), edit_hosptial_name.getText().toString().trim()
                            , edit_phone.getText().toString().trim());
                }


            }
        });


    }

    private void getAddress(PlaceDetails placeDetails) {
        edit_hospital_address.setText(getString(R.string.fetching_address));
       // activityHandle.showProgress(getString(R.string.loading_msg));
        Call<PredictionResponse> call = RetrofitInstance.getInstance(Urls.GOOGLE_PLACES_BASE_URL)
                .getPlaceDetails(placeDetails.getPlaceId(), Urls.GOOGLE_PLACES_API_KEY);
        call.enqueue(new Callback<PredictionResponse>() {
            @Override
            public void onResponse(Call<PredictionResponse> call, Response<PredictionResponse> response) {
                PredictionResponse predictionRes = response.body();
                if (predictionRes.getStatus().equalsIgnoreCase("ok")) {
                    List<AddressComponent> addressComponents = predictionRes.getResult().getAddressComponents();
                    String addressString = "";
                    for (AddressComponent address : addressComponents) {
                        List<String> types = address.getTypes();
                        for (String type : types) {
                            if (type.equalsIgnoreCase("premise")) {
                                addressString= addressString +(address.getLongName())+" ";
                            } else if (type.equalsIgnoreCase("route")) {
                                addressString = addressString + (address.getLongName())+" ";
                            } else if (type.equalsIgnoreCase("locality")) {
                                addressString= addressString + address.getLongName()+" ";
                            }
                        }
                    }
                    edit_hospital_address.setText(addressString);
                    latitude = predictionRes.getResult().getGeometry().getLocation().getLat();
                    longitude = predictionRes.getResult().getGeometry().getLocation().getLng();
                }
               // activityHandle.hideProgress();

            }

            @Override
            public void onFailure(Call<PredictionResponse> call, Throwable t) {
                edit_hospital_address.setText(null);
               // activityHandle.hideProgress();
            }
        });
    }

    ShareDialog shareDialog;
    CallbackManager callbackManager;

    public static String urlEncode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            Log.wtf("BloodRequestFrag", "UTF-8 should always be supported", e);
            throw new RuntimeException("URLEncoder.encode() failed for " + s);
        }
    }
}
