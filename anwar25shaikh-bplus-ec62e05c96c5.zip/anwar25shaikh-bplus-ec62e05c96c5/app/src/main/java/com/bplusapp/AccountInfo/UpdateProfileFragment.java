package com.bplusapp.AccountInfo;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import com.bplusapp.Adapter.SpinnerAdapter;
import com.bplusapp.ApplicationContainer;
import com.bplusapp.BaseActivityScreen;
import com.bplusapp.Entity.BloodGroup;
import com.bplusapp.Entity.Country;
import com.bplusapp.Entity.UserInfo;
import com.bplusapp.Interface.IDialogClick;
import com.bplusapp.R;
import com.bplusapp.Sort.BloodGroupComparator;
import com.bplusapp.Sort.CountryComparator;
import com.bplusapp.StaticData.StaticConstant;
import com.bplusapp.UI.CustomEditView;
import com.bplusapp.UI.CustomTextView;
import com.bplusapp.UI.CustomTextWatcher;
import com.bplusapp.Utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Akash.Singh on 1/6/2016.
 */
public class UpdateProfileFragment extends Fragment implements View.OnClickListener,IDialogClick {
    ArrayList<Object> bloodGroupArray =  new ArrayList();
    ArrayList<Object> nationalityArray =  new ArrayList<>();
    Spinner spinner_blood_group,spinner_country;
    CustomTextView text_country,text_blood_group;
    CustomEditView edit_address,edit_state,edit_city,edit_zipcode,edit_phone;
    TextInputLayout input_address,input_state,input_city,input_zipcode,input_phone;

    @Nullable
    @Override
            public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.content_update_profile_screen,container,false);
            WidgetMapping(view);
            if(getActivity() instanceof AccountActivityScreen)
        {
            ((AccountActivityScreen)getActivity()).SetToolbarInitialization(this,getString(R.string.title_update_profile));
        }else if (getActivity() instanceof BaseActivityScreen){
            ((BaseActivityScreen)getActivity()).SetToolbarInitialization(this, getString(R.string.title_update_profile));
            UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();

            spinner_blood_group.setPrompt(userInfo.getUserBloodGroup());
            edit_address.setText(userInfo.getUserAddress());
            edit_state.setText(userInfo.getUserState());
            edit_city.setText(userInfo.getUserCity());
            edit_zipcode.setText(userInfo.getUserZipCode());
            edit_phone.setText(userInfo.getUserMobile());

            int index = getIndexByname(userInfo.getUserBloodGroup());

            spinner_blood_group.setSelection(index);

            if(getArguments() != null){
                if(getArguments().getBoolean(StaticConstant.BLOOD_GROUP_NON_EDITABLE)){
                    spinner_blood_group.setEnabled(false);
                }
            }
            spinner_country.setSelection(getIndexBynameCountry(userInfo.getUserCountry()));

        }
        return view;
    }

    public int getIndexByname(String pName)
    {
        for(int i = 0 ;i<bloodGroupArray.size() ;i++){
            BloodGroup bloodGroup = (BloodGroup) bloodGroupArray.get(i);
            if((bloodGroup.getBloodGroupName().equals(pName)))
                return bloodGroupArray.indexOf(bloodGroup);
        }
        return -1;
    }


    public int getIndexBynameCountry(String pName)
    {
        for(int i = 0 ;i<nationalityArray.size() ;i++){
            Country country = (Country) nationalityArray.get(i);
            if((country.getCountryName().equals(pName)))
                return nationalityArray.indexOf(country);
        }
        return -1;
    }

    private void WidgetMapping(View view) {
        edit_address = (CustomEditView) view.findViewById(R.id.edit_address);
        edit_state = (CustomEditView) view.findViewById(R.id.edit_state);
        edit_city = (CustomEditView) view.findViewById(R.id.edit_city);
        edit_zipcode = (CustomEditView) view.findViewById(R.id.edit_zipcode);
        edit_phone = (CustomEditView) view.findViewById(R.id.edit_phone);

        input_address = (TextInputLayout) view.findViewById(R.id.input_address);
        input_state = (TextInputLayout) view.findViewById(R.id.input_state);
        input_city = (TextInputLayout) view.findViewById(R.id.input_city);
        input_zipcode = (TextInputLayout) view.findViewById(R.id.input_zipcode);
        input_phone = (TextInputLayout) view.findViewById(R.id.input_phone);


        text_country = (CustomTextView) view.findViewById(R.id.text_country);
        text_blood_group = (CustomTextView) view.findViewById(R.id.text_blood_group);
        spinner_blood_group = (Spinner) view.findViewById(R.id.spinner_blood_group);
        spinner_country = (Spinner) view.findViewById(R.id.spinner_country);


        edit_address.addTextChangedListener(new CustomTextWatcher(input_address));
        edit_state.addTextChangedListener(new CustomTextWatcher(input_state));
        edit_city.addTextChangedListener(new CustomTextWatcher(input_city));
        edit_zipcode.addTextChangedListener(new CustomTextWatcher(input_zipcode));
        edit_phone.addTextChangedListener(new CustomTextWatcher(input_phone));


        ((AppCompatButton)view.findViewById(R.id.btnSubmited)).setOnClickListener(this);
        BloodGroupView();
        CountryChangeView();
        SpinnerAdapter adapter_payment = new SpinnerAdapter(getActivity(), R.layout.my_spinner_style, bloodGroupArray);
        adapter_payment.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_blood_group.setAdapter(adapter_payment);
        final Typeface face= Typeface.createFromAsset(getActivity().getAssets(), "LatoRegular.ttf");

        spinner_blood_group.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                if (position == 0){

                    text_blood_group.setVisibility(View.INVISIBLE);
                }

                else
                    text_blood_group.setVisibility(View.VISIBLE);
                ((TextView) parent.getChildAt(0)).setTypeface(face);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });
        spinner_country.setAdapter(new SpinnerAdapter(getActivity(), R.layout.my_spinner_style, nationalityArray));
        spinner_country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                if (position == 0)
                    text_country.setVisibility(View.INVISIBLE);
                else
                    text_country.setVisibility(View.VISIBLE);
                ((TextView) parent.getChildAt(0)).setTypeface(face);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


    }

    private boolean Validation(){
        BloodGroup bloodGroup = (BloodGroup) spinner_blood_group.getSelectedItem();
        Country country = (Country) spinner_country.getSelectedItem();

        if(bloodGroup.getBloodGroupName().equalsIgnoreCase("Select your blood group")) {
            Utils.ShowAlertDialog(getActivity(), "Select a blood group type", this, null);
            return false;
        }else if(TextUtils.isEmpty(edit_address.getText().toString())) {
           // input_address.setError(getString(R.string.hint_please_enter_your_address));
            Utils.ShowAlertDialog(getActivity(), getString(R.string.hint_please_enter_your_address), this, null);
            return false;
        }else if(country.getCountryName().equalsIgnoreCase("Select your country")) {
            Utils.ShowAlertDialog(getActivity(), "Select a country", this, null);
            return false;
        }else if(TextUtils.isEmpty(edit_state.getText().toString())) {
            //input_state.setError(getString(R.string.hint_please_enter_your_state));
            Utils.ShowAlertDialog(getActivity(), getString(R.string.hint_please_enter_your_state), this, null);
            return false;
        }else if(TextUtils.isEmpty(edit_city.getText().toString())) {
            //input_city.setError(getString(R.string.hint_please_enter_your_city));
            Utils.ShowAlertDialog(getActivity(), getString(R.string.hint_please_enter_your_city), this, null);
            return false;
        }
        else if(TextUtils.isEmpty(edit_city.getText().toString())) {
            //input_zipcode.setError(getString(R.string.hint_please_enter_zipcode));
            Utils.ShowAlertDialog(getActivity(), getString(R.string.hint_please_enter_zipcode), this, null);
            return false;
        }else if(TextUtils.isEmpty(edit_city.getText().toString())) {
            //input_phone.setError(getString(R.string.hint_please_enter_your_phone));
            Utils.ShowAlertDialog(getActivity(), getString(R.string.hint_please_enter_your_phone), this, null);
            return false;
        }else if(!TextUtils.isEmpty(edit_city.getText().toString())&& !Utils.validatePhone(edit_phone.getText().toString())) {
          //  input_phone.setError(getString(R.string.hint_please_enter_your_phone));
            Utils.ShowAlertDialog(getActivity(), getString(R.string.hint_please_enter_your_phone), this, null);
            return false;
        }

        return  true;
    }



    private void BloodGroupView() {
        bloodGroupArray.clear();
        HashMap<Object,Object> objectArrayList = ApplicationContainer.getInstance().getDataModel().GetBloodGroupList();
        for(HashMap.Entry entry:objectArrayList.entrySet()){
            BloodGroup bloodGroup = (BloodGroup) entry.getValue();
            bloodGroupArray.add(bloodGroup);
        }
        BloodGroupComparator comparator =  new BloodGroupComparator();
        comparator.sort(CountryComparator.CODE_ATOZ, bloodGroupArray);

    }

    private AdapterView.OnItemSelectedListener OnCatSpinnerCL = new AdapterView.OnItemSelectedListener() {
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

        }

        public void onNothingSelected(AdapterView<?> parent) {

        }
    };

    private void CountryChangeView() {
        nationalityArray.clear();
        HashMap<Object,Object> objectArrayList = ApplicationContainer.getInstance().getDataModel().GetCountryList();
        for(HashMap.Entry entry:objectArrayList.entrySet()){
            Country nationality = (Country) entry.getValue();
            nationalityArray.add(nationality);
        }
        CountryComparator comparator =  new CountryComparator();
        comparator.sort(CountryComparator.NAME_ATOZ, nationalityArray);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSubmited:
                if(Validation()){
                    BloodGroup bloodGroup = (BloodGroup) spinner_blood_group.getSelectedItem();
                    Country country = (Country) spinner_country.getSelectedItem();
                    UserInfo userInfo = ApplicationContainer.getInstance().getBPlusSavedDBData().getUserInfo();


                    if(getActivity() instanceof AccountActivityScreen) {
                        ((AccountActivityScreen) getActivity()).PerformUpdateProfileProcess(userInfo.getUserId()
                                , bloodGroup.getBloodGroupName(), edit_address.getText().toString()
                                , country.getCountryName(), edit_state.getText().toString(), edit_city.getText().toString()
                                , edit_zipcode.getText().toString(), edit_phone.getText().toString());
                    }else if (getActivity() instanceof BaseActivityScreen){
                        ((BaseActivityScreen) getActivity()).PerformUpdateProfileProcess(userInfo.getUserId()
                                , bloodGroup.getBloodGroupName(), edit_address.getText().toString()
                                , country.getCountryName(), edit_state.getText().toString(), edit_city.getText().toString()
                                , edit_zipcode.getText().toString(), edit_phone.getText().toString());
                    }
                    //Update user info in local database
                    userInfo.setUserAddress(String.valueOf(edit_address.getText()));
                    userInfo.setUserCountry(country.getCountryName());
                    userInfo.setUserState(String.valueOf(edit_state.getText()));
                    userInfo.setUserCity(String.valueOf(edit_city.getText()));
                    userInfo.setUserZipCode(String.valueOf(edit_zipcode.getText()));
                    userInfo.setUserMobile(String.valueOf(edit_phone.getText()));
                    ApplicationContainer.getInstance().getBPlusSavedDBData().InsertUserInfoID(userInfo);
                }
                break;
        }
    }

    @Override
    public void OnClickListener(Fragment fragment) {

    }
}
