package com.bplusapp.UI;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.support.v7.widget.AppCompatButton;
import android.util.AttributeSet;
import com.bplusapp.R;

/**
 * Created by Akash.Singh on 6/2/2015.
 * This is custom TextView class. This class use declare font on global
 */
public class CustomAppCompatButton extends AppCompatButton {

    private static final String LatoBold= "LatoBold";
    private static final String LatoRegular= "LatoRegular";


    public CustomAppCompatButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        if(!isInEditMode()) {
            Init(attrs);
        }
    }

    private void Init(AttributeSet  attributeset) {
            if (attributeset != null)
            {
                TypedArray attributeset1 = getContext().obtainStyledAttributes(attributeset, R.styleable.CustomAppCompatButton);
                String s = attributeset1.getString(0);
                if(LatoBold.equals(s)){
                    setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoBold.ttf"));
                }
                else if(LatoRegular.equals(s)){
                    setTypeface(Typeface.createFromAsset(getContext().getAssets(), "LatoRegular.ttf"));
                }
                attributeset1.recycle();
            }
  }
}
