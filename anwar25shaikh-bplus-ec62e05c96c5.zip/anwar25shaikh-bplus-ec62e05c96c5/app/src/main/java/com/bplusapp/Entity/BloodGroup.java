package com.bplusapp.Entity;

import java.io.Serializable;

/**
 * Created by Akash.Singh on 02/04/2016.
 * This class object contain country information
 */
public class BloodGroup implements Serializable{
    int bloodGroupCode;
    String bloodGroupName;
    String bloodGroupColor;

    public BloodGroup(){

    }
    public BloodGroup(int bloodGroupCode, String bloodGroupName,String bloodGroupColor) {
        setBloodGroupCode(bloodGroupCode);
        setBloodGroupName(bloodGroupName);
        setBloodGroupColor(bloodGroupColor);

    }

    public int getBloodGroupCode() {
        return bloodGroupCode;
    }

    public void setBloodGroupCode(int bloodGroupCode) {
        this.bloodGroupCode = bloodGroupCode;
    }

    public String getBloodGroupName() {
        return bloodGroupName;
    }

    public void setBloodGroupName(String bloodGroupName) {
        this.bloodGroupName = bloodGroupName;
    }

    public String getBloodGroupColor() {
        return bloodGroupColor;
    }

    public void setBloodGroupColor(String bloodGroupColor) {
        this.bloodGroupColor = bloodGroupColor;
    }
}
