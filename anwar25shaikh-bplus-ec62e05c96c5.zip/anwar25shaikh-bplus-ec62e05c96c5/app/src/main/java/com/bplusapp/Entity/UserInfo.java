package com.bplusapp.Entity;

/**
 * Created by Akash.singh on 1/30/2016.
 */
public class UserInfo {

    int Success;
    String message;
    String userEmail;
    String profile_image;
    String userFName;
    String userLName;
    String userMobile;
    String userAddress;
    String userBloodGroup;
    String userCountry;
    String userCity;
    String userState;
    String userZipCode;
    String profilePic;
    String authId;
    String userId;
    String authBy;
    String totalNotifications;

    String filterDistance ;
    String filterBloodGroup ;

    public String getFilterDistance() {
        return filterDistance;
    }

    public void setFilterDistance(String filterDistance) {
        this.filterDistance = filterDistance;
    }

    public String getFilterBloodGroup() {
        return filterBloodGroup;
    }

    public void setFilterBloodGroup(String filterBloodGroup) {
        this.filterBloodGroup = filterBloodGroup;
    }

    public String getProfile_image() {
        return profile_image;
    }

    public void setProfile_image(String profile_image) {
        this.profile_image = profile_image;
    }

    public String getTotalNotifications() {
        return totalNotifications;
    }

    public void setTotalNotifications(String totalNotifications) {
        this.totalNotifications = totalNotifications;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public void setAuthBy(String authBy) {
        this.authBy = authBy;
    }

    public String getAuthId() {
        return authId;
    }

    public String getAuthBy() {
        return authBy;
    }

    public int getSuccess() {
        return Success;
    }

    public void setSuccess(int success) {
        Success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserFName() {
        return userFName;
    }

    public void setUserFName(String userFName) {
        this.userFName = userFName;
    }

    public String getUserLName() {
        return userLName;
    }

    public void setUserLName(String userLName) {
        this.userLName = userLName;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserBloodGroup() {
        return userBloodGroup;
    }

    public void setUserBloodGroup(String userBloodGroup) {
        this.userBloodGroup = userBloodGroup;
    }

    public String getUserCountry() {
        return userCountry;
    }

    public void setUserCountry(String userCountry) {
        this.userCountry = userCountry;
    }

    public String getUserCity() {
        return userCity;
    }

    public void setUserCity(String userCity) {
        this.userCity = userCity;
    }

    public String getUserState() {
        return userState;
    }

    public void setUserState(String userState) {
        this.userState = userState;
    }

    public String getUserZipCode() {
        return userZipCode;
    }

    public void setUserZipCode(String userZipCode) {
        this.userZipCode = userZipCode;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }
}
